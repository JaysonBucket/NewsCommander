#!/usr/bin/env python3
"""
News Commander — send_digest.py
Render + Versand des Digests in Teams Self-Chat oder per Mail.

Usage:
    python send_digest.py [--digest <path>] [--channel teams_self_chat|mail|both]
                          [--force-send] [--dry-run]

Default: Liest data/digests/<today>.json, schaut in preferences.json nach
dem Channel und rendert die Templates aus templates/. Bei dry-run wird
das Rendering nur nach working/digest-preview.* geschrieben statt verschickt.

Da Senden hier nicht direkt geht (kein MCP-Zugriff aus Python),
schreibt das Script die fertigen Render-Outputs in:
    output/digest-teams-<today>.md         (für PostMessage recipients=['me'])
    output/digest-mail-<today>.html        (für SendEmailWithAttachments body_file_path)

Der Cowork-Run-Prompt liest dann die Dateien und ruft die richtigen
Versand-Tools auf. Empty-Day-Suppress wird ebenfalls hier signalisiert:
Exit-Code 2 = "leer, nicht senden".
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _atomic import atomic_save_json, atomic_write_text  # noqa: E402

SKILL_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = SKILL_DIR / "data"
DIGESTS_DIR = DATA_DIR / "digests"
TEMPLATES_DIR = SKILL_DIR / "templates"
PREFS_FILE = DATA_DIR / "preferences.json"
META_FILE = DATA_DIR / "_meta.json"

OUTPUT_DIR = Path("/mnt/workspace/output")
WORKING_DIR = Path("/mnt/workspace/working")


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    atomic_save_json(Path(path), data)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def is_valid_url(url: str | None) -> bool:
    """Strict check: must start with http(s)://, no anchor-only, no javascript:."""
    if not url or not isinstance(url, str):
        return False
    u = url.strip()
    if not u:
        return False
    low = u.lower()
    if low.startswith("javascript:") or low.startswith("mailto:"):
        return False
    if not (low.startswith("http://") or low.startswith("https://")):
        return False
    if u.endswith("#") or "#" == u.split("//", 1)[-1].split("/", 1)[-1].strip("/"):
        return False
    return True


def effective_url(item: dict) -> tuple[str, bool]:
    """Return (url, is_fallback). Falls back to source_url with hint flag
    when item['url'] is missing or invalid. Last-resort: '#' (renderer should
    suppress link rendering)."""
    primary = item.get("url")
    if is_valid_url(primary):
        return primary, False
    src_url = item.get("source_url")
    if is_valid_url(src_url):
        return src_url, True
    return "#", True


def format_item_md(item: dict, idx: int) -> str:
    title = item["title"].strip()
    url, is_fallback = effective_url(item)
    src = item.get("source_title", item.get("source_id", "?"))
    score = item.get("score", 0)
    matched = item.get("matched_keywords", [])
    matched_str = ", ".join(matched[:3]) if matched else "—"
    abstract = (item.get("abstract") or "").strip()
    if abstract and len(abstract) > 240:
        abstract = abstract[:237] + "…"

    block = [f"**{idx}. [{title}]({url})**"]
    block.append(f"   _{src}_ · Score {score} · Treffer: {matched_str}")
    if abstract:
        block.append(f"   > {abstract}")
    if is_fallback:
        block.append(f"   ⚠️ _Direktlink fehlt — Fallback auf Quellenseite_")
        block.append(f"   🔗 [Zur Quelle ({src})]({url})")
    else:
        block.append(f"   🔗 [Vollständiger Artikel öffnen]({url})")
    return "\n".join(block)


def format_watch_md(item: dict, idx: int) -> str:
    title = item["title"].strip()
    url, is_fallback = effective_url(item)
    src = item.get("source_title", item.get("source_id", "?"))
    suggestion = item.get("watch_suggestion", {})
    kw = suggestion.get("topic_hint_keyword", "")
    add_cmd = suggestion.get("add_command", f"News Commander Topic Add {kw}")

    block = [f"**{idx}. [{title}]({url})**"]
    block.append(f"   _{src}_")
    block.append(f"   💡 Würde mit aktuellen Filtern rausfallen. Treffer: `{kw}`. Topic adden?")
    block.append(f"   → `{add_cmd}`")
    if is_fallback:
        block.append(f"   ⚠️ _Direktlink fehlt — Fallback auf Quellenseite_")
        block.append(f"   🔗 [Zur Quelle ({src})]({url})")
    else:
        block.append(f"   🔗 [Vollständiger Artikel öffnen]({url})")
    return "\n".join(block)


def render_teams_md(digest: dict) -> str:
    counts = digest["counts"]
    date_str = digest["date"]
    high = digest.get("high", [])
    medium = digest.get("medium", [])
    watch = digest.get("watch", [])

    lines = []
    lines.append(f"# 📰 News Commander — {date_str}")
    lines.append("")
    lines.append(f"_{counts['high']} HIGH · {counts['medium']} MEDIUM · {counts['watch']} Vorschläge · {counts['deduped']} dedupliziert_")
    lines.append("")
    lines.append("---")
    lines.append("")

    if high:
        lines.append("## 🔥 HIGH")
        lines.append("")
        for i, it in enumerate(high, 1):
            lines.append(format_item_md(it, i))
            lines.append("")
            lines.append("")
        lines.append("---")
        lines.append("")

    if medium:
        lines.append("## 📌 MEDIUM")
        lines.append("")
        for i, it in enumerate(medium, 1):
            lines.append(format_item_md(it, i))
            lines.append("")
            lines.append("")
        lines.append("---")
        lines.append("")

    if watch:
        lines.append("## 💡 Vorschläge — knapp unter Filter")
        lines.append("")
        for i, it in enumerate(watch, 1):
            lines.append(format_watch_md(it, i))
            lines.append("")
            lines.append("")
        lines.append("---")
        lines.append("")

    lines.append(f"_Generated {digest['generated_at']} · Topic adden via `News Commander Topic Add <keyword>`_")
    return "\n".join(lines)


def render_mail_html(digest: dict) -> str:
    counts = digest["counts"]
    date_str = digest["date"]
    high = digest.get("high", [])
    medium = digest.get("medium", [])
    watch = digest.get("watch", [])

    def item_html(item: dict, idx: int) -> str:
        title = item["title"].strip().replace("<", "&lt;").replace(">", "&gt;")
        url, is_fallback = effective_url(item)
        src = item.get("source_title", item.get("source_id", "?"))
        score = item.get("score", 0)
        matched = ", ".join(item.get("matched_keywords", [])[:3]) or "—"
        abstract = (item.get("abstract") or "").strip()
        if abstract and len(abstract) > 240:
            abstract = abstract[:237] + "…"
        abstract = abstract.replace("<", "&lt;").replace(">", "&gt;")
        src_safe = src.replace("<", "&lt;").replace(">", "&gt;")

        h = f'<div style="margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid #eee">'
        h += f'<div style="font-size:15px"><strong>{idx}. <a href="{url}" style="color:#0078d4;text-decoration:none">{title}</a></strong></div>'
        h += f'<div style="color:#666;font-size:13px;margin-top:4px">{src_safe} · Score {score} · Treffer: {matched}</div>'
        if abstract:
            h += f'<div style="color:#444;margin-top:8px;font-style:italic;line-height:1.5">{abstract}</div>'
        if is_fallback:
            h += f'<div style="color:#b56500;margin-top:8px;font-size:12px">⚠️ Direktlink fehlt — Fallback auf Quellenseite</div>'
            h += f'<div style="margin-top:6px"><a href="{url}" style="color:#0078d4;font-size:13px;text-decoration:none">🔗 Zur Quelle ({src_safe}) →</a></div>'
        else:
            h += f'<div style="margin-top:10px"><a href="{url}" style="color:#0078d4;font-size:13px;text-decoration:none">🔗 Vollständiger Artikel öffnen →</a></div>'
        h += "</div>"
        return h

    def watch_html(item: dict, idx: int) -> str:
        title = item["title"].strip().replace("<", "&lt;").replace(">", "&gt;")
        url, is_fallback = effective_url(item)
        src = item.get("source_title", item.get("source_id", "?"))
        src_safe = src.replace("<", "&lt;").replace(">", "&gt;")
        kw = item.get("watch_suggestion", {}).get("topic_hint_keyword", "")
        add_cmd = item.get("watch_suggestion", {}).get("add_command", f"News Commander Topic Add {kw}")
        h = f'<div style="margin-bottom:24px;padding:14px;background:#fff8e1;border-left:3px solid #ffb300;border-radius:3px">'
        h += f'<div style="font-size:15px"><strong>{idx}. <a href="{url}" style="color:#0078d4;text-decoration:none">{title}</a></strong></div>'
        h += f'<div style="color:#666;font-size:13px;margin-top:4px">{src_safe}</div>'
        h += f'<div style="margin-top:8px;font-size:13px">💡 Würde rausfallen. Treffer: <code>{kw}</code>. Topic adden?</div>'
        h += f'<div style="margin-top:4px;font-size:12px;font-family:monospace;color:#555">→ {add_cmd}</div>'
        if is_fallback:
            h += f'<div style="color:#b56500;margin-top:8px;font-size:12px">⚠️ Direktlink fehlt — Fallback auf Quellenseite</div>'
            h += f'<div style="margin-top:6px"><a href="{url}" style="color:#0078d4;font-size:13px;text-decoration:none">🔗 Zur Quelle ({src_safe}) →</a></div>'
        else:
            h += f'<div style="margin-top:10px"><a href="{url}" style="color:#0078d4;font-size:13px;text-decoration:none">🔗 Vollständiger Artikel öffnen →</a></div>'
        h += "</div>"
        return h

    def section_divider() -> str:
        return '<hr style="margin:36px 0;border:none;border-top:1px solid #ddd"/>'

    out = []
    out.append('<html><body style="font-family:-apple-system,Segoe UI,sans-serif;max-width:720px;margin:0 auto;padding:16px;line-height:1.4;color:#222">')
    out.append(f'<h1 style="border-bottom:2px solid #0078d4;padding-bottom:8px;margin-bottom:4px">📰 News Commander — {date_str}</h1>')
    out.append(f'<p style="color:#666;margin-top:4px">{counts["high"]} HIGH · {counts["medium"]} MEDIUM · {counts["watch"]} Vorschläge · {counts["deduped"]} dedupliziert</p>')

    if high:
        out.append(section_divider())
        out.append('<h2 style="color:#d83b01;margin-bottom:18px">🔥 HIGH</h2>')
        for i, it in enumerate(high, 1):
            out.append(item_html(it, i))
    if medium:
        out.append(section_divider())
        out.append('<h2 style="color:#0078d4;margin-bottom:18px">📌 MEDIUM</h2>')
        for i, it in enumerate(medium, 1):
            out.append(item_html(it, i))
    if watch:
        out.append(section_divider())
        out.append('<h2 style="color:#b56500;margin-bottom:18px">💡 Vorschläge — knapp unter Filter</h2>')
        for i, it in enumerate(watch, 1):
            out.append(watch_html(it, i))

    out.append(section_divider())
    out.append(f'<p style="color:#999;font-size:12px">Generated {digest["generated_at"]} · Topic adden via <code>News Commander Topic Add &lt;keyword&gt;</code></p>')
    out.append('</body></html>')
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--digest", help="Path to digest JSON (default: today's)")
    ap.add_argument("--channel", help="Override delivery channel")
    ap.add_argument("--force-send", action="store_true", help="Ignore suppress_empty_days")
    ap.add_argument("--dry-run", action="store_true", help="Write to working/, not output/")
    args = ap.parse_args()

    prefs = load_json(PREFS_FILE)
    if not prefs:
        print("ERROR: preferences.json missing", file=sys.stderr)
        return 1

    today = datetime.now().date().isoformat()
    digest_path = Path(args.digest) if args.digest else DIGESTS_DIR / f"{today}.json"
    digest = load_json(digest_path)
    if not digest:
        print(f"ERROR: digest {digest_path} missing", file=sys.stderr)
        return 1

    counts = digest["counts"]
    total = counts["high"] + counts["medium"] + counts["watch"]
    suppress = prefs["delivery"].get("suppress_empty_days", True)

    if total == 0 and suppress and not args.force_send:
        print("⏭  empty day — suppressed (suppress_empty_days=true)")
        return 2

    channel = args.channel or prefs["delivery"].get("channel", "teams_self_chat")
    out_dir = WORKING_DIR if args.dry_run else OUTPUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)

    written = []
    if channel in ("teams_self_chat", "both"):
        teams_path = out_dir / f"digest-teams-{today}.md"
        atomic_write_text(teams_path, render_teams_md(digest))
        written.append(("teams", teams_path))
    if channel in ("mail", "both"):
        mail_path = out_dir / f"digest-mail-{today}.html"
        atomic_write_text(mail_path, render_mail_html(digest))
        written.append(("mail", mail_path))

    # Update meta
    meta = load_json(META_FILE, default={})
    last_run = meta.setdefault("last_run", {})
    last_run["digest_rendered_at"] = now_iso()
    last_run["digest_channel"] = channel
    last_run["digest_total_items"] = total
    stats = meta.setdefault("stats", {})
    stats["total_digests_rendered"] = stats.get("total_digests_rendered", 0) + 1
    save_json(META_FILE, meta)

    print(f"✓ rendered {len(written)} channel(s) for {today}")
    for kind, p in written:
        print(f"  - {kind}: {p}")
    print(f"  HIGH={counts['high']}  MEDIUM={counts['medium']}  WATCH={counts['watch']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
