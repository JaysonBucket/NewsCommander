#!/usr/bin/env python3
"""
News Commander — intake_topics.py
Scannt den Teams-Self-Chat seit dem letzten Lauf nach
    "News Commander Topic Add <keyword>"
    "News Commander Topic Drop <keyword>"
und passt data/topics.json entsprechend an.

Dieses Script ist als CLI-Stub gedacht — der eigentliche Scan läuft über
das Cowork-Tool `ListChatMessages(person='me', since=...)` im Morning-
Run-Prompt. Das Script kapselt nur die Mutation-Logik: gegebene Add/Drop-
Strings auf topics.json anwenden, History pflegen.

Usage:
    python intake_topics.py --add "azure openai" --add "gpt-5"
    python intake_topics.py --drop "xbox"
    python intake_topics.py --apply <json_file>   # batch-input

Wenn von Cowork aufgerufen, kommt --apply mit einem temp-JSON, das alle
gefundenen Add/Drop-Statements zusammenfasst:
    {"ts": "...", "operations": [
       {"action": "add", "keyword": "...", "from_message_ts": "..."},
       {"action": "drop", "keyword": "...", "from_message_ts": "..."}
    ]}
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _atomic import atomic_save_json  # noqa: E402

SKILL_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = SKILL_DIR / "data"
TOPICS_FILE = DATA_DIR / "topics.json"
META_FILE = DATA_DIR / "_meta.json"
INTAKE_STATE_FILE = DATA_DIR / ".intake-state.json"

MAX_MUTATIONS_PER_RUN = 20


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    atomic_save_json(Path(path), data)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def slugify(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s[:40] or "untitled"


def find_topic_by_keyword(topics: list[dict], keyword: str) -> dict | None:
    k = keyword.lower()
    for t in topics:
        if any(kw.lower() == k for kw in t["keywords"]):
            return t
    return None


def add_keyword(topics_data: dict, keyword: str, source_meta: str = "user_chat") -> dict:
    topics = topics_data["topics"]
    existing = find_topic_by_keyword(topics, keyword)
    if existing:
        return {"action": "add", "keyword": keyword, "topic_id": existing["id"], "result": "already_present"}
    # Create a new user-topic. We use a stable id derived from the keyword slug.
    tid = f"nc-{slugify(keyword)}"
    if any(t["id"] == tid for t in topics):
        # collision — append the existing one
        existing = next(t for t in topics if t["id"] == tid)
        existing["keywords"].append(keyword)
        return {"action": "add", "keyword": keyword, "topic_id": tid, "result": "appended_to_existing"}
    topics.append({
        "id": tid,
        "label": keyword.title(),
        "keywords": [keyword],
        "weight": 1.0,
        "source": source_meta,
        "added": datetime.now().date().isoformat(),
    })
    return {"action": "add", "keyword": keyword, "topic_id": tid, "result": "created"}


def drop_keyword(topics_data: dict, keyword: str) -> dict:
    topics = topics_data["topics"]
    k = keyword.lower()
    affected: list[str] = []
    removed_topics: list[str] = []
    for t in topics:
        before = len(t["keywords"])
        t["keywords"] = [kw for kw in t["keywords"] if kw.lower() != k]
        if len(t["keywords"]) < before:
            affected.append(t["id"])
    # Remove now-empty topics — but only if source != auto_role (Safeguard)
    survivors = []
    for t in topics:
        if not t["keywords"]:
            if t.get("source") == "auto_role":
                # leave empty auto-topic with a warning marker
                t["_warning"] = "all_keywords_dropped_by_user"
                survivors.append(t)
                continue
            removed_topics.append(t["id"])
            continue
        survivors.append(t)
    topics_data["topics"] = survivors
    return {"action": "drop", "keyword": keyword, "affected_topics": affected, "removed_topics": removed_topics, "result": "dropped" if affected else "not_found"}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--add", action="append", default=[], help="Keyword(s) to add (repeatable)")
    ap.add_argument("--drop", action="append", default=[], help="Keyword(s) to drop (repeatable)")
    ap.add_argument("--apply", help="Batch JSON file from chat scan")
    args = ap.parse_args()

    operations: list[dict] = []
    if args.apply:
        batch = load_json(Path(args.apply))
        if not batch:
            print(f"ERROR: --apply file {args.apply} empty", file=sys.stderr)
            return 1
        operations = batch.get("operations", [])
    else:
        for kw in args.add:
            operations.append({"action": "add", "keyword": kw})
        for kw in args.drop:
            operations.append({"action": "drop", "keyword": kw})

    if not operations:
        print("nothing to do")
        return 0
    if len(operations) > MAX_MUTATIONS_PER_RUN:
        print(f"WARN: {len(operations)} mutations requested, capped to {MAX_MUTATIONS_PER_RUN}", file=sys.stderr)
        operations = operations[:MAX_MUTATIONS_PER_RUN]

    topics_data = load_json(TOPICS_FILE)
    if not topics_data:
        print("ERROR: topics.json missing", file=sys.stderr)
        return 1
    history = topics_data.setdefault("history", [])

    results: list[dict] = []
    for op in operations:
        if op["action"] == "add":
            r = add_keyword(topics_data, op["keyword"])
        elif op["action"] == "drop":
            r = drop_keyword(topics_data, op["keyword"])
        else:
            r = {"action": op["action"], "result": "unknown_action"}
        history_entry = {
            "ts": now_iso(),
            "action": op["action"],
            "keyword": op.get("keyword"),
            "from_message_ts": op.get("from_message_ts"),
            "by": "user_chat",
            "result": r["result"],
        }
        if "topic_id" in r:
            history_entry["topic_id"] = r["topic_id"]
        history.append(history_entry)
        results.append(r)

    save_json(TOPICS_FILE, topics_data)

    # Update intake-state
    intake_state = load_json(INTAKE_STATE_FILE, default={})
    intake_state["last_processed_ts"] = now_iso()
    intake_state["last_run_operations"] = len(operations)
    save_json(INTAKE_STATE_FILE, intake_state)

    # Stats in _meta.json
    meta = load_json(META_FILE, default={})
    stats = meta.setdefault("stats", {})
    add_count = sum(1 for r in results if r["action"] == "add" and r["result"] in ("created", "appended_to_existing"))
    drop_count = sum(1 for r in results if r["action"] == "drop" and r["result"] == "dropped")
    stats["topic_add_events"] = stats.get("topic_add_events", 0) + add_count
    stats["topic_drop_events"] = stats.get("topic_drop_events", 0) + drop_count
    meta.setdefault("last_run", {})["intake_processed_ts"] = now_iso()
    save_json(META_FILE, meta)

    print(f"✓ {add_count} adds, {drop_count} drops applied")
    for r in results:
        print(f"  - {r}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
