#!/usr/bin/env python3
"""
News Commander — archive_items.py
Monats-Archiv-Rotation für data/mirror/items.jsonl.

Strategie:
- Alle 30 Tage ein Lauf (Trigger sitzt in pull_feeds.py via _meta.last_archive_ts).
- Items mit pulled_at >= 90 Tagen werden aus items.jsonl in eine Monats-Tranche
  data/mirror/_archive/items-YYYY-MM.jsonl angehängt (YYYY-MM = Lauf-Monat).
- items.jsonl wird atomar mit nur den behaltenen Items neu geschrieben.
- _meta.last_archive_ts + Stats werden fortgeschrieben.

Crash-Sicherheit:
1. Archiv-Datei zuerst append (idempotenter Append — bei Crash nur evtl. Dupes
   in der Archiv-Tranche, items.jsonl bleibt komplett intakt).
2. Dann items.jsonl atomar neu schreiben (tmp → fsync → replace).
3. Erst danach _meta updaten.
=> Worst case: Items doppelt im Archiv (harmlos, Archiv ist read-only-backup),
   aber niemals Verlust.

Usage:
    python archive_items.py            # nur wenn fällig (>=30d seit last_archive_ts)
    python archive_items.py --force    # immer laufen, unabhängig vom Intervall
    python archive_items.py --min-age-days 60    # andere Altersgrenze
    python archive_items.py --interval-days 14   # andere Lauf-Kadenz
    python archive_items.py --dry-run  # nur zählen, nichts schreiben
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _atomic import atomic_save_json, atomic_write_text  # noqa: E402

SKILL_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = SKILL_DIR / "data"
MIRROR_DIR = DATA_DIR / "mirror"
ARCHIVE_DIR = MIRROR_DIR / "_archive"
ITEMS_FILE = MIRROR_DIR / "items.jsonl"
META_FILE = DATA_DIR / "_meta.json"

DEFAULT_MIN_AGE_DAYS = 90
DEFAULT_INTERVAL_DAYS = 30


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def now_dt() -> datetime:
    return datetime.now(timezone.utc)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def parse_iso(ts: str | None) -> datetime | None:
    if not ts:
        return None
    try:
        s = ts.replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (ValueError, TypeError):
        return None


def is_due(meta: dict, interval_days: int) -> bool:
    last = parse_iso((meta or {}).get("last_archive_ts"))
    if last is None:
        return True
    return (now_dt() - last) >= timedelta(days=interval_days)


def maybe_archive(
    force: bool = False,
    min_age_days: int = DEFAULT_MIN_AGE_DAYS,
    interval_days: int = DEFAULT_INTERVAL_DAYS,
    dry_run: bool = False,
) -> dict:
    """Entry point — sowohl CLI als auch pull_feeds.py rufen das hier auf.
    Returns dict: {ran, reason, archived, kept, archive_file, ...}.
    """
    meta = load_json(META_FILE, default={}) or {}

    if not force and not is_due(meta, interval_days):
        last = meta.get("last_archive_ts")
        return {"ran": False, "reason": f"not_due (last_archive_ts={last})"}

    if not ITEMS_FILE.exists():
        return {"ran": False, "reason": "items.jsonl missing"}

    cutoff = now_dt() - timedelta(days=min_age_days)
    archive_ym = datetime.now().strftime("%Y-%m")
    archive_file = ARCHIVE_DIR / f"items-{archive_ym}.jsonl"

    kept_lines: list[str] = []
    to_archive_lines: list[str] = []
    malformed = 0
    no_pulled_at = 0

    with ITEMS_FILE.open("r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if not stripped:
                continue
            try:
                obj = json.loads(stripped)
            except json.JSONDecodeError:
                malformed += 1
                kept_lines.append(stripped)  # keep malformed → manual review
                continue
            pulled = parse_iso(obj.get("pulled_at"))
            if pulled is None:
                no_pulled_at += 1
                kept_lines.append(stripped)  # ohne Alter kein Archiv
                continue
            if pulled < cutoff:
                to_archive_lines.append(stripped)
            else:
                kept_lines.append(stripped)

    result = {
        "ran": True,
        "ts": now_iso(),
        "archive_file": str(archive_file),
        "items_before": len(kept_lines) + len(to_archive_lines),
        "archived": len(to_archive_lines),
        "kept": len(kept_lines),
        "malformed_kept": malformed,
        "no_pulled_at_kept": no_pulled_at,
        "min_age_days": min_age_days,
        "cutoff_utc": cutoff.isoformat(),
        "dry_run": dry_run,
    }

    if not to_archive_lines:
        result["reason"] = "nothing_to_archive"
        if not dry_run:
            meta["last_archive_ts"] = now_iso()
            stats = meta.setdefault("stats", {})
            stats["total_archive_runs"] = stats.get("total_archive_runs", 0) + 1
            atomic_save_json(META_FILE, meta)
        return result

    if dry_run:
        return result

    # 1) Append to archive file (idempotent — Crash hier hinterlässt nur
    #    halben Archiv-Anhang; items.jsonl unverändert).
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    with archive_file.open("a", encoding="utf-8") as f:
        for line in to_archive_lines:
            f.write(line + "\n")
        f.flush()
        try:
            import os
            os.fsync(f.fileno())
        except OSError:
            pass

    # 2) Rewrite items.jsonl atomically with only the kept lines.
    new_content = "\n".join(kept_lines) + ("\n" if kept_lines else "")
    atomic_write_text(ITEMS_FILE, new_content)

    # 3) Update meta.
    meta["last_archive_ts"] = now_iso()
    stats = meta.setdefault("stats", {})
    stats["total_archive_runs"] = stats.get("total_archive_runs", 0) + 1
    stats["total_items_archived"] = stats.get("total_items_archived", 0) + len(to_archive_lines)
    meta.setdefault("last_run", {})["archive_run_ts"] = now_iso()
    meta["last_run"]["archive_archived_count"] = len(to_archive_lines)
    meta["last_run"]["archive_kept_count"] = len(kept_lines)
    atomic_save_json(META_FILE, meta)

    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true", help="Run regardless of last_archive_ts")
    ap.add_argument("--min-age-days", type=int, default=DEFAULT_MIN_AGE_DAYS,
                    help=f"Items older than this go to archive (default {DEFAULT_MIN_AGE_DAYS})")
    ap.add_argument("--interval-days", type=int, default=DEFAULT_INTERVAL_DAYS,
                    help=f"Min days between runs (default {DEFAULT_INTERVAL_DAYS})")
    ap.add_argument("--dry-run", action="store_true", help="Count only, no writes")
    args = ap.parse_args()

    result = maybe_archive(
        force=args.force,
        min_age_days=args.min_age_days,
        interval_days=args.interval_days,
        dry_run=args.dry_run,
    )

    if not result.get("ran"):
        print(f"⏭  skipped: {result.get('reason')}")
        return 0

    if args.dry_run:
        print(f"DRY-RUN — would archive {result['archived']} items "
              f"(kept {result['kept']}, malformed {result['malformed_kept']}, "
              f"no_pulled_at {result['no_pulled_at_kept']})")
        print(f"  target: {result['archive_file']}")
        return 0

    print(f"✓ archived {result['archived']} items → {result['archive_file']}")
    print(f"  kept {result['kept']} in items.jsonl "
          f"(malformed kept: {result['malformed_kept']}, "
          f"no pulled_at kept: {result['no_pulled_at_kept']})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
