#!/usr/bin/env python3
"""
News Commander — _atomic.py
Atomic-Write-Helper. Schreibt nach tmp-File im selben Verzeichnis, fsynct,
os.replace. Bei Crash mid-write bleibt die Original-Datei unverändert.

Verwendung:
    from _atomic import atomic_save_json, atomic_write_text
    atomic_save_json(path, data)
    atomic_write_text(path, "content")
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any


def atomic_write_text(path: Path, content: str, encoding: str = "utf-8") -> None:
    """Schreibt Text atomar — entweder vollständig oder gar nicht."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_name = tempfile.mkstemp(
        dir=str(path.parent),
        prefix=f".{path.name}.",
        suffix=".tmp",
    )
    try:
        with os.fdopen(tmp_fd, "w", encoding=encoding) as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def atomic_save_json(path: Path, data: Any) -> None:
    atomic_write_text(Path(path), json.dumps(data, indent=2, ensure_ascii=False))
