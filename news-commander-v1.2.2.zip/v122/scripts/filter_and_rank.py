#!/usr/bin/env python3
"""
News Commander — filter_and_rank.py
Topic-Scoring + Dedup + Suggestion-Detection.

Usage:
    python filter_and_rank.py [--since YYYY-MM-DD] [--out data/digests/YYYY-MM-DD.json]

Liest data/mirror/items.jsonl, data/topics.json, data/preferences.json
und data/sources.json. Schreibt einen Digest-Snapshot nach data/digests/.

Digest-Schema:
{
  "date": "2026-05-28",
  "generated_at": "...",
  "counts": {"high": 5, "medium": 4, "watch": 3, "drop": 17, "total_items": 29},
  "high": [<scored_item>...],
  "medium": [...],
  "watch": [...],
  "dedup_log": [{"winner": "item_id", "alias_of": ["item_id", ...]}, ...]
}

scored_item adds: score, matched_topics, matched_keywords, watch_suggestion (if WATCH).
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone, timedelta
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _atomic import atomic_save_json  # noqa: E402

SKILL_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = SKILL_DIR / "data"
MIRROR_DIR = DATA_DIR / "mirror"
DIGESTS_DIR = DATA_DIR / "digests"
ITEMS_FILE = MIRROR_DIR / "items.jsonl"
TOPICS_FILE = DATA_DIR / "topics.json"
PREFS_FILE = DATA_DIR / "preferences.json"
SOURCES_FILE = DATA_DIR / "sources.json"

PRIORITY_BOOST = {"top": 0.5, "high": 0.3, "medium": 0.0, "low": -0.2}
WATCH_THRESHOLDS = {"narrow": 0.7, "normal": 0.5, "wide": 0.3}
WATCH_MAX = {"narrow": 2, "normal": 4, "wide": 6}


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    atomic_save_json(Path(path), data)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def parse_date(s: str) -> datetime | None:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


def load_items() -> list[dict]:
    if not ITEMS_FILE.exists():
        return []
    items = []
    with ITEMS_FILE.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return items


def normalize(text: str) -> str:
    return re.sub(r"[^a-z0-9\s\-+#]", " ", (text or "").lower())


def score_item(item: dict, topics: list[dict], blocklist: list[dict]) -> dict:
    haystack_parts = [
        normalize(item.get("title", "")),
        normalize(item.get("abstract", "")),
        normalize(" ".join(item.get("source_tags", []))),
    ]
    haystack = " ".join(haystack_parts)

    for blk in blocklist:
        if normalize(blk["keyword"]) in haystack:
            return {"score": 0.0, "matched_topics": [], "matched_keywords": [], "blocked_by": blk["keyword"]}

    total_score = 0.0
    matched_topics: list[dict] = []
    matched_keywords: list[str] = []
    for topic in topics:
        hits = 0
        topic_kws: list[str] = []
        for kw in topic["keywords"]:
            nkw = normalize(kw)
            if not nkw:
                continue
            count = haystack.count(nkw)
            if count > 0:
                hits += count
                topic_kws.append(kw)
        if hits > 0:
            topic_score = topic["weight"] * hits
            total_score += topic_score
            matched_topics.append({"id": topic["id"], "label": topic["label"], "hits": hits, "score": round(topic_score, 2)})
            matched_keywords.extend(topic_kws)

    boost = PRIORITY_BOOST.get(item.get("source_priority", "medium"), 0.0)
    total_score += boost

    return {
        "score": round(total_score, 2),
        "matched_topics": matched_topics,
        "matched_keywords": list(dict.fromkeys(matched_keywords)),
        "priority_boost": boost,
    }


def classify(score: float, watch_threshold: float) -> str:
    if score >= 2.0:
        return "high"
    if score >= 1.0:
        return "medium"
    if score >= watch_threshold:
        return "watch"
    return "drop"


def fuzzy_dedup(items: list[dict], threshold: float) -> tuple[list[dict], list[dict]]:
    """Returns (kept, dedup_log)."""
    kept: list[dict] = []
    dedup_log: list[dict] = []
    titles_norm: list[tuple[int, str]] = []  # (kept_index, norm_title)
    for it in sorted(items, key=lambda x: x["score"], reverse=True):
        norm = normalize(it["title"])
        alias_target = None
        for idx, other_norm in titles_norm:
            if SequenceMatcher(None, norm, other_norm).ratio() >= threshold:
                alias_target = kept[idx]
                break
        if alias_target is None:
            kept.append(it)
            titles_norm.append((len(kept) - 1, norm))
        else:
            dedup_log.append({
                "winner_item_id": alias_target["item_id"],
                "winner_title": alias_target["title"],
                "alias_item_id": it["item_id"],
                "alias_title": it["title"],
                "alias_source": it["source_id"],
            })
    return kept, dedup_log


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--since", help="ISO date — only consider items pulled_at >= this")
    ap.add_argument("--out", help="Output digest path (default: data/digests/<today>.json)")
    args = ap.parse_args()

    topics_data = load_json(TOPICS_FILE)
    prefs = load_json(PREFS_FILE)
    items = load_items()

    if not topics_data:
        print("ERROR: topics.json missing", file=sys.stderr)
        return 1
    if not prefs:
        print("ERROR: preferences.json missing", file=sys.stderr)
        return 1

    topics = topics_data["topics"]
    blocklist = topics_data.get("blocklist", [])
    aggressiveness = prefs["filter"].get("suggestion_aggressiveness", "normal")
    watch_threshold = WATCH_THRESHOLDS.get(aggressiveness, 0.5)
    max_age_days = prefs["filter"].get("max_age_days", 30)
    max_high = prefs["filter"].get("max_high_items", 8)
    max_medium = prefs["filter"].get("max_medium_items", 6)
    max_watch = min(prefs["filter"].get("max_suggestion_items", 4), WATCH_MAX.get(aggressiveness, 4))
    dedupe_threshold = prefs["filter"].get("dedupe_fuzzy_threshold", 0.78)

    # Recency filter
    cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
    since_dt = parse_date(args.since) if args.since else None

    recent_items: list[dict] = []
    for it in items:
        pub = parse_date(it.get("pub_date", ""))
        if pub is None:
            continue
        if pub.tzinfo is None:
            pub = pub.replace(tzinfo=timezone.utc)
        if pub < cutoff:
            continue
        if since_dt:
            pulled = parse_date(it.get("pulled_at", ""))
            if pulled and pulled < since_dt:
                continue
        recent_items.append(it)

    # Score
    scored: list[dict] = []
    for it in recent_items:
        s = score_item(it, topics, blocklist)
        if s.get("blocked_by"):
            continue
        item_out = dict(it)
        item_out.update(s)
        item_out["bucket"] = classify(s["score"], watch_threshold)
        scored.append(item_out)

    # Drop unrated
    kept = [s for s in scored if s["bucket"] != "drop"]

    # Dedup
    kept_sorted, dedup_log = fuzzy_dedup(kept, dedupe_threshold)

    # Bucket-split + cap
    high = [s for s in kept_sorted if s["bucket"] == "high"][:max_high]
    medium = [s for s in kept_sorted if s["bucket"] == "medium"][:max_medium]
    watch = [s for s in kept_sorted if s["bucket"] == "watch"][:max_watch]

    # Watch-Suggestion-Decoration
    for w in watch:
        kw = w["matched_keywords"][0] if w["matched_keywords"] else ""
        w["watch_suggestion"] = {
            "topic_hint_keyword": kw,
            "disclaimer": f"Würde mit aktuellen Filtern rausfallen. Treffer: {kw}. Topic adden?",
            "add_command": f"News Commander Topic Add {kw}",
        }

    today = datetime.now().date().isoformat()
    digest = {
        "date": today,
        "generated_at": now_iso(),
        "preferences_snapshot": {
            "channel": prefs["delivery"].get("channel"),
            "aggressiveness": aggressiveness,
            "watch_threshold": watch_threshold,
        },
        "counts": {
            "total_items_seen": len(scored),
            "high": len(high),
            "medium": len(medium),
            "watch": len(watch),
            "deduped": len(dedup_log),
        },
        "high": high,
        "medium": medium,
        "watch": watch,
        "dedup_log": dedup_log,
    }

    out_path = Path(args.out) if args.out else DIGESTS_DIR / f"{today}.json"
    save_json(out_path, digest)
    print(f"✓ digest written: {out_path}")
    print(f"  HIGH={len(high)}  MEDIUM={len(medium)}  WATCH={len(watch)}  (deduped {len(dedup_log)})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
