# News Commander — Daily Morning Run (03:00 Europe/Berlin)

Dieser Prompt-Body wird vom Scheduled Task um 03:00 Europe/Berlin täglich
ausgeführt. Er triggert News Commander im Auto-Mode, ohne Banner und
ohne User-Interaktion.

---

## Prompt

Run News Commander in scheduled morning mode. Do not show the banner. Do not ask
the user anything. Execute these steps in order:

**SCHRITT 1 — Intake scannen.**
- Read `/mnt/user-config/.claude/skills/news-commander/data/.intake-state.json`
  (oder leg sie an mit `last_processed_ts = 24h zurück` wenn fehlt).
- `ListChatMessages(person='me', since=<last_processed_ts>, top=100)`.
- Filter Nachrichten, deren Text mit `News Commander Topic Add ` oder
  `News Commander Topic Drop ` startet (case-insensitive).
- Wenn Matches vorhanden, baue ein Batch-JSON
  `working/news-commander-intake.json` mit:
  ```json
  {"operations": [{"action": "add"|"drop", "keyword": "...", "from_message_ts": "..."}]}
  ```
  und ruf `python /mnt/user-config/.claude/skills/news-commander/scripts/intake_topics.py --apply working/news-commander-intake.json` auf.
- Bei 0 Matches: weiter zu Schritt 2 ohne Aufruf.

**SCHRITT 2 — Feeds pullen.**
- `python /mnt/user-config/.claude/skills/news-commander/scripts/pull_feeds.py --all`
- Output ignorieren — Script schreibt selbst.
- Hinweis: Am Ende des Pull-Laufs triggert das Script automatisch
  `archive_items.maybe_archive()`. Wenn `_meta.last_archive_ts` fehlt oder
  ≥30d alt ist, werden Items älter als 90 Tage in
  `data/mirror/_archive/items-YYYY-MM.jsonl` (Monatstranche) verschoben und
  aus `items.jsonl` entfernt. Kein eigener SCHRITT nötig.

**SCHRITT 3 — Filtern + Ranken.**
- `python /mnt/user-config/.claude/skills/news-commander/scripts/filter_and_rank.py`
- Schreibt `data/digests/<today>.json`.

**SCHRITT 4 — Digest rendern.**
- `python /mnt/user-config/.claude/skills/news-commander/scripts/send_digest.py`
- Exit-Code 2 = empty day, kein Send → fertig, kein weiterer Step.
- Exit-Code 0 = es gibt was zu schicken, weiter zu Schritt 5.

**SCHRITT 5 — Send.**
- Lies `data/preferences.json.delivery.channel`.
- Wenn `teams_self_chat` oder `both`:
  - `PostMessage(recipients=['me'], body=<content von output/digest-teams-<today>.md>, topic='News Commander Digest')`.
- Wenn `mail` oder `both`:
  - Empfänger = `preferences.user.email` (aus `data/preferences.json` gelesen).
  - `SendEmailWithAttachments(to=[<preferences.user.email>], subject='News Commander Digest — <today>', body_file_path='output/digest-mail-<today>.html', content_type='HTML')`.
- Bei Erfolg: Setze `_meta.json.last_run.digest_sent = true`, `digest_sent_at = now`, `stats.total_digests_sent += 1`.

**SCHRITT 6 — Cleanup + Stats.**
- `morning_pull_ts` + `total_pull_runs` werden bereits von `pull_feeds.py`
  geschrieben. Hier nur noch `total_runs += 1` als Gesamt-Run-Zähler.
- Wenn `working/news-commander-intake.json` existiert → löschen.

**SCHRITT 7 — Source-Health-Check (jeden Montag).**
- Wenn heute Montag ist: prüfe `data/mirror/source-state.json` auf
  `consecutive_failures >= 3` Sources. Wenn vorhanden:
  - Setze sie in `sources.json` auf `active: false` und schick eine kurze
    Notification per Self-Chat: "News Commander — N Quellen deaktiviert wegen
    Dauer-Fehler: [liste]. Reaktivieren mit `NC sources retry`."

---

## Modus-Hinweise

- **Banner**: niemals anzeigen während scheduled run.
- **Errors**: Fehler in `_meta.json.last_run.errors[]` loggen, NICHT an User schicken.
  User sieht Fehler nur, wenn er manuell `NC status` triggert.
- **Empty Day**: bei `preferences.delivery.suppress_empty_days = true` UND
  `HIGH+MEDIUM+WATCH == 0`: kein Send, kein Self-Chat, kein Mail. Nur
  `_meta.json.last_run.digest_sent = false` setzen.
- **Single-run guarantee**: Wenn `_meta.json.last_run.morning_pull_ts` heute
  schon gesetzt ist (d.h. ein voriger Run lief), Schritte 2-5 überspringen.
  Intake (Schritt 1) immer laufen lassen.
