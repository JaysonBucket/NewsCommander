# News Commander — Setup

## Voraussetzungen

- Cowork-Workspace mit Personal-Skills-Verzeichnis unter
  `/mnt/user-config/.claude/skills/`
- Python-Pakete: `feedparser`, `beautifulsoup4`. Wenn nicht installiert,
  fallback ist HTML-Scrape ohne BS4 nicht möglich — der Skill skipped dann
  HTML-Quellen und gibt im Log eine Notice aus.
- MCP-Tools im Cowork: `PostMessage`, `SendEmailWithAttachments`,
  `ListChatMessages`, `SetupScheduledPrompt` (kommt mit Standard-Cowork).

## Installation

Die Skill-Dateien liegen bereits unter
`/mnt/user-config/.claude/skills/news-commander/`. Beim ersten Trigger
("News Commander", "NC start", oder einfach das Schedule um 03:00 lassen)
läuft der Onboarding-Flow.

### Schritt-für-Schritt

1. **Sanity-Check** — im Cowork-Chat sagen:
   ```
   News Commander
   ```
   → Banner erscheint (einmal pro Session), dann läuft Onboarding wenn
   `preferences.json.onboarding.completed == false`.

2. **Onboarding** — drei Fragen via Adaptive Card:
   - Channel? (Teams Self-Chat / Mail / Beide)
   - Topic-Init? (Auto aus Rolle / Aus Beispielen lernen / Manuell)
   - Industries? (Alle aus / Bestimmte an)

3. **Scheduled Task anlegen** — direkt nach Onboarding ruft der Skill
   `SetupScheduledPrompt` mit:
   - Name: "News Commander — Daily Morning Run"
   - Frequency: Day, Interval 1, Hours [3], Minutes [0]
   - Execution-Mode: inline
   - Description: Inhalt von `scheduled-prompts/daily-news-run.md`

4. **Optional Outlook-Regel** — wenn Channel = Mail oder Beide:
   ```
   CreateMailRule(
     display_name="News Commander Digest → News-Folder",
     subject_contains=["News Commander Digest"],
     move_to_folder="<News/News Commander/ folder-id>"
   )
   ```

5. **DOPS-Cross-Link** — wenn `daily-ops-ms` installiert:
   - News Commander erkennt es per Glob-Check automatisch.
   - DOPS bekommt zusätzlich den Trigger `DOPS news` → liest letzten Digest.
   - Beide bleiben strikt unabhängig: weder Skill fragt nach dem anderen,
     wenn der jeweils andere fehlt.

## Verzeichnis-Layout

```
news-commander/
├── SKILL.md                          # Skill-Doku + Trigger
├── SETUP.md                          # Diese Datei
├── README.md                         # Public-Facing Overview
├── RELEASE_NOTES.md                  # Versions-Historie + Begründung
├── .gitignore                        # Schließt Runtime-State + preferences.json aus
├── scripts/
│   ├── _atomic.py                    # tempfile+fsync+os.replace (geteilt)
│   ├── pull_feeds.py                 # RSS/Atom + HTML-Scrape, gap-aware Window
│   ├── filter_and_rank.py            # Topic-Score + Dedup + Suggestion
│   ├── intake_topics.py              # Self-Chat Topic Add/Drop
│   ├── archive_items.py              # Monatsrotation Items >90d
│   └── send_digest.py                # Render → output/, Versand via MCP
├── templates/
│   ├── digest-teams.md               # Teams Self-Chat Markdown
│   └── digest-mail.md                # Outlook HTML
├── scheduled-prompts/
│   └── daily-news-run.md             # 03:00 Run Prompt-Body
└── data/
    ├── _meta.json                    # Schema/Version/Stats (gitignored)
    ├── sources.json                  # ~65 Quellen-Katalog (50 aktiv)
    ├── topics.json                   # Topic-Bundles + Blocklist + History
    ├── preferences.example.json      # Template — kopieren nach preferences.json
    ├── preferences.json              # User-Config (gitignored)
    ├── .intake-state.json            # Self-Chat-Scan-State (gitignored)
    ├── mirror/                       # gitignored
    │   ├── items.jsonl
    │   ├── source-state.json
    │   └── _archive/items-YYYY-MM.jsonl
    └── digests/                      # Tagesweise Snapshots (gitignored)
```

## Manuelle Befehle

| Befehl | Wirkung |
|--------|---------|
| `News Commander` | Probelauf mit Banner |
| `NC status` | _meta.json + Stats |
| `NC sources` | Quellenkatalog kompakt |
| `NC topics` | Topics + Weights |
| `NC topic add <keyword>` | Topic-Add inline |
| `NC topic drop <keyword>` | Topic-Drop inline |
| `NC digest` | Letzten Digest zeigen |
| `NC pause` | Scheduled Prompt pausieren |
| `NC resume` | Scheduled Prompt aktivieren |
| `DOPS news` | (wenn DOPS installiert) Letzten Digest |

## Troubleshooting

- **Kein Digest um 03:00**: Check `data/_meta.json.last_run.errors[]`.
  Häufigste Ursache: feedparser fehlt → `pip install feedparser`.
- **Empty Day obwohl Items kamen**: Topics zu eng. Aggressiveness auf `wide`
  setzen oder mehr Topics via `NC topic add` ergänzen.
- **Doppelte Items im Digest**: dedupe_fuzzy_threshold zu hoch.
  In `preferences.json` auf 0.72 senken (mehr Dedup).
- **Source dauerhaft tot**: `data/mirror/source-state.json` zeigt
  `consecutive_failures >= 3` → wird automatisch montags deaktiviert.
- **Banner erscheint trotz Scheduled Run**: Bug — bitte melden.
  Scheduled Runs sollen NIE Banner zeigen.

## Reset

Wenn alles neu aufgesetzt werden soll:
```
News Commander reset
```
- Löscht `data/mirror/`, `data/digests/`, `data/.intake-state.json`
- Setzt `_meta.json.last_run` zurück
- LÄSST `data/topics.json` und `data/preferences.json` stehen
- Onboarding wird NICHT erneut erzwungen
