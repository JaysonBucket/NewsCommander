# 📰 News Commander — {{date}}

_{{counts.high}} HIGH · {{counts.medium}} MEDIUM · {{counts.watch}} Vorschläge · {{counts.deduped}} dedupliziert_

---

## 🔥 HIGH

{{#each high}}
**{{@index1}}. [{{title}}]({{url}})**
   _{{source_title}}_ · Score {{score}} · Treffer: {{matched_keywords_joined}}
   > {{abstract}}
   🔗 [Vollständiger Artikel öffnen]({{url}})


{{/each}}

---

## 📌 MEDIUM

{{#each medium}}
**{{@index1}}. [{{title}}]({{url}})**
   _{{source_title}}_ · Score {{score}} · Treffer: {{matched_keywords_joined}}
   > {{abstract}}
   🔗 [Vollständiger Artikel öffnen]({{url}})


{{/each}}

---

## 💡 Vorschläge — knapp unter Filter

{{#each watch}}
**{{@index1}}. [{{title}}]({{url}})**
   _{{source_title}}_
   💡 Würde mit aktuellen Filtern rausfallen. Treffer: `{{watch_suggestion.topic_hint_keyword}}`. Topic adden?
   → `{{watch_suggestion.add_command}}`
   🔗 [Vollständiger Artikel öffnen]({{url}})


{{/each}}

---
_Generated {{generated_at}} · Topic adden via `News Commander Topic Add <keyword>` · Topic droppen via `Drop`_
