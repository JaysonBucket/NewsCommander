<html>
<body style="font-family:-apple-system,Segoe UI,sans-serif;max-width:720px;margin:0 auto;padding:16px;line-height:1.4;color:#222">

<h1 style="border-bottom:2px solid #0078d4;padding-bottom:8px;margin-bottom:4px">📰 News Commander — {{date}}</h1>
<p style="color:#666;margin-top:4px">{{counts.high}} HIGH · {{counts.medium}} MEDIUM · {{counts.watch}} Vorschläge · {{counts.deduped}} dedupliziert</p>

<hr style="margin:36px 0;border:none;border-top:1px solid #ddd"/>

<!-- HIGH-Block -->
<h2 style="color:#d83b01;margin-bottom:18px">🔥 HIGH</h2>
{{#each high}}
<div style="margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid #eee">
  <div style="font-size:15px"><strong>{{@index1}}. <a href="{{url}}" style="color:#0078d4;text-decoration:none">{{title}}</a></strong></div>
  <div style="color:#666;font-size:13px;margin-top:4px">{{source_title}} · Score {{score}} · Treffer: {{matched_keywords_joined}}</div>
  <div style="color:#444;margin-top:8px;font-style:italic;line-height:1.5">{{abstract}}</div>
  <div style="margin-top:10px"><a href="{{url}}" style="color:#0078d4;font-size:13px;text-decoration:none">🔗 Vollständiger Artikel öffnen →</a></div>
</div>
{{/each}}

<hr style="margin:36px 0;border:none;border-top:1px solid #ddd"/>

<!-- MEDIUM-Block -->
<h2 style="color:#0078d4;margin-bottom:18px">📌 MEDIUM</h2>
{{#each medium}}
<div style="margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid #eee">
  <div style="font-size:15px"><strong>{{@index1}}. <a href="{{url}}" style="color:#0078d4;text-decoration:none">{{title}}</a></strong></div>
  <div style="color:#666;font-size:13px;margin-top:4px">{{source_title}} · Score {{score}} · Treffer: {{matched_keywords_joined}}</div>
  <div style="color:#444;margin-top:8px;font-style:italic;line-height:1.5">{{abstract}}</div>
  <div style="margin-top:10px"><a href="{{url}}" style="color:#0078d4;font-size:13px;text-decoration:none">🔗 Vollständiger Artikel öffnen →</a></div>
</div>
{{/each}}

<hr style="margin:36px 0;border:none;border-top:1px solid #ddd"/>

<!-- WATCH/Vorschläge-Block -->
<h2 style="color:#b56500;margin-bottom:18px">💡 Vorschläge — knapp unter Filter</h2>
{{#each watch}}
<div style="margin-bottom:24px;padding:14px;background:#fff8e1;border-left:3px solid #ffb300;border-radius:3px">
  <div style="font-size:15px"><strong>{{@index1}}. <a href="{{url}}" style="color:#0078d4;text-decoration:none">{{title}}</a></strong></div>
  <div style="color:#666;font-size:13px;margin-top:4px">{{source_title}}</div>
  <div style="margin-top:8px;font-size:13px">💡 Würde mit aktuellen Filtern rausfallen. Treffer: <code>{{watch_suggestion.topic_hint_keyword}}</code>. Topic adden?</div>
  <div style="margin-top:4px;font-size:12px;font-family:monospace;color:#555">→ {{watch_suggestion.add_command}}</div>
  <div style="margin-top:10px"><a href="{{url}}" style="color:#0078d4;font-size:13px;text-decoration:none">🔗 Vollständiger Artikel öffnen →</a></div>
</div>
{{/each}}

<hr style="margin:36px 0;border:none;border-top:1px solid #ddd"/>

<p style="color:#999;font-size:12px">Generated {{generated_at}} · Topic adden via <code>News Commander Topic Add &lt;keyword&gt;</code> · Topic droppen via <code>Drop</code></p>

</body>
</html>
