# News Commander — Release Notes (English)

> German version: [`RELEASE_NOTES.md`](RELEASE_NOTES.md)

## Why this skill exists

### The challenge

Anyone working professionally with the Microsoft ecosystem — Cloud Architect,
Consultant, Modern-Work Specialist, Security Engineer, or similar — knows the drill:

- **~50 relevant RSS/Atom feeds** across the Microsoft universe (blog.microsoft.com,
  techcommunity.microsoft.com, devblogs, learn.microsoft.com/updates, Roadmap feeds,
  Security updates, industry blogs). Plus tech Twitter, plus newsletters, plus
  YouTube channels.
- **Heavy redundancy.** A single Defender announcement shows up in parallel on the
  Tech Community board, the Microsoft Blog, the Security Blog, and sometimes the
  Roadmap feed — same content, four sources, four clicks to "already read it".
- **No topic focus.** RSS readers sort chronologically. But you don't want
  everything — you want *"what's new today on Defender XDR, Copilot, Azure OpenAI,
  Entra ID?"* The things you're tracking **right now**.
- **Shifting focus over time.** Today you're tracking GPT-5 rollouts; in three
  months it's Copilot Agents; in six months something else entirely. Maintaining
  filters across five tools? Nobody does it.
- **Doom-scroll risk.** Open the reader in the morning and you lose 30 minutes.
  Don't open it and you fall behind.
- **Newsletter spam days.** Some days simply have nothing. Inbox still full.
  Push notifications still firing. The vague sense of missing something stays.

The problem isn't a lack of information. It's **poor signal-to-noise ratio and
missing personalization** to what the role actually needs.

### The approach

News Commander flips the logic:

1. **Topic-centric, not source-centric.** You define topic bundles
   (Defender, Copilot, Azure OpenAI, Roadmap, …) with weights. Every item gets a
   score = Σ (topic weight × keyword hits). Digest order reflects *your* interests,
   not publication date.

2. **Aggressive deduplication.** SequenceMatcher-based fuzzy title matching
   (threshold ≥0.78) catches cross-posts between TC boards and Microsoft blogs.
   You see each announcement once, from the best source.

3. **Three buckets instead of a flood.** HIGH (score ≥2.0) → top of digest.
   MEDIUM (≥1.0) → solid context. **Suggestions** (just below the filter, ≥0.5)
   → *"would this be relevant? Want to add the topic?"*. The last bucket is the
   most honest feature: it shows you what you almost missed.

4. **Self-tunable via chat.** `News Commander Topic Add gpt-5` in the Teams
   self-chat is enough. The next run reads the message, mutates `topics.json`,
   done. No settings UI, no redeploy, no *"think first, configure later"*.

5. **Empty-day suppress.** Nothing important today? Then **nothing** gets sent.
   No empty mail, no "0 items" push. Silence is also an answer.

6. **One-shot channel.** Exactly **one** message in the morning. Teams self-chat,
   mail, or both. Push notification instead of app toggle.

### What you get out of it

| Before | With News Commander |
|--------|---------------------|
| 50 RSS tabs to click through | 1 digest, done in 3 minutes of reading |
| Same Defender news across 4 sources | One copy, deduplicated |
| "What's new on topic X today?" → three searches | Topic score answers it |
| Filter maintenance in reader UI | `Topic Add <keyword>` in self-chat |
| Inbox spam on quiet days | Empty-day suppress |
| News-FOMO without a plan | Structured morning briefing |

Concretely: **3–5 minutes of reading, once a day, everything important inside,
nothing twice.**

### Architectural decisions that mattered

- **Atomic writes.** Every JSON/JSONL write goes through tempfile + fsync +
  `os.replace`. A crash mid-write cannot corrupt state. Important because the
  skill runs daily and is never manually supervised.
- **Append-only mirror.** `items.jsonl` is only appended, never rewritten
  (except during archive rotation). The history stays reconstructable.
- **Monthly archive with crash-safe write order.** Items older than 90 days are
  moved to `_archive/items-YYYY-MM.jsonl` every 30 days — but in an order where
  a crash during rotation can at worst produce duplicates in the archive, never
  data loss. Write order: (1) archive append + fsync, (2) atomic rewrite of
  `items.jsonl`, (3) meta update.
- **Gap-aware pull window.** If the last run was missed, the next run
  automatically extends the window — nothing slips through.
- **Per-source health tracking.** Three consecutive failures → auto-deactivation
  on Monday, with a self-chat notification. Dead feeds die quietly; you find
  out once a week instead of never or constantly.
- **Cross-skill integration is optional and read-only.** Other skills can read
  the latest digest but cannot write. If News Commander is missing, they keep
  working unchanged.

---

## v1.2.2 — Source-Discipline Guardrail v2

Patch release driven by direct user feedback. In v1.2.1 the skill answered a
generally-phrased events question ("what Copilot Agents events are coming up in
the next 60 days?") with a top-10 list in which 5 of 10 entries came from open
web search (3rd-party trainings like Roedl & Partner, U2U, affinis, Live! 360) —
and therefore **not from the curated catalog**. The v1.1.2 HARD RULE "Source
Discipline" failed in that moment because the user had not used an NC trigger
and the rule could be read as applying only to direct NC invocations. v1.2.2
closes that loophole.

### Changed

- **Scope clarification in `SKILL.md`** — new subsection "When this rule
  applies (Scope)". Source discipline now explicitly governs **every** question
  whose answer could plausibly come from the MS news/events/roadmap/product
  space — even without a `News Commander` trigger word, even in seemingly
  harmless follow-ups, even when the user phrases the question generically.
  Concrete examples are documented in the rule itself. Rule of thumb: *"Could
  the question plausibly be answered from a Microsoft source?"* → if yes, apply
  the rule.

- **Pre-Answer Checklist is mandatory** — new subsection in `SKILL.md`. Before
  sending a response that falls under source discipline, the skill walks
  through 5 checkpoints: Scope check, Grounding check (every claim maps to a
  `source_id` in `data/sources.json`), Pretraining check, External check,
  Provenance check. If even one fails → response is not sent; instead the gap
  is disclosed openly and Rule 3 applies (exactly ONE `AskUserQuestion`).

- **Labeled Provenance is mandatory** — new subsection in `SKILL.md`. Every
  individually listed statement (event, item, roadmap entry, announcement)
  ends with a `Quelle: <source_id>` tag from v1.2.2 onward. Catalog items
  carry the `source_id`; live fetches against catalog URLs use `Quelle:
  <source_id> (live)`; items from a one-time user-authorized web research
  carry the marker tag `Quelle: [external] <origin>` — the user sees at a
  glance what is curated and what is not. Pretraining-based statements — if
  ever accepted — run under `Quelle: [pretraining, unverifiziert]`.

- **Override clause vs. system defaults** — the scope clarification is
  explicitly an override of the general "action bias / look up before you
  answer" defaults in the host system prompt as soon as the topic is MS news /
  events / roadmap. In those cases the skill must NOT "proactively improve the
  answer" by quietly researching externally. That was the mechanism that broke
  v1.1.2.

- **`USER_AGENT`** → `NewsCommander/1.2.2`. Side note: the placeholder host
  `example.invalid` was replaced by `https://jaysons.dev` (previous releases
  shipped `example.invalid` as the default — that is now the skill's homepage
  in plain text).

- **Banner subtitle** — new v1.2.2 lines about Guardrail v2 and Labeled
  Provenance directly in the ASCII banner subtitle.

### Not changed

- No schema change in `sources.json` (`_schema.version` stays 1.0.0). The
  catalog itself, all 42 active sources, all tags, all categories remain
  identical to v1.2.1. v1.2.2 is a pure policy tightening.
- No change to Python scripts outside the UA constant. Pull, filter, rank,
  send all work identically.
- `_schema.categories` unchanged (18-category vocabulary from v1.2.1).

### Migration v1.2.1 → v1.2.2

**No schema migration, no mirror rotation, no re-pull required.**

- `item_id = sha1(source_id+url)[:16]` stays stable.
- `items.jsonl`, `topics.json`, `_meta.json`, `preferences.json`,
  `source-state.json` remain valid unchanged.
- The next manual trigger loads the new `SKILL.md` and with it the tightened
  Guardrail v2 — no further action needed.
- To test the curated-source enforcement in the Pre-Answer Checklist: ask an
  implicit events question ("what Copilot events are running this week?") and
  verify the skill returns only items from `adoption-customer-hub`,
  `msft-de-events`, `techwiese-events` etc. — or openly reports that nothing
  in the catalog matches and asks for clearance via `AskUserQuestion`.

---

## v1.2.1 — Category Audit + Tag Enrichment

Smaller release based on a content audit of all 42 active sources. Three
themes: (1) **Four new categories** derived from actual content rather than
force-fit into existing buckets — `identity-iam`, `agents-core`, `browser-web`,
`windows-tooling`; (2) **Four re-buckets** (`tc-entra` → identity-iam,
`agents-hub` → agents-core, `edge-blog` → browser-web, `tc-sysinternals` →
windows-tooling); (3) **19 sources enriched with product tags**
(copilot-in-excel, defender-xdr, copilot-studio, agent-builder, mcp,
ai-foundry, …) so topic scoring also hits on substring matches against tags —
categories remain a secondary lookup index, the primary signal is and stays
the topic score over title + abstract + tags.

### New categories

| Category | Why | Source(s) |
|----------|-----|-----------|
| `identity-iam` | Entra / Identity is its own domain, not generic security | tc-entra |
| `agents-core` | Agents / MCP / Agent Builder as standalone topic, not a dev subset | agents-hub |
| `browser-web` | Edge Copilot mode + agentic browsing needs its own bucket | edge-blog |
| `windows-tooling` | Sysinternals is tooling, not a dev platform | tc-sysinternals |

### Re-buckets (4)

- `tc-entra` — security → **identity-iam** (content is pure IAM)
- `agents-hub` — dev-platform → **agents-core** (Learn hub for Agent
  Framework / MCP)
- `edge-blog` — windows → **browser-web** (Copilot mode + browser roadmap)
- `tc-sysinternals` — dev-platform → **windows-tooling** (troubleshooting
  tools)

### Tag enrichment (19 sources)

New product-near substring tags to improve scoring hit rate — without
elevating category to the primary filter:

- `techwiese-events`, `techwiese-aktuell` — DE community / events plus
  Azure / Foundry / Agents
- `news-signal`, `microsoft-ai-news` — strategy / AI chair-CTO,
  Azure OpenAI, Copilot Studio
- `on-the-issues` — EU Data Boundary, DMA, AI Act
- `tc-m365copilot`, `m365-blog`, `m365-dev-blog`, `m365-roadmap`,
  `tc-m365blog` — Copilot Chat, Business Chat, Loop, Clipchamp, Designer,
  Outlook, Teams, Graph API, Teams Toolkit, Copilot Extensibility, Agents,
  Agent Builder, Purview, Viva
- `tc-excel`, `tc-outlook`, `tc-teams`, `tc-sharepoint`, `tc-eos` —
  Copilot-in-Excel, Python-in-Excel, Copilot-in-Outlook, New Outlook, Teams
  Rooms, Teams Premium, Copilot-in-Teams, Copilot-in-SharePoint, Syntex,
  Lists, Windows-10-EOS, Office-2019/2021-EOS, M365 Apps
- `tc-security`, `security-blog`, `msrc-blog`, `sec-advisories` —
  Defender XDR, Sentinel, Purview, Defender for Cloud, Copilot for Security,
  CVE, Patch Tuesday
- `tc-entra` — Entra ID, Conditional Access, Verified ID, External ID,
  Privileged Identity
- `vs-blog`, `powershell-blog`, `tc-mechanics`, `tc-sysinternals`,
  `agents-hub`, `azure-updates` — Agents, Copilot, PowerShell Gallery,
  cross-workload tech deepdives, Fabric, AI Foundry, Arc, Process Explorer,
  Procmon, Autoruns, MCP, Agent Framework
- `pp-blog`, `pp-apps`, `pp-automate` — Copilot Studio, Agent Builder, MCP,
  Dataverse, Canvas, AI Builder, Cloud Flows, Desktop Flows
- `edge-blog` — agentic browsing, Copilot mode, WebView2, PWA, Manifest V3
- `adoption-portal`, `adoption-release` — events, webinars, training
  (adoption portal links to events / webinars / trainings)
- `msft-de-events`, `adoption-customer-hub` — already introduced as event
  sources in v1.2.0, now tag-consolidated (Copilot, Copilot Chat, Agents,
  Adoption, Training, Events)

### Design decision — categories stay a secondary index

A clear user feedback in the audit: categories must not become the primary
filter, because content shifts (`vs-blog` increasingly carries Copilot /
Agents content) and category-based filtering would then blank exactly the
items the user actually wants. Consequence of the audit:

- Categories are purely a **lookup aid** (source listing, status display, ad
  hoc filters like "security sources only").
- Topic scoring still runs over **title + abstract + tags**
  (`sources.json[item.source_id].tags` as a substring pool).
- Hence tag enrichment instead of a category multiplier. If e.g.
  `copilot-in-excel` matches as a substring against a topic keyword, the tag
  carries the score — regardless of which category the source belongs to.

### Changed

- **`_schema.categories`** in `sources.json` — 4 new categories added
  (`identity-iam`, `agents-core`, `browser-web`, `windows-tooling`).
- **`_schema.version`** optionally 1.0.0 → 1.0.1 (schema fields unchanged,
  only category vocabulary extended).
- **`USER_AGENT`** → `NewsCommander/1.2.1`.
- **`SKILL.md`** frontmatter, banner subtitle (new v1.2.1 lines) and heading
  bumped to v1.2.1.

### Migration v1.2.0 → v1.2.1

**No schema migration required, no mirror rotation, no re-pull required.**

- `item_id = sha1(source_id+url)[:16]` stays stable — re-bucketing and tag
  enrichment touch neither `source_id` nor URL convention.
- `items.jsonl` needs neither rewrite nor archive rotation.
- Existing `topics.json`, `_meta.json`, `preferences.json`,
  `source-state.json` stay valid unchanged.
- The next pull run reads the extended tags directly from `sources.json` and
  uses them from the first new item onward in scoring — old items keep their
  prior scores; this is intentional (no retroactive re-scoring).

---

## v1.2.0 — Source Catalog Cleanup + Parallel Pull + More JSON APIs

Mid-sized release based on real-test feedback and source validation. Three
themes: (1) **Source hygiene** — 6 permanently broken sources kicked out
instead of carrying them around in the active catalog; (2) **More official
JSON APIs** — MSRC Security Updates and Azure Updates are now pulled via the
official Release Communications / CVRF endpoints in the same style as the
M365 Roadmap, instead of fragile HTML scraping; (3) **Pull phase
parallelized** — `ThreadPoolExecutor` with 10 workers reduces the run from
~80s (sequential, 40 sources × TIMEOUT=20s worst case) to ~10-15s.

### Removed (6 sources)

Sources that delivered zero items in the validation pass (out-of-skill via
`web_fetch`) — either defunct, renamed, or unreachable from the container.
Rather than continuing to poll them and racking up `consecutive_failures`,
now explicitly removed and documented in `removed[]` in `sources.json`:

| Source | Reason |
|--------|--------|
| `techwiese-itpro` | Feed returns only `<title>Microsoft</title>`, no items — defunct |
| `tc-copilot-studio` | TechCommunity board.id 404 — board presumably renamed; manual rediscovery needed |
| `tc-copilot-events` | HTML events page no longer returns a parseable listing |
| `tc-planner` | TechCommunity board.id 404 — board renamed |
| `tc-skills-hub` | TechCommunity board.id 404 — board renamed |
| `amc-rss` (`aka.ms/AMC/RSS`) | Auth wall, unreachable from container; replaced by `_placeholder_internal` slot |

The active catalog shrinks from 46 to 40 sources — cleaner signal, less noise
in source health logs.

### New

- **MSRC Security Updates via CVRF v3.0 JSON API** — New source
  `sec-advisories` with `feed_type: "json_msrc_cvrf"` now pulls
  `https://api.msrc.microsoft.com/cvrf/v3.0/updates`. Response has top-level
  `value: [...]` with `ID`, `DocumentTitle`, `CurrentReleaseDate`,
  `InitialReleaseDate`. Per-item URL via template
  `https://msrc.microsoft.com/update-guide/releaseNote/{ID}`. Delivers the
  monthly Patch Tuesday releases as clean items with a reliable date.
- **Azure Updates via official JSON API** — `azure-updates` with new
  `feed_type: "json_azure_updates"` and endpoint
  `https://www.microsoft.com/releasecommunications/api/v1/azure`. Same field
  schema as the M365 Roadmap parser, per-item URL via
  `https://azure.microsoft.com/en-us/updates?id={id}`. More stable than the
  previous marketing-page scrape.
- **`PULL_PARALLELISM = 10`** — New constant in `pull_feeds.py`. Pull phase
  now runs in a `ThreadPoolExecutor(max_workers=10)` instead of sequentially.
  Thread safety holds because (a) each worker handles one distinct
  `source_id` (no state collision), (b) `item_id = sha1(source_id+url)[:16]`
  is by definition source-scoped (no cross-worker dedup needed), (c)
  `existing_ids` passed as a read snapshot and finally deduped in the main
  thread, (d) file writes (`append_items`, `save_json`) stay sequential in
  the main thread. Defensive per-worker `try/except` so a single source
  crash doesn't take down the pool. Elapsed time is logged at the end for
  performance monitoring.

### Changed

- **`USER_AGENT`** → `NewsCommander/1.2.0`.
- **`source-state.json`** — 6 orphan entries for the removed sources cleared
  out (39 health entries instead of 45).
- **Banner subtitle** — new v1.2.0 lines on source cleanup, Azure / MSRC
  JSON APIs and pull parallelization.

### Migration v1.1.3 → v1.2.0

No schema migration needed. Existing `items.jsonl`, `topics.json`,
`_meta.json`, `preferences.json` stay valid unchanged. Mirror dedup hashes
(`item_id`) are stable because neither `source_id` nor URL convention
changed for the remaining sources. `source-state.json` may contain orphans
for the 6 removed sources — they are ignored by the next run; the v1.2.0
cleanup additionally removed them.

For anyone who ran Azure Updates or MSRC Advisories as RSS / HTML scrape
sources before v1.2.0: the new JSON sources produce their own `item_id`
hashes (different URL pattern), so the first runs after upgrade may
temporarily produce duplicates against old mirror entries until the old
ones reach >90 days and rotate into `_archive/`. For strict dedup
requirements: manually grep the old items out of `items.jsonl` before the
first v1.2.0 run.

---

## v1.1.3 — Roadmap-API + Link-Hardening Patch

Small patch release driven by real-use feedback. In v1.1.2 a test run surfaced two issues: (a) the M365 Roadmap source returned effectively no items (React SPA — HTML scraping can't extract per-item hrefs), and (b) several digest items rendered without a clickable link, especially Roadmap entries and event listings. Both are fixed now, without breaking mirror state.

### Changed

- **M365 Roadmap via official JSON API** — Replaces the previous HTML scrape (`https://www.microsoft.com/en-us/microsoft-365/roadmap`) with the public release-communications endpoint `https://www.microsoft.com/releasecommunications/api/v2/m365`. A new `feed_type: "json_m365_roadmap"` parses the API response (top-level list OR wrapper dict with `value`/`items`/`results`/`data`), extracts `id`, `title`, `description`, `modified`/`created`, and builds the per-item URL via the template `https://www.microsoft.com/microsoft-365/roadmap?id={id}`. Roadmap items now reliably carry title, abstract, date, and a direct link.
- **Link-hardening: source-URL fallback with visible hint** — In the render path (`send_digest.py`), a new `effective_url(item)` helper validates the item URL at send time (must be `http(s)://`, not a bare anchor, not `javascript:`/`mailto:`). If invalid, rendering falls back to `source_url` (source page) and adds an explicit ⚠️ _Direktlink fehlt — Fallback auf Quellenseite_ hint plus a separate "🔗 Zur Quelle (<Source>)" line. The user sees instantly that the click leads to the index page, not the article. No more silent dead-end clicks.
- **Strict URL validation** — A new `is_valid_url()` helper (duplicated in `pull_feeds.py` and `send_digest.py` for module independence) reliably blocks pseudo-links (bare anchor, `javascript:`, `mailto:`).
- **`source_url` field per item** — New optional key in the mirror item schema (`source_url: <source homepage>`), needed for the render-time fallback. Populated at pull time from `sources.json[item.source_id].url`.
- **Render-time validation instead of pull-time drop** — Deliberate design: `item_id = sha1(source_id + url)[:16]` stays stable because URL validation happens at render time only. Mirror dedup hashes never shift, even if a per-item link turns out broken later.
- **Banner subtitle extended with v1.1.3 lines** — New notes about the Roadmap API and the link-hardening directly in the ASCII banner.

### Migration v1.1.2 → v1.1.3

No schema migration required. Items already in `items.jsonl` without `source_url` are rendered without the fallback mechanic (old items behave as before). New items written from v1.1.3 onward automatically carry `source_url`. Mirror dedup hashes stay stable. Existing `topics.json`, `source-state.json`, `_meta.json`, `preferences.json` remain valid unchanged.

One `sources.json` change is required: the `m365-roadmap` source switches to `feed_url: "https://www.microsoft.com/releasecommunications/api/v2/m365"` and `feed_type: "json_m365_roadmap"`. The shipped v1.1.3 `sources.json` already contains the update.

---

## v1.1.2 — Source-Discipline Patch

Small patch release driven by real-use feedback. In v1.1.1, on one follow-up question, the skill autonomously enriched its answer with content from the open web that did not come from the curated sources. That is exactly what News Commander must not do: it is a triage system over a curated source list, not a generic web researcher.

### Changed

- **New HARD RULE "Source Discipline" in `SKILL.md`** — the skill operates exclusively on `data/sources.json` and `data/mirror/items.jsonl`. External tools (`web_search`, `web_fetch`, `deep-research`, `SearchM365` for news lookups) are **forbidden by default** unless the user explicitly authorizes them for the current question.
- **Explicit ask on gaps** — When mirror data cannot answer a user question, the skill MUST issue exactly one `AskUserQuestion` offering: (a) research externally, (b) stay within the defined sources, or (c) add a topic and wait for the next pull. Only after an explicit "yes" do web tools fire — and only for that one question, not as a standing permission.
- **Pre-training knowledge is not presented as a source** — If the skill "knows" something that is not in the mirror, it must not present it as if it came from the curated sources. Either mark it as uncertain AND ask, or omit it.
- **Startscreen banner extended with skill description** — Mirroring the AccountRadar startscreen, the banner now includes short documentation (what it pulls, filter logic, buckets, delivery) plus an explicit v1.1.2 line noting that source discipline is now a HARD RULE. Footer: "More Playful AI at https://jaysons.dev".

### Migration v1.1.1 → v1.1.2

No file or schema migration needed. Only `SKILL.md` (new HARD RULE + banner) and `README.md` / release notes change. Existing `items.jsonl`, `topics.json`, `source-state.json`, `_meta.json`, `preferences.json` remain valid unchanged.

---

## v1.1.1 — Usability Patch

Small patch release based on real-use feedback. Content and architecture identical
to v1.1.0; three usability fixes:

### Changed

- **Banner display is now a HARD RULE.** The ASCII-art banner is mandated as the
  first output of every manual trigger response (before any other text, before
  any tool calls). In v1.1.0 the banner occasionally didn't show on user
  triggers; this is fixed.
- **Explicit "open full article" link per item.** Every item in the digest now
  has a dedicated call-to-action link to the full article, in addition to the
  title-as-link. Applies to both the Teams self-chat Markdown and the HTML mail
  render.
- **More breathing room between topic blocks.** Section dividers (`---`) between
  counts and HIGH/MEDIUM/WATCH blocks, double blank lines between items in
  Markdown. In HTML mail: larger `<hr>` margins (36px), item containers with
  28px bottom margin + border, abstract with line-height 1.5.

### Migration v1.1.0 → v1.1.1

No migration needed. Template and render changes plus SKILL.md header only.
Existing `items.jsonl`, `topics.json`, `source-state.json`, `_meta.json` stay
valid.

---

## v1.1.0 — Community Release

First fully public community release. Bundles all v0.2.0 features in a packaged
state, adds consistency and performance hardening, ships as a ZIP.

### New

- **Public-repo ready.** Skill is fully scrubbed — no internal paths, mail
  addresses, names, or tenant IDs. All user data lives in `data/preferences.json`
  (gitignored). The template `data/preferences.example.json` is copy-and-edit-ready.

- **Hardened cross-skill integration.** Optional, read-only hooks for
  `daily-ops-ms`, `account-radar`, and `fasttrack`/`fasttracker`. Detection is
  silent and miss-silent — if the other skill isn't installed, News Commander
  runs unchanged. No question, no noise.

- **Consistency audit passed.** All Python scripts py_compile-clean. All JSONs
  valid. Cross-references (SKILL.md ↔ scheduled-prompts ↔ scripts ↔ data/) are
  consistent against the v1.1 layout.

- **Performance audit passed.** Scoring loop is linear over recent items × topics
  × keywords. Fuzzy dedup is O(n²) but bounded by bucket survivors (n<30 in
  practice, <100 ms). Archive rotation is a single linear scan. All file writes
  atomic.

### Changed from v0.2.0

- **Versioning.** Skill level is now v1.1.0 (frontmatter, banner, headings) —
  a semantic signal that the API and file structure are stable and ready for
  community adoption.
- **User-Agent string** in `pull_feeds.py` bumped to `NewsCommander/1.1` for
  source-side traceability.
- **Documentation.** The cross-skill integration table in `SKILL.md` now covers
  all three consumers (instead of only DOPS). The file-structure tree reflects
  the atomic-writes module, archive rotation, and the template file.

### Known limits (unchanged from v0.2.0)

- One schedule instance per skill.
- No cross-tenant tagging (multi-customer workflows are targeted no earlier
  than v1.3).
- HTML scraping is fragile; health tracking catches the failure mode, but a
  manual selector update is still needed when a source redesigns.

### Migration v0.2 → v1.1

No code migration needed. Pure version re-labeling plus community hardening.
Existing `items.jsonl`, `topics.json`, `source-state.json`, `_meta.json` stay
valid.

---

## v0.2.0 — Initial Public Release

### New

- **Atomic write module (`_atomic.py`).** Shared module for the tempfile + fsync
  + `os.replace` pattern, exposed as `atomic_save_json()` and `atomic_write_text()`.
  Used by all four mutation scripts (`pull_feeds`, `filter_and_rank`,
  `intake_topics`, `send_digest`) plus `archive_items`.

- **Monthly archive rotation (`archive_items.py`).** Every 30 days, items older
  than 90 days are moved to `data/mirror/_archive/items-YYYY-MM.jsonl`. Crash-safe
  write order: archive append → items.jsonl rewrite → meta update. Worst case is
  a duplicate in the archive, never data loss. Cadence and minimum age are
  override-able via CLI flags (`--interval-days`, `--min-age-days`).

- **Auto-trigger in `pull_feeds.py`.** At the end of every pull,
  `archive_items.maybe_archive()` is called automatically. No separate schedule,
  no cron entry. Errors in the archive step are explicitly non-fatal — pull stays
  green even if rotation crashes.

- **Gap-aware pull window.** `compute_window_start()` checks
  `_meta.last_run.morning_pull_ts`. If the last successful run is >36h in the
  past (schedule down, manual skip), the window expands to
  `(now − last_run) + 6h overlap`. Missed items get picked up.

- **Per-source health tracking.** `data/mirror/source-state.json` tracks
  `last_pull_ts`, `last_status` (`working` / `empty` / `failing`), and
  `consecutive_failures` per source. After 3 consecutive failures, the source
  is automatically deactivated on the next Monday with a self-chat notification.

- **Cross-skill integration hooks.**
  - `daily-ops-ms`: can read the latest digest via the `DOPS news` trigger.
    News Commander in turn reads `daily-ops-ms/data/links.json` as an additional
    topic signal (+0.3 score boost on tag match).
  - `account-radar`: when building a customer snapshot, MS-news items that
    match the customer's topics are surfaced as an "MS-side context" attachment.
  - `fasttrack`: before a deliverable brief, the digest is checked for relevant
    roadmap/wave items for that deliverable in the last 14 days.

  All three integrations are **optional, silent, and read-only** — if News
  Commander is missing, the other skills work unchanged.

- **`preferences.example.json` template.** First-time setup via copy-and-edit.
  The real `preferences.json` is gitignored so nothing personal lands in the repo.

### Changed

- **`scheduled-prompts/daily-news-run.md` STEP 2.** Documents the auto-archive
  trigger in the pull script. No separate archive step needed.

- **`scheduled-prompts/daily-news-run.md` STEP 6.** Simplified. `morning_pull_ts`
  and `total_pull_runs` are already written by the pull script. Only
  `total_runs += 1` remains as a top-level counter.

- **`source-state.json` schema.** `last_guid` field removed (redundant — mirror
  dedup covers it). Schema reduced to what really matters: health tracking.

### Migration v0.1 → v0.2

No migration needed. All changes are additive:

- Existing `items.jsonl` files stay valid.
- `source-state.json` without `last_guid` is read automatically; the field is
  just ignored.
- First run after upgrade sets `_meta.last_archive_ts`; rotation then runs every
  30 days automatically.

### Known limits

- **One schedule instance per skill.** Anyone wanting multi-schedules (e.g.
  morning + evening digest) needs two separate scheduled prompts with different
  modes.
- **No cross-tenant tagging.** Multi-customer workflows are targeted no earlier
  than v0.4.
- **HTML scraping is fragile.** Sources without RSS/Atom are parsed via
  BeautifulSoup — site redesigns break parsing. Health tracking catches it, but
  a manual selector update is still required.

---

## Coming next (not committed)

- **v0.3** — per-item sentiment classification: announce vs. fix vs. EOL vs.
  preview. Weekly digest mode (Monday morning with a week summary).
- **v0.4** — cross-tenant tagging for multi-customer workflows. Adaptive-Card
  GUI in the self-chat instead of plain Markdown.
- **Open** — topic bundles for other roles: Security Architect, Modern-Work
  Specialist, Data-and-AI Lead. Got one? Send it in as a PR.

---

## License

MIT. Sources in `sources.json` are exclusively public Microsoft domains
(blog.microsoft.com, techcommunity.microsoft.com, learn.microsoft.com, etc.);
their content is subject to the respective Microsoft terms.
