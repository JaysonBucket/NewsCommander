# News Commander

> Persönliches News-Aggregations- und Triage-System für Microsoft-Rollen.
> Zieht täglich ~50 öffentliche Microsoft-Quellen, filtert topic-zentrisch
> und liefert einen kompakten Digest in Teams-Self-Chat oder per Mail.

[![Version](https://img.shields.io/badge/version-1.2.2-blue)]()
[![Skill-Type](https://img.shields.io/badge/skill-personal-green)]()
[![License](https://img.shields.io/badge/license-MIT-lightgrey)]()

> **Release notes:** [Deutsch](RELEASE_NOTES.md) · [English](RELEASE_NOTES.en.md)

---

## Was es macht

```
03:00 Europe/Berlin   ─►  pull_feeds.py    ─►  ~50 RSS/Atom + HTML Sources
                          filter_and_rank  ─►  Topic-Score + Anti-Echo-Dedup
                          send_digest      ─►  Teams Self-Chat ODER Outlook
                          maybe_archive    ─►  Mirror-Rotation (alle 30d)
```

Eine Push-Nachricht morgens — fertig. Keine 50 Tabs, keine Newsletter-Flut,
kein Doom-Scrolling durch Tech-Twitter.

## Features

- **Topic-zentrische Filterung** — Score = Σ (Topic-Weight × Keyword-Hits)
  über Title + Abstract + Source-Tags. Drei Buckets: HIGH (≥2.0),
  MEDIUM (≥1.0), Vorschläge (≥0.5, knapp unter Filter).
- **Anti-Echo-Dedup** — Fuzzy-Title-Match (SequenceMatcher ≥0.78) entfernt
  Dubletten zwischen TechCommunity-Boards und blog.microsoft.com.
- **Self-Tunable per Chat** — `News Commander Topic Add <keyword>` /
  `Drop <keyword>` im Teams-Self-Chat wird beim nächsten Run gelesen und
  in `topics.json` umgesetzt. Kein UI nötig.
- **Empty-Day-Suppress** — Wenn nichts Relevantes da ist, kommt nichts.
- **Atomic Writes** — Alle JSON/JSONL-Mutationen via tempfile + fsync +
  `os.replace`. Crash mitten im Schreiben kann State nicht corrupten.
- **Monatliche Archiv-Rotation** — Alle 30 Tage werden Items älter als
  90 Tage in `data/mirror/_archive/items-YYYY-MM.jsonl` ausgelagert.
  `items.jsonl` bleibt klein, nichts wird verloren.
- **Crash-sicheres Archiv-Write-Order** — (1) append-fsync zum Archiv,
  (2) atomares Rewrite von `items.jsonl`, (3) Meta-Update. Worst Case ist
  Dublette im Archiv, nie Datenverlust.
- **Gap-aware Window** — Wenn ein Lauf fehlt (Schedule down, manueller
  Skip), erweitert sich das Pull-Fenster automatisch + 6h Overlap.
- **Health-Tracking pro Source** — `consecutive_failures ≥3` → Auto-Deaktivierung
  am nächsten Montag, mit Self-Chat-Notification.
- **Cross-Skill-Integration** — `daily-ops-ms`, `account-radar` und
  `fasttrack` können den letzten Digest read-only abrufen (siehe unten).

## Trigger

```
News Commander          # manueller Probelauf
NC start                # alias
NC briefing             # alias
NC status               # Stats, kein Pull
NC sources              # Quellenkatalog
NC topics               # Topics + Weights
NC topic add <keyword>  # Topic-Mutation inline
NC topic drop <keyword>
NC digest               # letzter Digest read-only
NC pause / NC resume    # Scheduled Prompt steuern

News Commander Topic Add <keyword>    # async via Self-Chat
News Commander Topic Drop <keyword>
```

Sekundäre Trigger (natürliche Phrasen):

```
MS-News heute
was gibt's Neues bei Microsoft
News-Digest
Copilot-News  /  Defender-News  /  Roadmap-News
```

## Installation

1. **Klonen** in den Personal-Skills-Pfad:
   ```bash
   cp -r news-commander /mnt/user-config/.claude/skills/
   ```

2. **Python-Dependencies** (in der Cowork-Sandbox üblicherweise vorhanden):
   ```
   feedparser>=6.0
   beautifulsoup4>=4.12
   ```

3. **preferences.json initialisieren**:
   ```bash
   cd /mnt/user-config/.claude/skills/news-commander/data
   cp preferences.example.json preferences.json
   # in preferences.json: user.name, user.email, user.tz, user.language anpassen
   ```

4. **Sanity-Trigger**:
   ```
   News Commander
   ```
   Beim ersten Aufruf läuft der Onboarding-Flow (3 Adaptive-Card-Fragen),
   und der Scheduled Prompt für 03:00 wird automatisch via
   `SetupScheduledPrompt` angelegt.

5. **Optional — Outlook-Regel** (wenn Channel = Mail oder Beide):
   - Filter auf Subject `News Commander Digest` → Move to `News/News Commander/`

Details in [SETUP.md](SETUP.md).

## Daten-Layout

```
news-commander/
├── README.md                          # Du bist hier
├── RELEASE_NOTES.md                   # Version-History
├── SKILL.md                           # Skill-Manifest (Trigger + Doku)
├── SETUP.md                           # Installation Schritt für Schritt
├── scripts/
│   ├── _atomic.py                     # Shared: tempfile + fsync + replace
│   ├── pull_feeds.py                  # RSS/Atom + HTML, gap-aware Window
│   ├── filter_and_rank.py             # Topic-Score + Dedup + Suggestions
│   ├── intake_topics.py               # Self-Chat Topic Add/Drop Mutation
│   ├── send_digest.py                 # Teams-MD + Mail-HTML Render
│   └── archive_items.py               # Monats-Tranche Archiv-Rotation
├── templates/
│   ├── digest-teams.md                # Teams Self-Chat Markdown
│   └── digest-mail.md                 # Outlook HTML
├── scheduled-prompts/
│   └── daily-news-run.md              # 03:00 Run Prompt-Body
└── data/
    ├── _meta.json                     # Schema/Version/Stats/last_run
    ├── sources.json                   # ~65 Quellen, 50 aktiv
    ├── topics.json                    # Topic-Bundles + Blocklist + History
    ├── preferences.example.json       # Template für Erst-Setup
    ├── preferences.json                # (nach Setup) deine User-Config
    ├── mirror/
    │   ├── items.jsonl                # Append-only Mirror der letzten 90d
    │   ├── source-state.json          # Pro Source: Health + last_pull_ts
    │   └── _archive/
    │       └── items-YYYY-MM.jsonl    # Monats-Tranchen >90d
    ├── digests/
    │   └── YYYY-MM-DD.json            # Tagesweise Digest-Snapshots
    └── .intake-state.json             # Self-Chat-Scan-Cursor
```

## Was er löst — konkret

| Problem | Klassische Lösung | News Commander |
|---------|-------------------|----------------|
| 50 Microsoft-Blog-RSS-Feeds | RSS-Reader mit 50 Tabs | 1 Digest |
| Dubletten zwischen TC-Boards und MS-Blog | manuell skippen | Anti-Echo-Dedup |
| „Was ist heute zu Defender XDR neu?" | drei separate Searches | Topic-Score |
| Newsletter-Spam-Days | „delete all" Reflex | Empty-Day-Suppress |
| „Ich will jetzt auch GPT-5 tracken" | Reader-Filter neu bauen | Self-Chat-Keyword |
| Mirror wird mit der Zeit groß | nie bereinigt | 30d Archiv-Rotation |

## Cross-Skill-Integration

News Commander ist **autark** — keiner der anderen Skills ist Voraussetzung.
Wenn aber installiert, wissen sie voneinander:

| Skill | Was passiert |
|-------|--------------|
| `daily-ops-ms` | `DOPS news`-Trigger liest letzten Digest read-only. News Commander liest umgekehrt `daily-ops-ms/data/links.json` als zusätzliches Topic-Signal (+0.3 Score-Boost bei Tag-Match). |
| `account-radar` | Bei Customer-Snapshot zieht der Skill MS-News-Items, die im Digest unter Topics gematcht haben, als „MS-side context" Beilage. |
| `fasttrack` | Vor einem Deliverable-Brief checkt FastTrack, ob News Commander in den letzten 14 Tagen relevante Roadmap-/Wave-Items für das Deliverable hatte. |

Alle Integrationen sind **read-only** und **still** — fehlt News Commander,
funktionieren die anderen Skills unverändert weiter.

## Sicherheit & Privacy

- **Keine externen Schreibzugriffe** außer `PostMessage` / `SendEmail` mit
  Empfänger = du selbst. Kein Cloud-Sync, kein Telemetrie.
- **Quellen sind ausschließlich öffentlich** — RSS/Atom und HTML-Frontends
  von blog.microsoft.com, techcommunity.microsoft.com, etc. Kein Auth,
  keine internen Endpoints.
- **State liegt lokal** unter `/mnt/user-config/.claude/skills/news-commander/`.
  Per Default wird nichts in OneDrive synchronisiert. Wer Backup will, kann
  den Ordner symlinken oder den Archiv-Pfad in `archive_items.py` anpassen.
- **Keine Mail-/Teams-Inhalte werden gelesen** außer den drei Self-Chat-
  Keyword-Prefixen `News Commander Topic Add/Drop ...`.
- **Atomic Writes** verhindern Corrupted-JSON-Scenarios beim Crash.

## Performance

Pro Morning-Run typische Werte:

- ~50 Source-Pulls in <60 Sekunden (parallelisiert via HTTP-Pool)
- Items-Append: 100–500 neue Lines in `items.jsonl`
- Scoring: 1500–3000 Items zu prüfen, <2 Sekunden
- Dedup: O(n²) auf Bucket-Sieger, in der Praxis n<30, <100 ms
- Render: <500 ms für beide Channels
- Archiv-Rotation (alle 30d): linearer Scan über `items.jsonl`, <1 s pro
  10k Lines

Gesamter Run: typischerweise 1–2 Minuten, max 3.

## Anpassungen

Alles über `data/preferences.json`:

| Key | Wirkung |
|-----|---------|
| `delivery.channel` | `teams_self_chat` \| `mail` \| `both` |
| `delivery.suppress_empty_days` | `true` = leerer Tag → nix senden |
| `filter.suggestion_aggressiveness` | `narrow` \| `normal` \| `wide` |
| `filter.max_high_items` / `max_medium_items` / `max_suggestion_items` | Cut-offs |
| `filter.dedupe_fuzzy_threshold` | 0.0–1.0, höher = mehr Dedup |
| `filter.max_age_days` | Recency-Filter (Default 30) |
| `dops_integration.enabled` | Cross-Skill-Lookup an/aus |

Quellen schalten:
```bash
# in data/sources.json den entry suchen und active flippen:
{"id": "ms-blog-windows-insider", "active": false, ...}
```

Topics granular ändern:
```
NC topic add azure openai
NC topic add gpt-5
NC topic drop xbox
```

Oder direkt in `data/topics.json` editieren (Weights, Blocklist, etc.).

## Manuelles Reset

```
News Commander reset
```

- Löscht `data/mirror/`, `data/digests/`, `data/.intake-state.json`
- Setzt `_meta.last_run` zurück
- LÄSST `data/topics.json` und `data/preferences.json` stehen
- Onboarding wird NICHT erneut erzwungen

## Troubleshooting

| Symptom | Wahrscheinliche Ursache | Fix |
|---------|-------------------------|-----|
| Kein Digest morgens | Scheduled Prompt nicht aktiv | `GetScheduledPrompts` checken, ggf. neu anlegen via `News Commander` Trigger |
| Empty Day trotz News | Topics zu eng | Aggressiveness `wide`, oder `NC topic add` |
| Doppelte Items im Digest | `dedupe_fuzzy_threshold` zu hoch | In `preferences.json` auf 0.72 senken |
| Source dauerhaft tot | RSS-Endpoint umgezogen | `NC sources retry` oder URL in `sources.json` korrigieren |
| Mirror wird groß | Archiv-Rotation noch nicht gelaufen | `python scripts/archive_items.py --force` |
| `_atomic` ImportError | Script direkt aus anderem Pfad gestartet | `scripts/` als Working-Dir nutzen, oder über `python -m` |

## Lizenz

MIT — siehe Header in jedem Script. Quellen-URLs in `sources.json` sind
öffentliche Microsoft-Domains; deren Inhalte unterliegen den jeweiligen
Microsoft-Terms.

## Roadmap

Kandidaten für nächste Releases (nicht committed):

- v0.3: Pro-Item-Sentiment-Klassifikation (announce vs. fix vs. EOL vs. preview)
- v0.3: Weekly-Digest-Modus (Mo Morgen mit Summary der Woche)
- v0.4: Cross-Tenant-Tagging für Multi-Customer-Workflows
- v0.4: GUI-Card im Self-Chat statt nur Markdown

## Mitwirken

Issues, Verbesserungsvorschläge, neue Quellen-IDs: einfach in `sources.json`
ergänzen und teilen. Topic-Bundles für andere Rollen (Security-Architect,
Modern-Work-Specialist, etc.) sind willkommen.
