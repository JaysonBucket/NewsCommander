# News Commander — Daily Morning Run (03:00 Europe/Berlin)

Dieser Prompt-Body wird vom Scheduled Task um 03:00 Europe/Berlin täglich
ausgeführt. Er triggert News Commander im Auto-Mode, ohne Banner und
ohne User-Interaktion.

---

## Prompt

Run News Commander in scheduled morning mode. Do not show the banner. Do not ask
the user anything. Execute these steps in order:

**SCHRITT 1 — Intake scannen.**
- Read `/mnt/user-config/.claude/skills/news-commander/data/.intake-state.json`
  (oder leg sie an mit `last_processed_ts = 24h zurück` wenn fehlt).
- `ListChatMessages(person='me', since=<last_processed_ts>, top=100)`.
- Filter Nachrichten, deren Text mit `News Commander Topic Add ` oder
  `News Commander Topic Drop ` startet (case-insensitive).
- Wenn Matches vorhanden, baue ein Batch-JSON
  `working/news-commander-intake.json` mit:
  ```json
  {"operations": [{"action": "add"|"drop", "keyword": "...", "from_message_ts": "..."}]}
  ```
  und ruf `python /mnt/user-config/.claude/skills/news-commander/scripts/intake_topics.py --apply working/news-commander-intake.json` auf.
- Bei 0 Matches: weiter zu Schritt 2 ohne Aufruf.

**SCHRITT 2 — Feeds pullen (Phase 1, urllib).**
- `python /mnt/user-config/.claude/skills/news-commander/scripts/pull_feeds.py --all`
- Output ignorieren — Script schreibt selbst.
- Hinweis: Der Pull lauft jetzt zweistufig (v1.3.0). Phase 1 ist urllib direkt.
  Sources die der Container nicht erreicht (Errno 101) ODER deren
  `feed_type == "json_listing_search"` ist, landen in
  `data/mirror/unreachable.json` (`{generated_at, phase:"urllib", sources:[...]}`).
  Archive-Rotation wird in Phase 1 NICHT getriggert wenn `unreachable.sources`
  nicht-leer ist — das passiert erst nach Phase 3.

**SCHRITT 2b — Phase 2, Agent-MCP-Fetch (nur wenn Phase 1 etwas flaggt).**
- Lies `data/mirror/unreachable.json`. Wenn `sources == []` → skip 2b und 2c,
  weiter zu Schritt 3.
- Fur jede `source_id` in `unreachable.sources` lookup den Eintrag in
  `data/sources.json` und fuhre PARALLEL (subagents) je nach `feed_type` aus:
  - `feed_type == "json_listing_search"`:
    `mcp__core__web_search("site:<source.search_domain> <source.search_keyword>")`
    → die Ergebnisliste (max ~20 Results: title/url/snippet) als
    `{"kind":"search", "fetched_at":"<iso>", "results":[...]}`
    nach `data/mirror/raw-fetch/<source_id>.json` schreiben.
  - sonstiger `feed_type` (rss/atom/json_*):
    `mcp__core__web_fetch(source.feed_url)` → den Rohtext als
    `{"kind":"body", "fetched_at":"<iso>", "body":"<text>"}`
    nach `data/mirror/raw-fetch/<source_id>.json` schreiben.
- Atomic write empfohlen (tempfile + os.replace). Eine Datei pro Source.
- Subagents NICHT die Skill-Skripte aufrufen lassen — nur den MCP-Fetch und
  den File-Write. Phase 3 parst zentral im Main-Agent.

**SCHRITT 2c — Phase 3, From-Cache-Parse.**
- `python /mnt/user-config/.claude/skills/news-commander/scripts/pull_feeds.py --from-cache`
- Liest `unreachable.json`, parst pro Source `raw-fetch/<id>.json` mit den
  bestehenden Parsern (`parse_rss`, `parse_json_m365_roadmap`, ...,
  `parse_json_listing_search`) und merged Items via item_id-Dedup in den Mirror.
- Triggert am Ende `archive_items.maybe_archive()` automatisch. Wenn
  `_meta.last_archive_ts` fehlt oder >=30d alt ist, werden Items >90 Tage in
  `data/mirror/_archive/items-YYYY-MM.jsonl` verschoben.

**SCHRITT 3 — Filtern + Ranken.**
- `python /mnt/user-config/.claude/skills/news-commander/scripts/filter_and_rank.py`
- Schreibt `data/digests/<today>.json`.

**SCHRITT 4 — Digest rendern.**
- `python /mnt/user-config/.claude/skills/news-commander/scripts/send_digest.py`
- Exit-Code 2 = empty day, kein Send → fertig, kein weiterer Step.
- Exit-Code 0 = es gibt was zu schicken, weiter zu Schritt 5.

**SCHRITT 5 — Send.**
- Lies `data/preferences.json.delivery.channel`.
- Wenn `teams_self_chat` oder `both`:
  - `PostMessage(recipients=['me'], body=<content von output/digest-teams-<today>.md>, topic='News Commander Digest')`.
- Wenn `mail` oder `both`:
  - Empfänger = `preferences.user.email` (aus `data/preferences.json` gelesen).
  - `SendEmailWithAttachments(to=[<preferences.user.email>], subject='News Commander Digest — <today>', body_file_path='output/digest-mail-<today>.html', content_type='HTML')`.
- Bei Erfolg: Setze `_meta.json.last_run.digest_sent = true`, `digest_sent_at = now`, `stats.total_digests_sent += 1`.

**SCHRITT 6 — Cleanup + Stats.**
- `morning_pull_ts` + `total_pull_runs` werden bereits von `pull_feeds.py`
  geschrieben. Hier nur noch `total_runs += 1` als Gesamt-Run-Zähler.
- Wenn `working/news-commander-intake.json` existiert → löschen.

**SCHRITT 7 — Source-Health-Check (jeden Montag).**
- Wenn heute Montag ist: prüfe `data/mirror/source-state.json` auf
  `consecutive_failures >= 3` Sources. Wenn vorhanden:
  - Setze sie in `sources.json` auf `active: false` und schick eine kurze
    Notification per Self-Chat: "News Commander — N Quellen deaktiviert wegen
    Dauer-Fehler: [liste]. Reaktivieren mit `NC sources retry`."

---

## Modus-Hinweise

- **Banner**: niemals anzeigen während scheduled run.
- **Errors**: Fehler in `_meta.json.last_run.errors[]` loggen, NICHT an User schicken.
  User sieht Fehler nur, wenn er manuell `NC status` triggert.
- **Empty Day**: bei `preferences.delivery.suppress_empty_days = true` UND
  `HIGH+MEDIUM+WATCH == 0`: kein Send, kein Self-Chat, kein Mail. Nur
  `_meta.json.last_run.digest_sent = false` setzen.
- **Single-run guarantee**: Wenn `_meta.json.last_run.morning_pull_ts` heute
  schon gesetzt ist (d.h. ein voriger Run lief), Schritte 2-5 überspringen.
  Intake (Schritt 1) immer laufen lassen.
