#!/usr/bin/env python3
"""
News Commander — pull_feeds.py
RSS/Atom + HTML-Scrape, window-based (pub_date >= now − 36h).

Usage:
    python pull_feeds.py [--source <id>] [--all] [--dry-run] [--window-hours N]

Strategie:
- RSS/Atom: filter Items mit pub_date innerhalb des Fensters (Default 36h).
- HTML-Scrape: kein verlässliches pub_date → Mirror-Dedup via item_id (sha1(source+url)).
- Gap-aware: wenn _meta.last_run.morning_pull_ts älter als 36h, wird das Fenster
  auf (now − last_run) + 6h Overlap erweitert.
- source-state.json speichert nur noch Health (last_pull_ts, last_status, consecutive_failures).
  Kein last_guid mehr — überflüssig.

Items-Schema unverändert (siehe items.jsonl Format).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urljoin
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

try:
    import feedparser
except ImportError:
    feedparser = None

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _atomic import atomic_save_json  # noqa: E402

SKILL_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = SKILL_DIR / "data"
MIRROR_DIR = DATA_DIR / "mirror"
SOURCES_FILE = DATA_DIR / "sources.json"
META_FILE = DATA_DIR / "_meta.json"
STATE_FILE = MIRROR_DIR / "source-state.json"
ITEMS_FILE = MIRROR_DIR / "items.jsonl"
# v1.3.0 Two-Tier Fallback Pull: urllib (Phase 1) → unreachable.json → MCP (Agent) → raw-fetch/ → --from-cache (Phase 3)
RAW_FETCH_DIR = MIRROR_DIR / "raw-fetch"
UNREACHABLE_FILE = MIRROR_DIR / "unreachable.json"

USER_AGENT = "Mozilla/5.0 (compatible; NewsCommander/1.3.0; +https://jaysons.dev)"

ROADMAP_ITEM_URL_TEMPLATE = "https://www.microsoft.com/microsoft-365/roadmap?id={id}"
AZURE_UPDATE_URL_TEMPLATE = "https://azure.microsoft.com/en-us/updates?id={id}"
MSRC_RELEASE_NOTE_URL_TEMPLATE = "https://msrc.microsoft.com/update-guide/releaseNote/{id}"
TIMEOUT_SECS = 20
MAX_ITEMS_PER_FEED = 30
DEFAULT_WINDOW_HOURS = 36
GAP_OVERLAP_HOURS = 6
# Pull-Phase Parallelitaet: I/O-bound (urllib + parse), GIL released waehrend socket-recv.
# 10 Worker reduzieren 40-Source-Lauf von ~80s (sequential, TIMEOUT=20) auf ~10-15s.
PULL_PARALLELISM = 10


def load_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    atomic_save_json(Path(path), data)


def now_dt() -> datetime:
    return datetime.now(timezone.utc)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def item_hash(source_id: str, url: str) -> str:
    h = hashlib.sha1(f"{source_id}::{url}".encode("utf-8")).hexdigest()
    return h[:16]


def parse_iso(ts: str | None) -> datetime | None:
    if not ts:
        return None
    try:
        # Python's fromisoformat handles offsets since 3.11; fallback strip Z
        s = ts.replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except (ValueError, TypeError):
        return None


def compute_window_start(meta: dict, override_hours: int | None) -> datetime:
    """Default 36h zurück, oder gap-aware wenn letzter Lauf älter ist."""
    now = now_dt()
    base = timedelta(hours=override_hours or DEFAULT_WINDOW_HOURS)
    if override_hours:
        return now - base
    last_ts = parse_iso((meta or {}).get("last_run", {}).get("morning_pull_ts"))
    if last_ts:
        gap = now - last_ts
        if gap > base:
            return now - (gap + timedelta(hours=GAP_OVERLAP_HOURS))
    return now - base


def load_existing_item_ids() -> set[str]:
    """items.jsonl streamen, item_id-Set bauen."""
    seen: set[str] = set()
    if not ITEMS_FILE.exists():
        return seen
    with ITEMS_FILE.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if "item_id" in obj:
                    seen.add(obj["item_id"])
            except json.JSONDecodeError:
                continue
    return seen


def fetch(url: str) -> bytes | None:
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "*/*"})
    try:
        with urlopen(req, timeout=TIMEOUT_SECS) as resp:
            return resp.read()
    except (URLError, HTTPError, TimeoutError) as exc:
        print(f"  ! fetch failed: {exc}", file=sys.stderr)
        return None


def read_cache_file(source_id: str) -> dict | None:
    """v1.3.0: Read pre-fetched MCP payload from raw-fetch/<source_id>.json.

    Agent-side writes one of two shapes:
      {"kind": "body",   "body": "<raw fetched text>", "fetched_at": "..."}
      {"kind": "search", "results": [{title, url, snippet}, ...], "fetched_at": "..."}
    """
    path = RAW_FETCH_DIR / f"{source_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        print(f"  ! cache read failed for {source_id}: {exc}", file=sys.stderr)
        return None


def is_valid_url(url: str | None) -> bool:
    """Strict check: must start with http(s)://, have a hostname, no anchor-only, no javascript:."""
    if not url or not isinstance(url, str):
        return False
    u = url.strip()
    if not u:
        return False
    low = u.lower()
    if low.startswith("javascript:") or low.startswith("mailto:"):
        return False
    if not (low.startswith("http://") or low.startswith("https://")):
        return False
    # Reject pure anchors or empty paths after scheme
    if u.endswith("#") or "#" == u.split("//", 1)[-1].split("/", 1)[-1].strip("/"):
        return False
    # Require a non-empty hostname (rejects 'https://' and 'https:///path')
    try:
        from urllib.parse import urlparse
        if not (urlparse(u).hostname or "").strip():
            return False
    except (ValueError, TypeError):
        return False
    return True


def _base_domain(host: str) -> str:
    """Normalize host to its registrable domain (last 2 labels), stripping 'www.'.

    Examples:
        www.microsoft.com  -> microsoft.com
        learn.microsoft.com -> microsoft.com
        msrc.microsoft.com  -> microsoft.com
        azure.microsoft.com -> microsoft.com
    """
    h = (host or "").lower().strip()
    if h.startswith("www."):
        h = h[4:]
    parts = h.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else h


def url_matches_source_domain(url: str, source: dict) -> bool:
    """v1.3.0 source-discipline guard: a search-result URL is only accepted
    as a per-item URL when its registrable domain matches the source's own
    domain. Otherwise the renderer must fall back to source_url with the
    v1.1.3 hint. Subdomain-tolerant via _base_domain (last 2 labels)."""
    if not is_valid_url(url):
        return False
    try:
        from urllib.parse import urlparse
        host = (urlparse(url).hostname or "").lower()
        src_host = (urlparse(source.get("url") or "").hostname or "").lower()
        if not host or not src_host:
            return False
        return _base_domain(host) == _base_domain(src_host)
    except (ValueError, TypeError):
        return False


def strip_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:500]


def parse_rss(source: dict, body: bytes) -> list[dict]:
    if feedparser is None:
        print("  ! feedparser not installed — skipping RSS parse", file=sys.stderr)
        return []
    parsed = feedparser.parse(body)
    items = []
    for entry in parsed.entries[:MAX_ITEMS_PER_FEED]:
        title = (entry.get("title") or "").strip()
        if not title:
            continue
        link = entry.get("link") or ""
        guid = entry.get("id") or entry.get("guid") or link
        summary = entry.get("summary") or entry.get("description") or ""
        abstract = strip_html(summary)
        pub_struct = entry.get("published_parsed") or entry.get("updated_parsed")
        if pub_struct:
            pub_dt = datetime.fromtimestamp(time.mktime(pub_struct), tz=timezone.utc)
            pub_date = pub_dt.isoformat()
        else:
            pub_date = None  # unknown — wird im Filter behandelt
        items.append({
            "title": title,
            "abstract": abstract,
            "url": link,
            "guid": guid,
            "pub_date": pub_date,
        })
    return items


def parse_html(source: dict, body: bytes) -> list[dict]:
    if BeautifulSoup is None:
        print("  ! beautifulsoup4 not installed — skipping HTML scrape", file=sys.stderr)
        return []
    soup = BeautifulSoup(body, "html.parser")
    items: list[dict] = []
    candidates = soup.find_all("article")
    if not candidates:
        candidates = soup.select("div.card, li.card, div.m-blog-card, div.c-card")
    if not candidates:
        candidates = soup.select("h2 a, h3 a")
        seen_urls = set()
        for a in candidates[:MAX_ITEMS_PER_FEED]:
            href = a.get("href")
            title = (a.get_text() or "").strip()
            if not href or not title:
                continue
            url = urljoin(source["url"], href)
            if url in seen_urls:
                continue
            seen_urls.add(url)
            items.append({
                "title": title,
                "abstract": "",
                "url": url,
                "guid": url,
                "pub_date": None,
            })
        return items

    for art in candidates[:MAX_ITEMS_PER_FEED]:
        a = art.find("a", href=True)
        if not a:
            continue
        title = (a.get_text() or art.get_text() or "").strip().split("\n")[0]
        if not title:
            continue
        href = a["href"]
        url = urljoin(source["url"], href)
        summary_tag = art.find(["p", "div"], class_=re.compile(r"(summary|excerpt|description|abstract|teaser)", re.I))
        abstract = (summary_tag.get_text().strip() if summary_tag else "")[:500]
        time_tag = art.find("time")
        pub_date = time_tag.get("datetime") if time_tag and time_tag.get("datetime") else None
        items.append({
            "title": title,
            "abstract": abstract,
            "url": url,
            "guid": url,
            "pub_date": pub_date,
        })
    return items


def parse_json_m365_roadmap(source: dict, body: bytes) -> list[dict]:
    """Parse M365 Roadmap public JSON API.
    Endpoint: https://www.microsoft.com/releasecommunications/api/v1/m365
    Per-item URL is constructed via ROADMAP_ITEM_URL_TEMPLATE.
    """
    try:
        data = json.loads(body.decode("utf-8", errors="replace"))
    except json.JSONDecodeError as exc:
        print(f"  ! roadmap JSON decode failed: {exc}", file=sys.stderr)
        return []

    # API may return a top-level list OR a wrapper dict with "value"/"items"/"results"
    if isinstance(data, dict):
        for key in ("value", "items", "results", "data"):
            if isinstance(data.get(key), list):
                entries = data[key]
                break
        else:
            entries = []
    elif isinstance(data, list):
        entries = data
    else:
        entries = []

    items: list[dict] = []
    for entry in entries[:MAX_ITEMS_PER_FEED]:
        if not isinstance(entry, dict):
            continue
        rid = entry.get("id") or entry.get("featureId") or entry.get("publicId")
        title = (entry.get("title") or entry.get("name") or "").strip()
        if not rid or not title:
            continue
        desc = entry.get("description") or entry.get("publicDescription") or ""
        abstract = strip_html(desc)
        # Prefer modified, fall back to created
        pub_raw = (entry.get("modified") or entry.get("created")
                   or entry.get("modifiedDateTime") or entry.get("createdDateTime"))
        pub_date = None
        if pub_raw:
            pub_dt = parse_iso(pub_raw if isinstance(pub_raw, str) else None)
            if pub_dt:
                pub_date = pub_dt.isoformat()
        url = ROADMAP_ITEM_URL_TEMPLATE.format(id=rid)
        items.append({
            "title": title,
            "abstract": abstract,
            "url": url,
            "guid": f"roadmap-{rid}",
            "pub_date": pub_date,
        })
    return items


def parse_json_azure_updates(source: dict, body: bytes) -> list[dict]:
    """Parse Azure Updates public JSON API.
    Endpoint: https://www.microsoft.com/releasecommunications/api/v1/azure
    Per-item URL is constructed via AZURE_UPDATE_URL_TEMPLATE.
    Shares the field shape of the M365 roadmap API.
    """
    try:
        data = json.loads(body.decode("utf-8", errors="replace"))
    except json.JSONDecodeError as exc:
        print(f"  ! azure-updates JSON decode failed: {exc}", file=sys.stderr)
        return []

    if isinstance(data, dict):
        for key in ("value", "items", "results", "data"):
            if isinstance(data.get(key), list):
                entries = data[key]
                break
        else:
            entries = []
    elif isinstance(data, list):
        entries = data
    else:
        entries = []

    items: list[dict] = []
    for entry in entries[:MAX_ITEMS_PER_FEED]:
        if not isinstance(entry, dict):
            continue
        rid = entry.get("id") or entry.get("featureId") or entry.get("publicId")
        title = (entry.get("title") or entry.get("name") or "").strip()
        if not rid or not title:
            continue
        desc = entry.get("description") or entry.get("publicDescription") or ""
        abstract = strip_html(desc)
        pub_raw = (entry.get("modified") or entry.get("created")
                   or entry.get("modifiedDateTime") or entry.get("createdDateTime"))
        pub_date = None
        if pub_raw:
            pub_dt = parse_iso(pub_raw if isinstance(pub_raw, str) else None)
            if pub_dt:
                pub_date = pub_dt.isoformat()
        url = AZURE_UPDATE_URL_TEMPLATE.format(id=rid)
        items.append({
            "title": title,
            "abstract": abstract,
            "url": url,
            "guid": f"azure-update-{rid}",
            "pub_date": pub_date,
        })
    return items


def parse_json_msrc_cvrf(source: dict, body: bytes) -> list[dict]:
    """Parse MSRC CVRF v3.0 monthly updates list.
    Endpoint: https://api.msrc.microsoft.com/cvrf/v3.0/updates
    Response: { "value": [ { "ID": "2026-May", "DocumentTitle": "...",
                              "InitialReleaseDate": "...", "CurrentReleaseDate": "..." } ] }
    Each entry = one monthly security update batch. Per-item URL points to
    the MSRC release-note page for that month.
    """
    try:
        data = json.loads(body.decode("utf-8", errors="replace"))
    except json.JSONDecodeError as exc:
        print(f"  ! msrc-cvrf JSON decode failed: {exc}", file=sys.stderr)
        return []

    entries = data.get("value") if isinstance(data, dict) else None
    if not isinstance(entries, list):
        return []

    items: list[dict] = []
    for entry in entries[:MAX_ITEMS_PER_FEED]:
        if not isinstance(entry, dict):
            continue
        rid = entry.get("ID") or entry.get("Alias")
        title = (entry.get("DocumentTitle") or "").strip()
        if not rid or not title:
            continue
        pub_raw = entry.get("CurrentReleaseDate") or entry.get("InitialReleaseDate")
        pub_date = None
        if pub_raw and isinstance(pub_raw, str):
            pub_dt = parse_iso(pub_raw)
            if pub_dt:
                pub_date = pub_dt.isoformat()
        url = MSRC_RELEASE_NOTE_URL_TEMPLATE.format(id=rid)
        abstract = f"Monatliches Microsoft Security Update Release {rid}."
        items.append({
            "title": title,
            "abstract": abstract,
            "url": url,
            "guid": f"msrc-cvrf-{rid}",
            "pub_date": pub_date,
        })
    return items


def parse_json_listing_search(source: dict, results: list[dict]) -> list[dict]:
    """v1.3.0: Parse agent-side MCP web_search results for listing-style sources.

    Input shape (from raw-fetch cache, kind="search"):
        [{"title": "...", "url": "https://...", "snippet": "..."}, ...]

    Source-discipline guard:
      - If result URL matches source domain → use it as item URL (direct_link=True)
      - Else → fall back to source["url"] with v1.1.3 link-hardening hint
        (off-domain search hits do not become per-item URLs).
    """
    items: list[dict] = []
    if not isinstance(results, list):
        return items
    seen_urls: set[str] = set()
    for r in results[:MAX_ITEMS_PER_FEED]:
        if not isinstance(r, dict):
            continue
        title = (r.get("title") or "").strip()
        if not title:
            continue
        raw_url = (r.get("url") or "").strip()
        snippet = (r.get("snippet") or r.get("description") or "").strip()
        abstract = strip_html(snippet)
        if url_matches_source_domain(raw_url, source):
            item_url = raw_url
            direct = True
        else:
            item_url = source.get("url") or raw_url
            direct = False
        if not item_url or item_url in seen_urls:
            continue
        seen_urls.add(item_url)
        items.append({
            "title": title,
            "abstract": abstract,
            "url": item_url,
            "guid": raw_url or item_url,
            "pub_date": None,
            "direct_link": direct,
        })
    return items


def pull_source(
    source: dict,
    state: dict,
    window_start: datetime,
    existing_ids: set[str],
    from_cache: bool = False,
) -> tuple[list[dict], dict, bool]:
    """Returns (new_items, updated_state_for_source, needs_mcp).

    Modes:
    - from_cache=False (default, Phase 1): try urllib fetch + parse.
      For feed_type=='json_listing_search' (no real feed_url, only listing+keyword):
        urllib path is skipped — returns ([], state, needs_mcp=True) right away.
      For other types: on fetch failure (None body / Errno 101), returns
        ([], state, needs_mcp=True) so the agent can retry via MCP and write to raw-fetch/.
    - from_cache=True (Phase 3): load raw-fetch/<src_id>.json, dispatch by kind.

    Filter logic unchanged:
    - RSS/JSON: pub_date >= window_start (unknown → keep, mirror dedup catches)
    - HTML / listing-search: no pub_date filter, mirror dedup via item_id
    """
    src_id = source["id"]
    feed_url = source.get("feed_url") or source["url"]
    feed_type = source.get("feed_type", "rss")

    src_state = state.get(src_id, {
        "last_pull_ts": None,
        "last_status": "untested",
        "consecutive_failures": 0,
    })
    # Clean up legacy field
    src_state.pop("last_guid", None)

    print(f"→ {src_id} ({feed_type}{' / from-cache' if from_cache else ''})")

    raw_items: list[dict] = []

    if from_cache:
        cache = read_cache_file(src_id)
        if cache is None:
            src_state["last_status"] = "no-cache"
            src_state["consecutive_failures"] = src_state.get("consecutive_failures", 0) + 1
            print("  ! no cache file present")
            return [], src_state, False
        kind = (cache.get("kind") or "").lower()
        if kind == "search":
            raw_items = parse_json_listing_search(source, cache.get("results") or [])
        elif kind == "body":
            body_text = cache.get("body") or ""
            body_bytes = body_text.encode("utf-8") if isinstance(body_text, str) else body_text
            if not body_bytes:
                raw_items = []
            elif feed_type in ("rss", "atom"):
                raw_items = parse_rss(source, body_bytes)
            elif feed_type == "json_m365_roadmap":
                raw_items = parse_json_m365_roadmap(source, body_bytes)
            elif feed_type == "json_azure_updates":
                raw_items = parse_json_azure_updates(source, body_bytes)
            elif feed_type == "json_msrc_cvrf":
                raw_items = parse_json_msrc_cvrf(source, body_bytes)
            else:
                raw_items = parse_html(source, body_bytes)
        else:
            src_state["last_status"] = "cache-bad-kind"
            print(f"  ! cache kind '{kind}' not supported")
            return [], src_state, False
    else:
        # Phase 1 (urllib). json_listing_search has no fetchable feed → defer to MCP.
        if feed_type == "json_listing_search":
            src_state["last_status"] = "needs-mcp"
            print("  ↪ listing-search source — deferring to agent MCP fetch")
            return [], src_state, True

        body = fetch(feed_url)
        if body is None:
            src_state["last_status"] = "failing"
            src_state["consecutive_failures"] = src_state.get("consecutive_failures", 0) + 1
            return [], src_state, True

        if feed_type in ("rss", "atom"):
            raw_items = parse_rss(source, body)
        elif feed_type == "json_m365_roadmap":
            raw_items = parse_json_m365_roadmap(source, body)
        elif feed_type == "json_azure_updates":
            raw_items = parse_json_azure_updates(source, body)
        elif feed_type == "json_msrc_cvrf":
            raw_items = parse_json_msrc_cvrf(source, body)
        else:
            raw_items = parse_html(source, body)

    if not raw_items:
        src_state["last_status"] = "empty"
        src_state["last_pull_ts"] = now_iso()
        return [], src_state, False

    # No date-filter for HTML and listing-search (no reliable pub_date)
    date_filtered_types = ("rss", "atom",
                           "json_m365_roadmap", "json_azure_updates", "json_msrc_cvrf")
    skip_date_filter = feed_type not in date_filtered_types
    new_items: list[dict] = []
    skipped_old = 0
    skipped_dup = 0

    for raw in raw_items:
        url = raw["url"]
        if not url:
            continue
        item_id = item_hash(src_id, url)

        if item_id in existing_ids:
            skipped_dup += 1
            continue

        pub_dt = parse_iso(raw.get("pub_date"))
        if not skip_date_filter and pub_dt is not None and pub_dt < window_start:
            skipped_old += 1
            continue

        pub_date_out = raw.get("pub_date") or now_iso()
        item = {
            "item_id": item_id,
            "source_id": src_id,
            "source_title": source["title"],
            "source_category": source["category"],
            "source_priority": source.get("priority", "medium"),
            "source_tags": source.get("tags", []),
            "source_url": source.get("url"),
            "title": raw["title"],
            "abstract": raw["abstract"],
            "url": url,
            "pub_date": pub_date_out,
            "guid": raw.get("guid") or url,
            "pulled_at": now_iso(),
            "raw_lang": "de" if "de-de" in src_id.lower() or "techwiese" in src_id.lower() else "en",
        }
        # v1.3.0: propagate direct_link flag from listing-search parser
        if "direct_link" in raw:
            item["direct_link"] = bool(raw["direct_link"])
        new_items.append(item)
        existing_ids.add(item_id)  # innerhalb desselben Laufs nicht doppelt

    src_state["last_pull_ts"] = now_iso()
    src_state["last_status"] = "working-from-cache" if from_cache else "working"
    src_state["consecutive_failures"] = 0
    print(f"  + {len(new_items)} new (skipped {skipped_old} old, {skipped_dup} dup)")
    return new_items, src_state, False


def append_items(items: list[dict]) -> None:
    MIRROR_DIR.mkdir(parents=True, exist_ok=True)
    with ITEMS_FILE.open("a", encoding="utf-8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", help="Pull only this source id")
    ap.add_argument("--all", action="store_true", help="Pull all active sources (default)")
    ap.add_argument("--dry-run", action="store_true", help="No file writes")
    ap.add_argument("--window-hours", type=int, default=None,
                    help=f"Override window (default {DEFAULT_WINDOW_HOURS}h, gap-aware)")
    ap.add_argument("--from-cache", action="store_true",
                    help="v1.3.0 Phase 3: read pre-fetched MCP payloads from "
                         "data/mirror/raw-fetch/<id>.json instead of urllib. "
                         "Targets are restricted to ids listed in unreachable.json "
                         "unless --source is given.")
    args = ap.parse_args()

    sources_data = load_json(SOURCES_FILE)
    if not sources_data:
        print("ERROR: sources.json missing or empty", file=sys.stderr)
        return 1

    meta = load_json(META_FILE, default={})
    window_start = compute_window_start(meta, args.window_hours)
    print(f"window_start = {window_start.isoformat()} (UTC)")
    print(f"mode: {'from-cache (Phase 3)' if args.from_cache else 'urllib (Phase 1)'}")

    state = load_json(STATE_FILE, default={})
    existing_ids = load_existing_item_ids()
    print(f"existing mirror items: {len(existing_ids)}")

    all_active = [s for s in sources_data["sources"] if s.get("active")]
    targets = all_active
    if args.from_cache and not args.source:
        unreachable = load_json(UNREACHABLE_FILE, default=None)
        if unreachable is None or not isinstance(unreachable.get("sources"), list):
            print("ERROR: --from-cache requires unreachable.json from a prior Phase-1 run "
                  "(or --source <id>)", file=sys.stderr)
            return 1
        unreachable_ids = set(unreachable["sources"])
        targets = [s for s in all_active if s["id"] in unreachable_ids]
        print(f"from-cache scope: {len(targets)} unreachable sources from prior phase")
    if args.source:
        targets = [s for s in all_active if s["id"] == args.source]
        if not targets:
            print(f"ERROR: source {args.source} not found or inactive", file=sys.stderr)
            return 1

    if not targets:
        print("nothing to do — empty target set")
        return 0

    total_new = 0
    unreachable_sources: list[str] = []
    # Parallel I/O-Phase. pull_source() ist thread-safe weil:
    # - jeder Worker bearbeitet eine eigene source_id (keine state-Kollision)
    # - existing_ids als read-mostly snapshot uebergeben; cross-source-Dedup ist nicht
    #   noetig, da item_id = sha1(source_id + url) per Definition source-skopiert ist
    # - File-Writes (append_items, save_json) bleiben im Main-Thread sequenziell
    snapshot_ids = set(existing_ids)  # immutable snapshot for workers
    pool_size = min(PULL_PARALLELISM, len(targets)) or 1
    pool_start = time.monotonic()
    with ThreadPoolExecutor(max_workers=pool_size, thread_name_prefix="nc-pull") as pool:
        futures = {
            pool.submit(pull_source, src, state, window_start, snapshot_ids,
                        args.from_cache): src
            for src in targets
        }
        for fut in as_completed(futures):
            src = futures[fut]
            try:
                new_items, src_state, needs_mcp = fut.result()
            except Exception as exc:  # pragma: no cover — defensive, single source failure
                print(f"  ! {src['id']} worker crashed: {exc}", file=sys.stderr)
                continue
            state[src["id"]] = src_state
            if needs_mcp and not args.from_cache:
                unreachable_sources.append(src["id"])
            if new_items:
                # Final dedup against accumulated existing_ids (race-safe: main-thread only)
                fresh = [it for it in new_items if it["item_id"] not in existing_ids]
                if not args.dry_run and fresh:
                    append_items(fresh)
                for it in fresh:
                    existing_ids.add(it["item_id"])
                total_new += len(fresh)
    pool_elapsed = time.monotonic() - pool_start
    print(f"  pull phase elapsed: {pool_elapsed:.1f}s ({pool_size} workers / {len(targets)} sources)")

    if not args.dry_run:
        save_json(STATE_FILE, state)
        # v1.3.0 Phase 1: write unreachable manifest so the agent knows what to MCP-fetch.
        # Phase 3 (from-cache): do not touch — the prior phase wrote it; we just consumed it.
        if not args.from_cache:
            MIRROR_DIR.mkdir(parents=True, exist_ok=True)
            save_json(UNREACHABLE_FILE, {
                "generated_at": now_iso(),
                "phase": "urllib",
                "sources": sorted(unreachable_sources),
            })
            print(f"  unreachable.json: {len(unreachable_sources)} sources flagged for MCP fallback")
        # Update last morning_pull_ts so gap-aware window works next run
        meta = load_json(META_FILE, default={}) or {}
        meta.setdefault("last_run", {})["morning_pull_ts"] = now_iso()
        stats = meta.setdefault("stats", {})
        stats["total_pull_runs"] = stats.get("total_pull_runs", 0) + 1
        stats["total_items_pulled"] = stats.get("total_items_pulled", 0) + total_new
        save_json(META_FILE, meta)

    print(f"\n✓ pulled {total_new} new items from {len(targets)} sources")
    if not args.from_cache and unreachable_sources:
        print(f"⚠ {len(unreachable_sources)} sources need MCP fallback → "
              f"agent should fetch & re-run with --from-cache")

    # Auto-trigger monthly archive rotation (every 30d, items >90d old)
    # Only after the final pull phase (from-cache) — skip after Phase 1 so we
    # don't archive before the MCP fallback has had a chance to run.
    if not args.dry_run and (args.from_cache or not unreachable_sources):
        try:
            from archive_items import maybe_archive
            arch_result = maybe_archive()
            if arch_result.get("ran"):
                if arch_result.get("archived", 0) > 0:
                    print(f"✓ archive: {arch_result['archived']} items → {arch_result['archive_file']}")
                else:
                    print(f"✓ archive: nothing to archive (kept {arch_result.get('kept', 0)})")
        except Exception as exc:
            print(f"  ! archive step failed (non-fatal): {exc}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
