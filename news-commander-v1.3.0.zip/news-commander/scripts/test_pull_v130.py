#!/usr/bin/env python3
"""v1.3.0 self-tests for News Commander pull_feeds.py refactor.

Runs without network access. Builds an isolated fake skill directory in a
temp folder, monkey-patches pull_feeds module-level paths to point at it,
and exercises:

  T1  Imports + USER_AGENT bump
  T2  is_valid_url edge cases
  T3  url_matches_source_domain (subdomain-tolerant)
  T4  read_cache_file (missing / malformed / valid)
  T5  parse_json_listing_search (on-domain → direct, off-domain → fallback)
  T6  pull_source from_cache=True with kind=search  → emits items
  T7  pull_source from_cache=False with json_listing_search → needs_mcp=True (no urllib)
  T8  pull_source from_cache=False with fetch failure → needs_mcp=True
  T9  main() --from-cache restricted by unreachable.json
  T10 main() Phase-1 fetch monkey-patched to fail → writes unreachable.json

Exit code 0 = all green, 1 = any failure.
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import pull_feeds as pf  # noqa: E402

PASS = "\033[32m✓\033[0m"
FAIL = "\033[31m✗\033[0m"

results: list[tuple[str, bool, str]] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    results.append((name, cond, detail))
    sym = PASS if cond else FAIL
    print(f"  {sym} {name}" + (f" — {detail}" if detail else ""))


def setup_fake_skill(tmp: Path) -> None:
    """Re-point pull_feeds module-level paths into tmp."""
    data = tmp / "data"
    mirror = data / "mirror"
    raw = mirror / "raw-fetch"
    raw.mkdir(parents=True, exist_ok=True)

    pf.SKILL_DIR = tmp
    pf.DATA_DIR = data
    pf.MIRROR_DIR = mirror
    pf.SOURCES_FILE = data / "sources.json"
    pf.META_FILE = data / "_meta.json"
    pf.STATE_FILE = mirror / "source-state.json"
    pf.ITEMS_FILE = mirror / "items.jsonl"
    pf.RAW_FETCH_DIR = raw
    pf.UNREACHABLE_FILE = mirror / "unreachable.json"


def t1_imports() -> None:
    print("T1 imports + version")
    check("USER_AGENT bumped to 1.3.0", "1.3.0" in pf.USER_AGENT, pf.USER_AGENT)
    for fn in ("read_cache_file", "url_matches_source_domain",
               "parse_json_listing_search", "pull_source", "main"):
        check(f"has {fn}", hasattr(pf, fn))


def t2_is_valid_url() -> None:
    print("T2 is_valid_url")
    cases = [
        ("https://example.com/a", True),
        ("http://example.com", True),
        ("", False),
        (None, False),
        ("javascript:alert(1)", False),
        ("mailto:x@y.z", False),
        ("ftp://example.com", False),
        ("https://", False),
        ("https://example.com#", False),
    ]
    for url, want in cases:
        got = pf.is_valid_url(url)
        check(f"is_valid_url({url!r})={got}", got == want)


def t3_domain_match() -> None:
    print("T3 url_matches_source_domain")
    src = {"url": "https://www.microsoft.com/en-us/microsoft-365/roadmap"}
    cases = [
        ("https://www.microsoft.com/en-us/microsoft-365/roadmap?id=12345", True),
        ("https://learn.microsoft.com/en-us/agents/", True),  # subdomain tolerant
        ("https://microsoft.com/anything", True),
        ("https://news.ycombinator.com/", False),
        ("https://www.bing.com/search", False),
        ("javascript:void(0)", False),
        ("", False),
    ]
    for url, want in cases:
        got = pf.url_matches_source_domain(url, src)
        check(f"{url[:50]} → {got}", got == want)


def t4_read_cache_file(tmp: Path) -> None:
    print("T4 read_cache_file")
    # missing
    check("missing → None", pf.read_cache_file("does-not-exist") is None)
    # malformed
    bad = pf.RAW_FETCH_DIR / "bad.json"
    bad.write_text("not json {", encoding="utf-8")
    check("malformed → None", pf.read_cache_file("bad") is None)
    # valid
    good = pf.RAW_FETCH_DIR / "good.json"
    payload = {"kind": "body", "body": "hello", "fetched_at": "2026-05-29T00:00:00+02:00"}
    good.write_text(json.dumps(payload), encoding="utf-8")
    got = pf.read_cache_file("good")
    check("valid → dict", got == payload, str(got)[:80])


def t5_parse_listing_search() -> None:
    print("T5 parse_json_listing_search")
    src = {"id": "m365-roadmap", "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap"}
    results_in = [
        {"title": "Copilot new feature X",
         "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap?id=999",
         "snippet": "Rolling out Q3"},
        {"title": "Random blog about Microsoft",
         "url": "https://thirdparty.example.com/post/1",
         "snippet": "Some snippet"},
        {"title": "", "url": "https://www.microsoft.com/foo", "snippet": "no title — skip"},
        {"title": "Dupe on-domain",
         "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap?id=999",
         "snippet": "should dedup by url"},
    ]
    items = pf.parse_json_listing_search(src, results_in)
    check("3 valid candidates → 2 items (skip empty title + dedup)",
          len(items) == 2, f"got {len(items)}")
    if len(items) >= 2:
        on_dom = next((x for x in items if x["title"] == "Copilot new feature X"), None)
        off_dom = next((x for x in items if x["title"] == "Random blog about Microsoft"), None)
        check("on-domain direct_link=True", on_dom and on_dom.get("direct_link") is True)
        check("on-domain url preserved",
              on_dom and on_dom["url"] == "https://www.microsoft.com/en-us/microsoft-365/roadmap?id=999")
        check("off-domain direct_link=False", off_dom and off_dom.get("direct_link") is False)
        check("off-domain url falls back to source.url",
              off_dom and off_dom["url"] == src["url"])
    # bad input shape
    check("non-list input → []", pf.parse_json_listing_search(src, None) == [])
    check("empty list → []", pf.parse_json_listing_search(src, []) == [])


def t6_pull_source_from_cache_search(tmp: Path) -> None:
    print("T6 pull_source from_cache=True kind=search")
    src = {
        "id": "m365-roadmap",
        "title": "Microsoft 365 Roadmap",
        "category": "m365-copilot-core",
        "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap",
        "feed_type": "json_listing_search",
        "priority": "high", "tags": [],
    }
    cache_file = pf.RAW_FETCH_DIR / f"{src['id']}.json"
    cache_file.write_text(json.dumps({
        "kind": "search",
        "fetched_at": "2026-05-29T01:00:00+02:00",
        "results": [
            {"title": "Roadmap item A",
             "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap?id=111",
             "snippet": "feature A"},
            {"title": "Roadmap item B",
             "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap?id=222",
             "snippet": "feature B"},
        ],
    }), encoding="utf-8")
    items, st, needs = pf.pull_source(src, {}, pf.now_dt(), set(), from_cache=True)
    check("returns 2 items", len(items) == 2, f"got {len(items)}")
    check("state working-from-cache", st["last_status"] == "working-from-cache")
    check("needs_mcp False", needs is False)
    if items:
        check("item has direct_link key", "direct_link" in items[0])
        check("item_id stable sha1[:16]",
              len(items[0]["item_id"]) == 16 and all(c in "0123456789abcdef" for c in items[0]["item_id"]))


def t7_pull_source_phase1_listing(tmp: Path) -> None:
    print("T7 pull_source Phase 1 json_listing_search → needs_mcp")
    src = {
        "id": "azure-updates",
        "title": "Azure Updates",
        "category": "dev-platform",
        "url": "https://azure.microsoft.com/en-us/updates/",
        "feed_type": "json_listing_search",
        "priority": "high", "tags": [],
    }
    items, st, needs = pf.pull_source(src, {}, pf.now_dt(), set(), from_cache=False)
    check("no items returned", items == [])
    check("state needs-mcp", st["last_status"] == "needs-mcp")
    check("needs_mcp True", needs is True)


def t8_pull_source_phase1_fetch_fail(tmp: Path, monkey_fetch_to_none) -> None:
    print("T8 pull_source Phase 1 fetch failure → needs_mcp")
    src = {
        "id": "tc-teams",
        "title": "Teams Blog",
        "category": "workload",
        "url": "https://techcommunity.microsoft.com/.../board",
        "feed_url": "https://techcommunity.microsoft.com/.../rss",
        "feed_type": "rss",
        "priority": "high", "tags": [],
    }
    items, st, needs = pf.pull_source(src, {}, pf.now_dt(), set(), from_cache=False)
    check("no items", items == [])
    check("state failing", st["last_status"] == "failing")
    check("consecutive_failures incremented", st["consecutive_failures"] >= 1)
    check("needs_mcp True", needs is True)


def t9_main_from_cache_scope(tmp: Path) -> None:
    print("T9 main() --from-cache scope")
    # Write a minimal sources.json with two sources
    sources = {
        "_schema": {"version": "1.1.0", "description": "test"},
        "sources": [
            {"id": "m365-roadmap", "title": "MS Roadmap", "category": "m365-copilot-core",
             "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap",
             "feed_type": "json_listing_search", "active": True,
             "priority": "high", "tags": []},
            {"id": "tc-teams", "title": "Teams", "category": "workload",
             "url": "https://techcommunity.microsoft.com/x",
             "feed_url": "https://example.invalid/rss",
             "feed_type": "rss", "active": True, "priority": "high", "tags": []},
        ],
    }
    pf.SOURCES_FILE.write_text(json.dumps(sources), encoding="utf-8")
    # Unreachable manifest restricting to roadmap only
    pf.UNREACHABLE_FILE.write_text(json.dumps({
        "generated_at": pf.now_iso(),
        "phase": "urllib",
        "sources": ["m365-roadmap"],
    }), encoding="utf-8")
    # Cache for roadmap
    (pf.RAW_FETCH_DIR / "m365-roadmap.json").write_text(json.dumps({
        "kind": "search",
        "fetched_at": pf.now_iso(),
        "results": [
            {"title": "Item Z",
             "url": "https://www.microsoft.com/en-us/microsoft-365/roadmap?id=42",
             "snippet": "snip"},
        ],
    }), encoding="utf-8")
    # items.jsonl empty
    pf.ITEMS_FILE.write_text("", encoding="utf-8")
    pf.META_FILE.write_text(json.dumps({}), encoding="utf-8")

    rc = pf.main_with_argv(["--from-cache"])
    check("main() rc==0", rc == 0)
    written = pf.ITEMS_FILE.read_text(encoding="utf-8").strip().splitlines()
    check("1 item written", len(written) == 1, f"got {len(written)} lines")
    if written:
        obj = json.loads(written[0])
        check("item source_id == m365-roadmap", obj["source_id"] == "m365-roadmap")
        check("item url is roadmap?id=42",
              obj["url"] == "https://www.microsoft.com/en-us/microsoft-365/roadmap?id=42")


def t10_main_phase1_writes_unreachable(tmp: Path) -> None:
    print("T10 main() Phase 1 writes unreachable.json")
    # Re-init: empty items, no unreachable
    pf.ITEMS_FILE.write_text("", encoding="utf-8")
    if pf.UNREACHABLE_FILE.exists():
        pf.UNREACHABLE_FILE.unlink()
    # sources.json from T9 still in place; force urllib fetch to fail for tc-teams
    rc = pf.main_with_argv([])
    check("main() rc==0", rc == 0)
    check("unreachable.json exists", pf.UNREACHABLE_FILE.exists())
    if pf.UNREACHABLE_FILE.exists():
        u = json.loads(pf.UNREACHABLE_FILE.read_text(encoding="utf-8"))
        ids = set(u.get("sources", []))
        # roadmap is json_listing_search → always needs MCP
        # tc-teams fetch will fail (example.invalid) → needs MCP
        check("roadmap in unreachable", "m365-roadmap" in ids, str(ids))
        check("tc-teams in unreachable", "tc-teams" in ids, str(ids))


def main_with_argv_shim() -> None:
    """Inject a testable main() wrapper that accepts argv directly."""
    import argparse
    real_main = pf.main

    def main_with_argv(argv: list[str]) -> int:
        old = sys.argv
        try:
            sys.argv = ["pull_feeds.py"] + argv
            return real_main()
        finally:
            sys.argv = old

    pf.main_with_argv = main_with_argv


def run() -> int:
    main_with_argv_shim()
    with tempfile.TemporaryDirectory(prefix="nc-v130-test-") as tmpdir:
        tmp = Path(tmpdir)
        setup_fake_skill(tmp)

        t1_imports()
        t2_is_valid_url()
        t3_domain_match()
        t4_read_cache_file(tmp)
        t5_parse_listing_search()
        t6_pull_source_from_cache_search(tmp)
        t7_pull_source_phase1_listing(tmp)

        # Monkey-patch pf.fetch to always return None for T8
        original_fetch = pf.fetch
        pf.fetch = lambda url: None  # type: ignore[assignment]
        try:
            t8_pull_source_phase1_fetch_fail(tmp, None)
            t9_main_from_cache_scope(tmp)
            t10_main_phase1_writes_unreachable(tmp)
        finally:
            pf.fetch = original_fetch

    # Summary
    print()
    failures = [(n, d) for n, ok, d in results if not ok]
    print(f"=== {len(results) - len(failures)}/{len(results)} passed ===")
    if failures:
        print("FAILURES:")
        for n, d in failures:
            print(f"  • {n}" + (f" — {d}" if d else ""))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(run())
