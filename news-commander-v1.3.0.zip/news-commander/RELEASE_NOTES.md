# News Commander — Release Notes

## Warum es diesen Skill gibt

### Die Herausforderung

Wer beruflich mit Microsoft-Technologie arbeitet — als Cloud Architect, Consultant,
Modern-Work-Specialist, Security-Engineer oder in einer ähnlichen Rolle — kennt das:

- **~50 relevante RSS/Atom-Feeds** aus dem Microsoft-Universum (blog.microsoft.com,
  techcommunity.microsoft.com, devblogs, learn.microsoft.com/updates, Roadmap-Feeds,
  Security-Updates, Industry-Blogs). Plus Tech-Twitter, plus Newsletter,
  plus YouTube-Channels.
- **Massive Redundanz**: Ein Defender-Announcement taucht parallel im Tech-Community-
  Board, im Microsoft-Blog, im Security-Blog und manchmal noch im Roadmap-Feed auf —
  derselbe Inhalt, vier Quellen, vier Klicks zum „Schon gelesen".
- **Kein Themen-Fokus**: RSS-Reader sortieren chronologisch. Aber du willst nicht
  alles — du willst „Was ist heute neu zu Defender XDR, Copilot, Azure OpenAI,
  Entra ID?". Was du **gerade** trackst.
- **Wechselnde Schwerpunkte**: Heute trackst du GPT-5-Rollouts, in drei Monaten
  Copilot-Agents, in einem halben Jahr was komplett anderes. Filter manuell in
  fünf Tools pflegen? Tut keiner.
- **Doom-Scroll-Risiko**: Wer den Reader morgens öffnet, ist 30 Minuten weg.
  Wer es nicht öffnet, verliert den Anschluss.
- **Newsletter-Spam-Days**: Manche Tage haben einfach nichts. Trotzdem Posteingang
  voll. Trotzdem Push-Notifications. Trotzdem das Gefühl, was zu verpassen.

Das Problem ist nicht Mangel an Information. Es ist **schlechtes Signal-Rausch-Verhältnis
und fehlende Personalisierung** auf das, was die Rolle gerade braucht.

### Der Lösungsansatz

News Commander dreht die Logik um:

1. **Topic-zentrisch statt source-zentrisch.** Du definierst Topic-Bundles
   (Defender, Copilot, Azure OpenAI, Roadmap, …) mit Gewichtungen. Jedes Item
   bekommt einen Score = Σ (Topic-Weight × Keyword-Hits). Reihenfolge im Digest
   bestimmt dein Interesse, nicht das Publikationsdatum.

2. **Aggressive Deduplizierung.** SequenceMatcher-basierte Fuzzy-Title-Matches
   (Threshold ≥0.78) fangen Cross-Posts zwischen TC-Boards und Microsoft-Blogs.
   Du siehst jedes Announcement einmal, mit der besten Quelle.

3. **Drei Buckets statt einer Flut.** HIGH (Score ≥2.0) → top-of-digest.
   MEDIUM (≥1.0) → guter Kontext. **Vorschläge** (knapp unter Filter, ≥0.5)
   → „Wäre das relevant? Topic adden?". Letzteres ist die ehrlichste Feature:
   du siehst, was du fast verpasst hättest.

4. **Self-Tunable per Chat.** `News Commander Topic Add gpt-5` im Teams-Self-Chat
   reicht. Der nächste Lauf liest die Nachricht, mutiert `topics.json`, fertig.
   Kein Settings-UI, kein Re-Deploy, kein „erst nachdenken, dann Filter bauen".

5. **Empty-Day-Suppress.** Hat der Tag nichts Wichtiges? Dann kommt **nichts**.
   Keine leere Mail, kein „0 Items"-Push. Stille ist auch eine Antwort.

6. **One-Shot-Channel.** Genau **eine** Nachricht morgens. Teams-Self-Chat oder
   Mail oder beides. Push-Notification statt App-Toggle.

### Was du davon hast

| Vorher | Mit News Commander |
|--------|--------------------|
| 50 RSS-Tabs zum durchklicken | 1 Digest, fertig in 3 Minuten Lesezeit |
| Dieselbe Defender-News in 4 Quellen | Einmal, dedupliziert |
| „Was ist heute zu Topic X?" → drei Searches | Topic-Score zeigt's dir |
| Filter-Pflege in Reader-UI | `Topic Add <keyword>` im Self-Chat |
| Posteingang-Spam an leeren Tagen | Empty-Day-Suppress |
| News-FOMO ohne Plan | Strukturiertes Morgen-Briefing |

Konkret: **3–5 Minuten Lesezeit, 1× am Tag, alles Wichtige drin, nichts doppelt.**

### Architektur-Entscheidungen, die wichtig waren

- **Atomic Writes.** Jeder JSON/JSONL-Write geht über tempfile + fsync + `os.replace`.
  Ein Crash mitten im Schreiben kann State nicht korrupten. Wichtig, weil der Skill
  täglich läuft und nie manuell überwacht wird.
- **Append-only Mirror.** `items.jsonl` wird nur appended, nie umgeschrieben (außer
  bei Archiv-Rotation). Macht den Verlauf rekonstruierbar.
- **Monatliches Archiv mit crash-sicherer Write-Order.** Items >90 Tage werden alle
  30 Tage in `_archive/items-YYYY-MM.jsonl` verschoben — aber so, dass ein Crash
  während der Rotation maximal Dubletten im Archiv erzeugt, niemals Datenverlust.
  Write-Order: (1) append-fsync ins Archiv, (2) atomares Rewrite von `items.jsonl`,
  (3) Meta-Update.
- **Gap-aware Pull-Window.** Wenn der letzte Lauf ausgefallen ist, erweitert der
  nächste Lauf automatisch das Fenster — kein Verpassen.
- **Health-Tracking pro Source.** Drei Fehlversuche in Folge → Auto-Deaktivierung
  am Montag, mit Self-Chat-Notification. Tote Feeds sterben leise, du erfährst es
  einmal pro Woche statt nie oder ständig.
- **Cross-Skill-Integration optional und read-only.** Andere Skills können den
  letzten Digest lesen, aber nicht schreiben. Fehlt News Commander, funktionieren
  sie unverändert.

---

## v1.3.0 — Two-Tier Fallback Pull (Container-Resilienz)

Strukturelles Release, das eine reale Container-Limitierung behebt: aus dem
Skill-Container heraus erreicht `urllib` (Phase 1) bestimmte Microsoft-Hosts
schlicht nicht — `m365-roadmap` (SPA-Listing + JSON-API), `azure-updates`
(SPA-Listing + JSON-API) und die MSRC-CVRF-JSON-API geben `Errno 101 Network
is unreachable`. Im scheduled 03:00-Run fielen damit drei der wichtigsten
Roadmap-/Security-Quellen permanent aus, ohne dass das System es selbst hätte
fixen können. v1.3.0 routet alle solchen Quellen transparent über einen
zweistufigen Fallback: urllib zuerst → bei Unerreichbarkeit Manifest schreiben
→ Agent macht den MCP-Fetch → `pull_feeds.py --from-cache` parst das Ergebnis
mit denselben Parsern wie sonst auch. Mirror-Schema, item_id-Stabilität, atomic
writes, archive — alles unverändert.

### Architektur

Phase 1 (`pull_feeds.py`, default): urllib pro Source, mit 10-Worker-Pool wie
gehabt. Pro Source jetzt 3-Tuple `(items, src_state, needs_mcp)`. Quellen die
nicht erreicht werden (None body / Errno 101) ODER `feed_type ==
"json_listing_search"` haben (kein klassisches Feed) signalisieren
`needs_mcp=True`. Am Ende schreibt der Hauptlauf `data/mirror/unreachable.json`
(`{generated_at, phase: "urllib", sources: [...]}`).

Phase 2 (Agent, scheduled prompt body): liest `unreachable.json` und stößt für
jede gelistete `source_id` parallel den passenden MCP-Fetch an —
`mcp__core__web_search("site:<domain> <search_keyword>")` für listing-Quellen,
`mcp__core__web_fetch(<feed_url>)` für klassische Feeds. Pro Quelle landet
genau eine Datei in `data/mirror/raw-fetch/<source_id>.json` mit einer von zwei
Shapes: `{kind: "body", body: "<rohtext>", fetched_at}` oder
`{kind: "search", results: [{title, url, snippet}, ...], fetched_at}`.

Phase 3 (`pull_feeds.py --from-cache`): liest `unreachable.json`, geht die
gelisteten Source-IDs durch, parst `raw-fetch/<id>.json`. `kind=body` wird je
nach `feed_type` an die vorhandenen RSS-/JSON-Parser geroutet, `kind=search`
geht durch den neuen `parse_json_listing_search` (siehe unten). Items werden
mit Standard-Dedup (`item_id = sha1(source_id+url)[:16]`) gegen den bestehenden
Mirror gemerged. `archive_items.maybe_archive()` wird nur nach Phase 3
getriggert (oder wenn Phase 1 nichts Unerreichbares meldet) — so wird nichts
archiviert, bevor der Fallback laufen konnte.

### Neuer `feed_type: "json_listing_search"`

Für Quellen, die im Browser eine React-/SPA-Listing-Seite sind und deren
JSON-API vom Container nicht erreichbar ist. Aktuell drei:

- `m365-roadmap` — `search_keyword: "Microsoft 365 roadmap feature rolling out"`,
  `search_domain: "microsoft.com"`
- `azure-updates` — `search_keyword: "Azure update generally available preview"`,
  `search_domain: "azure.microsoft.com"`
- `sec-advisories` (MSRC) — `search_keyword: "MSRC security update release note Patch Tuesday"`,
  `search_domain: "msrc.microsoft.com"`

Der Agent füttert die `raw-fetch/<id>.json` per `kind=search` aus
`mcp__core__web_search`, der Parser `parse_json_listing_search` macht daraus
Items (Title, Snippet→Abstract, URL, GUID). **Quellen-Disziplin bleibt erhalten**
durch den neuen Guard `url_matches_source_domain()`: nur wenn der Treffer auf
derselben registrierbaren Domain (last 2 labels, `www.` gestrippt) wie die
Quelle liegt, wird seine URL als Item-URL übernommen (`direct_link=True`).
Off-domain-Treffer fallen sauber auf `source.url` zurück (`direct_link=False`),
damit der Renderer mit der v1.1.3-Link-Hardening den expliziten "Fallback auf
Quellenseite"-Hint zeigt. Kein heimliches Verlinken auf Drittseiten.

### URL-Validation gehärtet

`is_valid_url()` prüft jetzt zusätzlich, dass `urlparse(url).hostname`
nicht leer ist — verhindert dass `https://` oder `https:///path` als gültig
durchgehen. `_base_domain()` normalisiert auf die registrierbare Domain
(letzte 2 Labels, `www.` weg), damit `learn.microsoft.com`,
`azure.microsoft.com`, `msrc.microsoft.com` und `www.microsoft.com` für den
Source-Discipline-Guard alle als `microsoft.com` zählen.

### Tests

Neue Testsuite `scripts/test_pull_v130.py` (52 Checks in 10 Gruppen):
Imports + USER_AGENT-Bump, `is_valid_url`-Edge-Cases, Subdomain-Toleranz von
`url_matches_source_domain`, `read_cache_file` (missing/malformed/valid),
`parse_json_listing_search` (on-domain → direct_link=True,
off-domain → fallback, dedup, leere Titles), `pull_source` mit
`from_cache=True` (kind=search), `pull_source` Phase 1 für
`json_listing_search` (immer `needs_mcp=True`), `pull_source` Phase 1
Fetch-Failure (`consecutive_failures` increment), `main(--from-cache)` mit
Scope-Restriction über `unreachable.json`, und `main()` Phase 1 schreibt
`unreachable.json` korrekt. **52/52 grün** vor Release-Build.

Zusätzlich End-to-End-Live-Test gegen die Real-Welt: Mirror-Reset, Phase 1
urllib-Run (alle 42 aktiven Quellen, `unreachable.json` aufgezeichnet),
parallel-MCP-Fetch über 4 Sub-Agents in `web_search`-Modus (alle unerreichbaren
Quellen befüllt), Phase 3 `--from-cache` — Ergebnis: **42/42 Quellen liefern,
201 Items im Mirror, 199 mit `direct_link=True`, 2 mit sauberem Fallback**.

### Migration v1.2.x → v1.3.0

Keine Schema-Migration nötig. `items.jsonl`, `topics.json`, `source-state.json`,
`preferences.json`, `_meta.json`, `digests/` und `_archive/` bleiben gültig.
`item_id`-Hashes sind stabil (Algorithmus unverändert), d.h. bestehender
Mirror-Stand wird beim ersten v1.3-Pull nicht dupliziert.

Drei `sources.json`-Einträge wechseln intern auf `feed_type:
"json_listing_search"` und tragen jetzt `search_keyword` + `search_domain` —
das mitgelieferte `data/sources.json` enthält den finalen Stand schon.

Eine Verhaltensänderung sichtbar im 03:00-Run: zwischen Phase 1 und Phase 3
liegt jetzt eine kurze Agent-MCP-Phase (Sekundenbereich, parallel pro Source).
Der scheduled-prompt body in `scheduled-prompts/daily-news-run.md` ist
entsprechend angepasst, damit der Agent weiß: nach `pull_feeds.py` zuerst
`unreachable.json` lesen, MCP-Fetch ausführen, dann
`pull_feeds.py --from-cache`.

---

## v1.2.1 — Kategorie-Audit + Tag-Enrichment

Kleinerer Release auf Basis Content-Audit aller 42 aktiven Quellen. Drei Themen: (1) **Vier neue Kategorien** aus den tatsaechlichen Inhalten abgeleitet — `identity-iam`, `agents-core`, `browser-web`, `windows-tooling` — statt Forced-Fit in bestehende Buckets; (2) **Vier Re-Buckets** (`tc-entra` → identity-iam, `agents-hub` → agents-core, `edge-blog` → browser-web, `tc-sysinternals` → windows-tooling); (3) **19 Quellen mit Produkt-Tags angereichert** (copilot-in-excel, defender-xdr, copilot-studio, agent-builder, mcp, ai-foundry, …) damit das Topic-Scoring auch beim Substring-Match auf Tags greift — Kategorien bleiben sekundaerer Lookup-Index, primaeres Signal ist und bleibt der Topic-Score auf Title+Abstract+Tags.

### Neue Kategorien

| Kategorie | Warum | Quelle(n) |
|-----------|-------|-----------|
| `identity-iam` | Entra/Identity ist eigene Domaene, nicht generische Security | tc-entra |
| `agents-core` | Agents/MCP/Agent-Builder als eigenstaendiges Thema, nicht Dev-Subset | agents-hub |
| `browser-web` | Edge Copilot-Mode + agentic browsing braucht eigenes Bucket | edge-blog |
| `windows-tooling` | Sysinternals ist Tooling, nicht Dev-Platform | tc-sysinternals |

### Re-Buckets (4)

- `tc-entra` — security → **identity-iam** (Inhalte sind reine IAM)
- `agents-hub` — dev-platform → **agents-core** (Learn-Hub fuer Agent-Framework/MCP)
- `edge-blog` — windows → **browser-web** (Copilot-Mode + Browser-Roadmap)
- `tc-sysinternals` — dev-platform → **windows-tooling** (Troubleshoot-Tools)

### Tag-Enrichment (19 Sources)

Neue produktnahe Substring-Tags zur Verbesserung der Score-Trefferquote — ohne dass die Kategorie zum primaeren Filter wird:

- `techwiese-events`, `techwiese-aktuell` — DE-Community/Events plus Azure/Foundry/Agents
- `news-signal`, `microsoft-ai-news` — Strategy/AI Chair-CTO, Azure-OpenAI, Copilot-Studio
- `on-the-issues` — EU-Data-Boundary, DMA, AI-Act
- `tc-m365copilot`, `m365-blog`, `m365-dev-blog`, `m365-roadmap`, `tc-m365blog` — Copilot-Chat, Business-Chat, Loop, Clipchamp, Designer, Outlook, Teams, Graph-API, Teams-Toolkit, Copilot-Extensibility, Agents, Agent-Builder, Purview, Viva
- `tc-excel`, `tc-outlook`, `tc-teams`, `tc-sharepoint`, `tc-eos` — Copilot-in-Excel, Python-in-Excel, Copilot-in-Outlook, New-Outlook, Teams-Rooms, Teams-Premium, Copilot-in-Teams, Copilot-in-SharePoint, Syntex, Lists, Windows-10-EOS, Office-2019/2021-EOS, M365-Apps
- `tc-security`, `security-blog`, `msrc-blog`, `sec-advisories` — Defender-XDR, Sentinel, Purview, Defender-for-Cloud, Copilot-for-Security, CVE, Patch-Tuesday
- `tc-entra` — Entra-ID, Conditional-Access, Verified-ID, External-ID, Privileged-Identity
- `vs-blog`, `powershell-blog`, `tc-mechanics`, `tc-sysinternals`, `agents-hub`, `azure-updates` — Agents, Copilot, PowerShell-Gallery, Cross-Workload-Tech-Deepdives, Fabric, AI-Foundry, Arc, Process-Explorer, Procmon, Autoruns, MCP, Agent-Framework
- `pp-blog`, `pp-apps`, `pp-automate` — Copilot-Studio, Agent-Builder, MCP, Dataverse, Canvas, AI-Builder, Cloud-Flows, Desktop-Flows
- `edge-blog` — Agentic-Browsing, Copilot-Mode, WebView2, PWA, Manifest-V3
- `adoption-portal`, `adoption-release` — Events, Webinars, Training (Adoption-Portal liefert verlinkte Events/Webinars/Trainings)
- `msft-de-events`, `adoption-customer-hub` — bereits in v1.2.0 als Event-Quellen eingefuehrt, jetzt Tag-konsolidiert (Copilot, Copilot-Chat, Agents, Adoption, Training, Events)

### Design-Entscheidung — Kategorien bleiben sekundaerer Index

Ein User-Feedback im Audit war eindeutig: Kategorien sollen nicht zum Hauptfilter werden, weil sich Inhalte verschieben (`vs-blog` liefert zunehmend Copilot/Agents-Content) und Kategorie-basiertes Filtern dann genau die Items wegblendet, die der User eigentlich sehen will. Konsequenz im Audit:

- Kategorien sind ausschliesslich **Lookup-Hilfe** (sources-Auflistung, Status-Anzeige, ggf. ad-hoc Filter „nur Security-Quellen").
- Topic-Scoring laeuft weiterhin ueber **Title + Abstract + Tags** (`sources.json[item.source_id].tags` als Substring-Pool im Matching).
- Daher Tag-Enrichment statt Kategorie-Multiplikator. Wenn z.B. `copilot-in-excel` als Substring im Topic-Keyword matcht, traegt das Tag den Score — egal welcher Kategorie die Quelle zugeordnet ist.

### Geaendert

- **`_schema.categories`** in `sources.json` — 4 neue Kategorien hinzugefuegt (`identity-iam`, `agents-core`, `browser-web`, `windows-tooling`).
- **`_schema.version`** ggf. 1.0.0 → 1.0.1 (optional; Schema-Felder unveraendert, nur Kategorie-Vokabular erweitert).
- **`USER_AGENT`** → `NewsCommander/1.2.1`.
- **`SKILL.md`** Frontmatter, Banner-Subtitle (neue v1.2.1-Zeilen) und Heading auf v1.2.1 gehoben.

### Migration v1.2.0 → v1.2.1

**Keine Schema-Migration noetig, keine Mirror-Rotation, kein Re-Pull noetig.**

- `item_id = sha1(source_id+url)[:16]` bleibt stabil — Re-Bucketing und Tag-Enrichment beruehren weder `source_id` noch URL-Konvention.
- `items.jsonl` braucht weder Rewrite noch Archiv-Rotation.
- Bestehende `topics.json`, `_meta.json`, `preferences.json`, `source-state.json` bleiben unveraendert gueltig.
- Der naechste Pull-Lauf liest die erweiterten Tags direkt aus `sources.json` und benutzt sie ab dem ersten neuen Item im Scoring — alte Items behalten ihre bisherigen Scores; das ist gewollt (kein retroaktives Re-Scoring).

---

## v1.2.0 — Source-Catalog-Cleanup + Parallel-Pull + Mehr JSON-APIs

Mittelgroßer Release auf Basis Realtest-Feedback und Quellen-Validierung. Drei Themen: (1) **Quellen-Hygiene** — 6 dauerhaft kaputte Sources rausgeworfen statt weiter im aktiven Katalog mitzuschleppen; (2) **Mehr offizielle JSON-APIs** — MSRC Security Updates und Azure Updates werden jetzt analog zur M365-Roadmap über die offiziellen Release-Communications-/CVRF-Endpoints gezogen statt über fragile HTML-Scrape; (3) **Pull-Phase parallelisiert** — `ThreadPoolExecutor` mit 10 Workern reduziert den Lauf von ~80s (sequenziell, 40 Quellen × TIMEOUT=20s Worst-Case) auf ~10-15s.

### Entfernt (6 Sources)

Quellen, die im Validation-Pass (Skript-extern via `web_fetch`) keinen einzigen Item mehr lieferten — entweder defunct, umbenannt, oder vom Container nicht erreichbar. Statt sie weiter zu polling-en und das `consecutive_failures`-Tracking voll laufen zu lassen, jetzt explizit raus und in `removed[]` in `sources.json` dokumentiert:

| Source | Grund |
|--------|-------|
| `techwiese-itpro` | Feed liefert nur noch `<title>Microsoft</title>`, keine Items mehr — defunct |
| `tc-copilot-studio` | TechCommunity board.id 404 — Board vermutlich umbenannt; manueller Re-Discover nötig |
| `tc-copilot-events` | HTML-Eventseite liefert kein parsbares Listing mehr |
| `tc-planner` | TechCommunity board.id 404 — Board umbenannt |
| `tc-skills-hub` | TechCommunity board.id 404 — Board umbenannt |
| `amc-rss` (`aka.ms/AMC/RSS`) | Auth-Wall, vom Container nicht erreichbar; ersetzt durch `_placeholder_internal`-Slot |

Aktiver Katalog ist damit von 46 auf 40 Quellen geschrumpft — saubereres Signal, weniger Rauschen in den Source-Health-Logs.

### Neu

- **MSRC Security Updates via CVRF v3.0 JSON-API** — Neue Source `sec-advisories` mit `feed_type: "json_msrc_cvrf"` zieht jetzt `https://api.msrc.microsoft.com/cvrf/v3.0/updates`. Antwort hat Top-Level `value: [...]` mit `ID`, `DocumentTitle`, `CurrentReleaseDate`, `InitialReleaseDate`. Per-Item-URL via Template `https://msrc.microsoft.com/update-guide/releaseNote/{ID}`. Liefert die monatlichen Patch-Tuesday-Releases als saubere Items mit verlässlichem Datum.
- **Azure Updates via offizieller JSON-API** — `azure-updates` mit neuem `feed_type: "json_azure_updates"` und Endpoint `https://www.microsoft.com/releasecommunications/api/v1/azure`. Selbes Field-Schema wie der M365-Roadmap-Parser, per-Item-URL via `https://azure.microsoft.com/en-us/updates?id={id}`. Stabiler als die alte Marketing-Page-Scrape.
- **`PULL_PARALLELISM = 10`** — Neue Konstante in `pull_feeds.py`. Pull-Phase läuft jetzt in einem `ThreadPoolExecutor(max_workers=10)` statt sequenziell. Thread-Sicherheit gegeben, weil (a) jeder Worker bearbeitet eine eindeutige `source_id` (keine State-Kollision), (b) `item_id = sha1(source_id+url)[:16]` ist per Definition source-skopiert (kein Cross-Worker-Dedup nötig), (c) `existing_ids` als Read-Snapshot übergeben und im Main-Thread final ge-dedupt, (d) File-Writes (`append_items`, `save_json`) bleiben sequenziell im Main-Thread. Defensive Per-Worker-`try/except` damit ein einzelner Source-Crash nicht den Pool kippt. Elapsed-Time wird am Ende geloggt für Performance-Monitoring.

### Geändert

- **`USER_AGENT`** → `NewsCommander/1.2.0`.
- **`source-state.json`** — 6 Orphan-Einträge der entfernten Sources rausgeräumt (39 Health-Einträge statt 45).
- **Banner-Untertitel** — neue v1.2.0-Zeilen zu Source-Cleanup, Azure/MSRC-JSON-APIs und Pull-Parallelisierung.

### Migration v1.1.3 → v1.2.0

Keine Schema-Migration nötig. Bestehende `items.jsonl`, `topics.json`, `_meta.json`, `preferences.json` bleiben unverändert gültig. Mirror-Dedup-Hashes (`item_id`) sind stabil, weil sich für die verbleibenden Sources weder `source_id` noch URL-Konvention geändert hat. `source-state.json` darf Orphans für die 6 entfernten Sources enthalten — sie werden vom nächsten Lauf ignoriert; das v1.2.0-Cleanup hat sie zusätzlich entfernt.

Wer Azure Updates oder MSRC Advisories bereits vor v1.2.0 als RSS-/HTML-Scrape-Source betrieben hat: die neuen JSON-Sources liefern eigene `item_id`-Hashes (anderes URL-Pattern), d.h. die ersten Läufe nach Upgrade können temporär Dubletten zu alten Mirror-Einträgen erzeugen, bis die alten >90 Tage sind und ins `_archive/` rotieren. Bei strikter Dedup-Anforderung: alte Items vor erstem v1.2.0-Lauf manuell aus `items.jsonl` greppen.

---

## v1.1.3 — Roadmap-API + Link-Hardening Patch

Kleiner Patch-Release auf Basis von Realtest-Feedback. In v1.1.2 ist beim Probelauf aufgefallen, dass (a) die M365-Roadmap-Quelle praktisch keine Items lieferte (React-SPA, HTML-Scrape findet keine Per-Item-Hrefs) und (b) einige Digest-Items ohne klickbaren Link auftauchten — vor allem Roadmap-Einträge und Events. Beide Probleme sind jetzt gefixt, ohne den Mirror-State zu brechen.

### Geändert

- **M365 Roadmap via offizieller JSON-API** — Statt der bisherigen HTML-Scrape (`https://www.microsoft.com/en-us/microsoft-365/roadmap`) wird jetzt der öffentliche Release-Communications-Endpoint `https://www.microsoft.com/releasecommunications/api/v2/m365` benutzt. Neuer `feed_type: "json_m365_roadmap"` parst die API-Antwort (Top-Level-Liste oder Wrapper-Dict mit `value`/`items`/`results`/`data`), extrahiert `id`, `title`, `description`, `modified`/`created` und baut die Per-Item-URL über das Template `https://www.microsoft.com/microsoft-365/roadmap?id={id}`. Roadmap-Items haben jetzt verlässlich Title, Abstract, Datum und Direktlink.
- **Link-Hardening: Fallback auf Quellenseite mit Hinweis** — Im Render-Pfad (`send_digest.py`) prüft eine neue `effective_url(item)`-Helper-Funktion zur Sendezeit, ob die Item-URL valide ist (`http(s)://`, kein leerer Anchor, kein `javascript:`/`mailto:`). Wenn nicht, fällt das Rendering auf die `source_url` (Quellenseite) zurück und zeigt explizit den Hinweis ⚠️ _Direktlink fehlt — Fallback auf Quellenseite_ plus eine separate „🔗 Zur Quelle (<Source>)"-Zeile. Der User sieht sofort, dass der Klick zur Listenseite führt, nicht zum konkreten Artikel. Kein stilles Klick-ins-Nichts mehr.
- **Strenge URL-Validierung** — Neue `is_valid_url()`-Helpers (in `pull_feeds.py` und `send_digest.py`, modul-unabhängig dupliziert) blocken Pseudolinks (leerer Anchor, `javascript:`, `mailto:`) zuverlässig.
- **`source_url`-Feld pro Item** — Neuer optionaler Schlüssel im Mirror-Item-Schema (`source_url: <Quellen-Hauptseite>`), nötig für den Render-Fallback. Wird beim Pull aus `sources.json[item.source_id].url` befüllt.
- **Render-time-Validierung statt Pull-time-Drop** — bewusst so designt: `item_id = sha1(source_id + url)[:16]` bleibt stabil, weil URL-Validierung erst beim Render passiert. Mirror-Dedup-Hashes shiften nicht, auch wenn sich später herausstellt, dass ein Item-Link kaputt war.
- **Banner-Untertitel um v1.1.3-Zeilen ergänzt** — neue Hinweise zur Roadmap-API und zum Link-Hardening direkt im ASCII-Banner.

### Migration v1.1.2 → v1.1.3

Keine Schema-Migration nötig. Items im bestehenden `items.jsonl` ohne `source_url` werden vom Renderer ohne Fallback-Mechanik behandelt (alte Items zeigen sich genauso wie früher). Neue Items ab v1.1.3 enthalten `source_url` automatisch. Mirror-Dedup-Hashes bleiben stabil. Bestehende `topics.json`, `source-state.json`, `_meta.json`, `preferences.json` bleiben unverändert gültig.

Eine einzelne `sources.json`-Änderung muss übernommen werden: die `m365-roadmap`-Quelle bekommt `feed_url: "https://www.microsoft.com/releasecommunications/api/v2/m365"` und `feed_type: "json_m365_roadmap"`. Die ausgelieferte v1.1.3-`sources.json` enthält den Update bereits.

---

## v1.1.2 — Source-Discipline Patch

Kleiner Patch-Release auf Basis von Realtest-Feedback. In v1.1.1 ist es einmal vorgekommen, dass der Skill auf eine Folgefrage hin **autonom Internet-Inhalte ergänzt** hat, die nicht aus den definierten Quellen kamen. Genau das soll News Commander nicht tun: er ist ein Triage-System auf einer kuratierten Quellenliste, kein generischer Web-Researcher.

### Geändert

- **Neue HARD RULE „Quellen-Disziplin" in `SKILL.md`** — der Skill arbeitet ausschließlich auf `data/sources.json` und `data/mirror/items.jsonl`. Externe Tools (`web_search`, `web_fetch`, `deep-research`, `SearchM365` für News-Lookups) sind **per Default verboten**, solange der User sie nicht explizit für die aktuelle Frage freigibt.
- **Explizites Nachfragen bei Lücke** — Wenn die Mirror-Daten eine User-Frage nicht beantworten, MUSS der Skill genau eine `AskUserQuestion` stellen mit den Optionen (a) extern recherchieren, (b) bei den definierten Quellen bleiben, oder (c) Topic adden und auf den nächsten Pull warten. Erst nach explizitem „Ja" werden Web-Tools aufgerufen — und auch nur für genau diese Frage, nicht als Dauerfreigabe.
- **Pretraining-Wissen nicht als Quelle ausgeben** — Wenn der Skill etwas „weiß", was nicht im Mirror steht, darf er es nicht so präsentieren, als käme es aus den Quellen. Entweder als unsicher markieren UND fragen, oder weglassen.
- **Startscreen-Banner um Skill-Beschreibung erweitert** — Analog zum AccountRadar-Startscreen jetzt mit Kurz-Doku (was er pullt, Filter-Logik, Buckets, Delivery) plus expliziter v1.1.2-Hinweis-Zeile, dass Quellen-Disziplin als HARD RULE gilt. Footer: „More Playful AI at https://jaysons.dev".

### Migration v1.1.1 → v1.1.2

Keine Datei- oder Schema-Migration nötig. Nur `SKILL.md` (neue HARD RULE + Banner) und `README.md`/Release-Notes. Bestehende `items.jsonl`, `topics.json`, `source-state.json`, `_meta.json`, `preferences.json` bleiben unverändert gültig.

---

## v1.1.1 — Usability Patch

Kleiner Patch-Release auf Basis von Realtest-Feedback. Inhalte und Architektur identisch zu v1.1.0; drei Usability-Fixes:

### Geändert

- **Banner-Display als HARD RULE** — Das ASCII-Art-Banner wird jetzt verbindlich als erste Ausgabe bei jedem manuellen Trigger gerendert (vor anderem Text, vor Tool-Calls). In v1.1.0 wurde der Banner bei manchen User-Triggern nicht angezeigt; das ist behoben.
- **Explizite „Vollständiger Artikel öffnen"-Links** — Pro Item erscheint jetzt zusätzlich zum Title-Link eine eigene Call-to-Action-Zeile mit Link zum vollständigen Artikel. Sowohl im Teams-Self-Chat-Markdown als auch im HTML-Mail-Render.
- **Mehr Luft zwischen Themenblöcken** — Sektions-Separator (`---`) zwischen counts und HIGH/MEDIUM/WATCH, doppelter Zeilenabstand zwischen Items im Markdown. Im HTML-Mail größere `<hr>`-Margins (36px), Item-Container mit 28px Bottom-Margin + Border, Abstract mit line-height 1.5.

### Migration v1.1.0 → v1.1.1

Keine Migration nötig. Nur Template- und Render-Änderungen plus SKILL.md-Header. Bestehende `items.jsonl`, `topics.json`, `source-state.json`, `_meta.json` bleiben valide.

---

## v1.1.0 — Community Release

Erste vollständig öffentliche Community-Release-Version. Bündelt alle v0.2.0-Features in einem packetierten Zustand, fügt Konsistenz- und Performance-Härtungen hinzu und ist als ZIP teilbar.

### Neu

- **Public-Repo-Ready**
  Skill ist komplett scrubbed — keine internen Pfade, Mail-Adressen, Namen oder Tenant-IDs. Alle User-Daten liegen in `data/preferences.json` (gitignored). Template `data/preferences.example.json` ist Copy-and-Edit-ready.

- **Hardened Cross-Skill-Integration**
  Optionale, read-only Hooks für `daily-ops-ms`, `account-radar` und `fasttrack`/`fasttracker`. Detection still und fehlen-still — wenn der andere Skill nicht installiert ist, läuft News Commander unverändert. Keine Frage, kein Mecker.

- **Konsistenz-Audit bestanden**
  Alle Python-Scripts py_compile-clean. Alle JSONs valide. Cross-References (SKILL.md ↔ scheduled-prompts ↔ scripts ↔ data/) konsistent gegen das v1.1-Layout.

### Geändert gegenüber v0.2.0

- **Versionierung**: Skill-Stand jetzt v1.1.0 (Frontmatter, Banner, Heading) — semantischer Hinweis, dass die API/Datei-Struktur stabil ist und für Community-Adoption taugt.
- **Dokumentation**: Cross-Skill-Integration-Tabelle in `SKILL.md` deckt jetzt alle drei Konsumenten ab (statt nur DOPS). Datei-Struktur-Tree spiegelt Atomic-Writes-Module, Archive-Rotation und Template-File.

### Bekannte Limits (unverändert von v0.2.0)

- Eine Schedule-Instanz pro Skill.
- Kein Cross-Tenant-Tagging (Multi-Customer-Workflows kommen frühestens v1.3).
- HTML-Scraping fragil; Health-Tracking fängt's auf, aber manueller Selector-Update bleibt nötig.

### Migration v0.2 → v1.1

Keine Code-Migration nötig. Reines Versions-Re-Labeling plus Community-Härtung. Bestehende `items.jsonl`, `topics.json`, `source-state.json`, `_meta.json` bleiben gültig.

---

## v0.2.0 — Initial Public Release

### Neu

- **Atomic-Write-Modul (`_atomic.py`)**
  Geteiltes Modul für tempfile + fsync + `os.replace`-Pattern, exposed als
  `atomic_save_json()` und `atomic_write_text()`. Verwendet von allen vier
  Mutations-Scripts (`pull_feeds`, `filter_and_rank`, `intake_topics`,
  `send_digest`) sowie `archive_items`.

- **Monatliche Archiv-Rotation (`archive_items.py`)**
  Alle 30 Tage werden Items älter als 90 Tage in `data/mirror/_archive/items-YYYY-MM.jsonl`
  ausgelagert. Crash-sichere Write-Order: archive-append → items.jsonl-rewrite →
  meta-update. Worst-Case ist Dublette im Archiv, niemals Datenverlust. Lauf-Kadenz
  und Min-Age sind per CLI-Flag override-bar (`--interval-days`, `--min-age-days`).

- **Auto-Trigger in `pull_feeds.py`**
  Am Ende jedes Pulls wird `archive_items.maybe_archive()` automatisch aufgerufen.
  Kein separater Schedule, kein Cron-Eintrag. Fehler im Archiv-Step sind explizit
  non-fatal — Pull bleibt grün auch wenn Rotation crasht.

- **Gap-aware Pull-Window**
  `compute_window_start()` checkt `_meta.last_run.morning_pull_ts`. Liegt der
  letzte erfolgreiche Lauf >36h zurück (Schedule down, manueller Skip), wird das
  Fenster auf `(now − last_run) + 6h Overlap` erweitert. Verpasstes wird nachgeholt.

- **Source-Health-Tracking**
  `data/mirror/source-state.json` trackt pro Source `last_pull_ts`, `last_status`
  (`working` / `empty` / `failing`) und `consecutive_failures`. Ab 3 Fehlern in
  Folge wird die Source am nächsten Montag automatisch deaktiviert, mit
  Self-Chat-Notification.

- **Cross-Skill-Integration-Hooks**
  - `daily-ops-ms`: kann den letzten Digest read-only via `DOPS news`-Trigger
    abrufen. News Commander liest umgekehrt `daily-ops-ms/data/links.json` als
    zusätzliches Topic-Signal (+0.3 Score-Boost bei Tag-Match).
  - `account-radar`: bei Customer-Snapshot werden MS-News-Items, die zu den
    Customer-Topics matchen, als „MS-side context"-Beilage angeboten.
  - `fasttrack`: vor einem Deliverable-Brief wird gecheckt, ob der Digest in
    den letzten 14 Tagen relevante Roadmap-/Wave-Items für das Deliverable hatte.

  Alle drei Integrationen sind **optional, still und read-only** — fehlt News
  Commander, funktionieren die anderen Skills unverändert.

- **`preferences.example.json`-Template**
  Erst-Setup über Copy-and-Edit. Echte `preferences.json` ist gitignoriert,
  damit nichts Persönliches im Repo landet.

### Geändert

- **`scheduled-prompts/daily-news-run.md` SCHRITT 2**
  Dokumentiert den Auto-Archive-Trigger im Pull-Script. Kein eigener SCHRITT für
  Archivierung mehr nötig.

- **`scheduled-prompts/daily-news-run.md` SCHRITT 6**
  Vereinfacht. `morning_pull_ts` und `total_pull_runs` werden bereits vom
  Pull-Script geschrieben. Hier nur noch `total_runs += 1` als Gesamt-Zähler.

- **`source-state.json`-Schema**
  `last_guid`-Feld entfernt (überflüssig — Mirror-Dedup übernimmt). Reduziert
  Schema auf das, was wirklich relevant ist: Health-Tracking.

### Migration v0.1 → v0.2

Keine Migration nötig. Alle Änderungen sind additiv:

- Bestehende `items.jsonl`-Files bleiben gültig.
- `source-state.json` ohne `last_guid` wird automatisch gelesen, das Feld einfach
  ignoriert.
- Erster Lauf nach Upgrade setzt `_meta.last_archive_ts`, danach läuft Rotation
  alle 30 Tage automatisch.

### Bekannte Limits

- **Eine Schedule-Instanz pro Skill.** Wer Mehrfach-Schedules will (z.B. Morning-
  und Evening-Digest), braucht zwei separate Scheduled-Prompts mit unterschiedlichen
  Modi.
- **Kein Cross-Tenant-Tagging.** Multi-Customer-Workflows kommen frühestens v0.4.
- **HTML-Scraping fragil.** Sources ohne RSS/Atom werden via BeautifulSoup geparst —
  bei Re-Designs der Quelle bricht das. Health-Tracking fängt es auf, aber manueller
  Selector-Update bleibt nötig.

---

## Coming next (nicht committed)

- **v0.3** — Pro-Item-Sentiment-Klassifikation: announce vs. fix vs. EOL vs. preview.
  Weekly-Digest-Modus (Mo Morgen mit Wochen-Summary).
- **v0.4** — Cross-Tenant-Tagging für Multi-Customer-Workflows. Adaptive-Card-GUI
  im Self-Chat statt nur Markdown.
- **Open**: Topic-Bundles für andere Rollen — Security-Architect, Modern-Work-
  Specialist, Data-and-AI-Lead. Wer eines hat, gerne als PR.

---

## Lizenz

MIT. Quellen in `sources.json` sind ausschließlich öffentliche Microsoft-Domains
(blog.microsoft.com, techcommunity.microsoft.com, learn.microsoft.com, etc.);
deren Inhalte unterliegen den jeweiligen Microsoft-Terms.
