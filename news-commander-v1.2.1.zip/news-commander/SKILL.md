---
name: news-commander
version: 1.2.1
description: |
  Persönliches News-Aggregations- und Triage-System für Microsoft-Rollen.
  Zieht täglich um 03:00 Europe/Berlin ~50 öffentliche Microsoft-Quellen
  (RSS + HTML-Scrape), spiegelt Items (Title, Abstract, Date, Link) lokal
  in delta-only-Manier, filtert topic-zentrisch gegen ein gewichtetes
  Keyword-Bundle und liefert einen kompakten Digest mit drei Sektionen
  (HIGH, MEDIUM, VORSCHLÄGE) entweder in den Teams-Self-Chat oder per Mail.

  Topic-zentrisch (NICHT quellen-zentrisch) — Score = sum(weight * hit_count)
  über Title + Abstract + Source-Tags. HIGH ≥2.0, MEDIUM ≥1.0, WATCH ≥0.5.
  Items knapp unter dem Filter landen in Sektion "Vorschläge" mit Disclaimer
  "würde mit aktuellen Filtern rausfallen — Topic adden?".

  Anti-Echo-Dedup (fuzzy Title-Match) entfernt Dubletten zwischen
  TechCommunity-Boards und blog.microsoft.com-Hauptseiten. Empty-Day-Suppress:
  Wenn HIGH+MEDIUM=0 und Vorschläge=0 → kein Digest verschickt.

  Intake-Kanal: Teams-Self-Chat-Keywords
    "News Commander Topic Add <keyword>"
    "News Commander Topic Drop <keyword>"
  werden bei jedem Morning-Run gescannt; Topic-Map wird angepasst, Verlauf
  in topics.json.history festgehalten.

  Integration mit daily-ops-ms (optional): Wenn DOPS installiert ist, liest
  News Commander dessen `links.json` als zusätzliches Topic-Signal (Tags,
  Audience). DOPS bekommt das Command "DOPS news" hinzugefügt, um den Digest
  on-demand abzurufen.

  Primäre Trigger:
  "News Commander start", "News Commander", "NC start", "NC briefing",
  "NC digest", "DOPS news" (wenn DOPS installiert),
  "News Commander Topic Add ...", "News Commander Topic Drop ...",
  "News Commander pause", "News Commander resume", "News Commander status",
  "News Commander quellen", "News Commander sources".

  Sekundäre Trigger (natürliche Phrasen):
  "MS-News heute", "was gibt's Neues bei Microsoft", "News-Digest",
  "Copilot-News", "Defender-News", "Roadmap-News".

  Do NOT use for: allgemeine Web-Suche zu beliebigen Themen
  (use built-in web_search oder deep-research). Konkrete Customer-Newsfeeds
  (use account-radar oder strategic-customer-research). Wettervorhersagen,
  Nachrichten außerhalb Microsoft-Ökosystem.

visibility: personal
cowork:
  category: productivity
  audience: csa-microsoft
---

## ⚠️ HARD RULE — Banner zuerst (MUST)

**Bei JEDEM manuellen User-Trigger** (`News Commander`, `NC start`, `NC briefing`,
`NC digest`, `NC status`, `MS-News heute`, „was gibt's Neues bei Microsoft", etc.)
muss die **erste Ausgabe** im Response der ASCII-Banner unten sein — als
Markdown-Codeblock (```), unverändert, vor jeder anderen Antwort, vor jedem
Tool-Call.

Ausnahmen (nur dann KEIN Banner):
- Scheduled Run um 03:00 (autonom, kein User-Sichtbar)
- Async-Self-Chat-Intake (`News Commander Topic Add/Drop ...` Nachrichten)
- Wenn `_meta.json.banner_shown_session_ids[]` die aktuelle Session-ID schon enthält

Verstoß = der Skill fühlt sich für den User nicht an wie News Commander. Banner
ist die Identität. Niemals weglassen.

```
 ███╗   ██╗███████╗██╗    ██╗███████╗
 ████╗  ██║██╔════╝██║    ██║██╔════╝
 ██╔██╗ ██║█████╗  ██║ █╗ ██║███████╗
 ██║╚██╗██║██╔══╝  ██║███╗██║╚════██║
 ██║ ╚████║███████╗╚███╔███╔╝███████║
 ╚═╝  ╚═══╝╚══════╝ ╚══╝╚══╝ ╚══════╝
  ██████╗ ██████╗ ███╗   ███╗███╗   ███╗ █████╗ ███╗   ██╗██████╗ ███████╗██████╗
 ██╔════╝██╔═══██╗████╗ ████║████╗ ████║██╔══██╗████╗  ██║██╔══██╗██╔════╝██╔══██╗
 ██║     ██║   ██║██╔████╔██║██╔████╔██║███████║██╔██╗ ██║██║  ██║█████╗  ██████╔╝
 ██║     ██║   ██║██║╚██╔╝██║██║╚██╔╝██║██╔══██║██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗
 ╚██████╗╚██████╔╝██║ ╚═╝ ██║██║ ╚═╝ ██║██║  ██║██║ ╚████║██████╔╝███████╗██║  ██║
  ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝

         D A I L Y   M S   N E W S   T R I A G E


  News Commander v1.2.1
  <YYYY-MM-DD>

  > pullt täglich um 03:00 Europe/Berlin ~50 öffentliche Microsoft-Quellen
  > (RSS/Atom + HTML-Scrape: blog.microsoft.com, techcommunity, devblogs,
  >  M365 Roadmap, Security, Power Platform, Industry-Blogs, …)
  > topic-zentrische Filterung statt chronologisches Doom-Scrolling
  > Anti-Echo-Dedup (fuzzy Title ≥0.78) entfernt Cross-Posts
  > drei Buckets: HIGH (≥2.0) · MEDIUM (≥1.0) · Vorschläge (≥0.5)
  > Empty-Day-Suppress · Self-Tunable per Self-Chat-Keyword
  > Delivery: Teams 1:1-Self-Chat ODER Outlook-Mail an dich selbst
  > v1.1.2: Quellen-Disziplin als HARD RULE — keine autonomen Web-Lookups
  >         mehr; bei Lücke wird explizit nach Freigabe gefragt
  > v1.1.3: M365-Roadmap via offizieller JSON-API (statt React-SPA-Scrape);
  >         Link-Hardening: ungültige Item-URLs → Fallback auf Quellenseite
  >         mit sichtbarem Hinweis statt stillem Klick-ins-Nichts
  > v1.2.0: Source-Catalog-Cleanup — 6 dauerhaft kaputte Quellen (techwiese-itpro,
  >         tc-copilot-studio/-events, tc-planner, tc-skills-hub, amc-rss) raus;
  >         Azure-Updates + MSRC-CVRF jetzt via offizieller JSON-API;
  >         Pull-Phase parallelisiert (ThreadPoolExecutor, 10 Worker) —
  >         40-Source-Lauf von ~80s auf ~10-15s
  > v1.2.1: Kategorie-Audit aus echten Inhalten — 4 neue Kategorien
  >         (identity-iam, agents-core, browser-web, windows-tooling),
  >         19 Quellen mit Produkt-Tags angereichert (copilot-in-excel,
  >         defender-xdr, copilot-studio, agent-builder, mcp, ai-foundry, …)
  >         Mirror-safe: item_id = sha1(source_id+url) bleibt stabil,
  >         keine Rotation, kein Re-Pull noetig

  More Playful AI at https://jaysons.dev
```

## ⚠️ HARD RULE — Quellen-Disziplin (MUST)

**News Commander arbeitet AUSSCHLIESSLICH auf den in `data/sources.json`
definierten Quellen und dem daraus gespeisten Mirror `data/mirror/items.jsonl`.**

Verbindlich für JEDEN Trigger, JEDE Folgefrage, JEDE Konversation im Kontext
dieses Skills (`News Commander`, `NC *`, `MS-News heute`, „was gibt's Neues bei
Microsoft", `DOPS news`, Follow-ups zu Digest-Items, Topic-Vorschläge,
Quellen-Auskunft, Hintergrund-Recherche zu einem Item, etc.):

1. **Antworten basieren nur auf Mirror-Inhalten.** Title, Abstract, URL,
   Source-Tags, pubDate, Score — was in `items.jsonl` (inkl. `_archive/`) und
   in `sources.json` steht, darf verwendet werden. Sonst nichts.

2. **KEINE autonomen externen Recherchen — außer auf kuratierten Quellen.**
   `web_search`, `deep-research`, `SearchM365` für News-Lookups, Wikipedia-
   Lookups, „aus dem Internet ergänzen", Pretraining-Wissen über aktuelle
   MS-Produkte oder Roadmap-Daten — alles **verboten**, solange der User es
   nicht explizit für DIESE konkrete Frage freigibt.

   **Ausnahme — Live-Fetch auf kuratierte Quellen ist erlaubt:**
   `web_fetch` / `mcp__core__web_fetch` darf jederzeit ohne Rückfrage auf URLs
   aufgerufen werden, die in `data/sources.json` als `url` oder `feed_url`
   stehen. Das ist dieselbe kuratierte Liste, die der Mirror sowieso pullt —
   nur live statt aus dem letzten Scheduled Run. Use-Cases: Mirror auffrischen
   bei Lücke seit letztem Pull, aktuelle Folgefrage zu einem definierten Quellen-
   Index, Verifikation eines konkreten Feed-Items. Ergebnisse können in den
   Mirror geschrieben werden (gleiche Dedup-Logik wie der Scheduled Pull).
   **Kein Bruch der Quellen-Disziplin**, weil keine neue Quelle dazukommt.
   Sobald die URL nicht in `sources.json` steht → wieder Punkt 3 (fragen).

3. **Bei Lücke: EXPLIZIT fragen, nicht raten.** Wenn die Mirror-Daten die
   User-Frage nicht (oder nicht vollständig) beantworten:
   - Sag offen: *„Dazu finde ich in den News-Commander-Quellen nichts
     [Genaueres / Aktuelleres / nichts seit <Datum>]."*
   - Stelle GENAU EINE `AskUserQuestion` mit Optionen wie:
     - „Ja, ergänzend extern recherchieren (Web/Search)"
     - „Nein, nur bei den definierten Quellen bleiben"
     - „Stattdessen Topic adden und auf nächsten Pull warten"
   - **Erst nach explizitem User-„Ja" Web-/Search-Tools aufrufen.**
   Auch wenn der User schon einmal „ja" gesagt hat: das gilt **nur für die
   aktuelle Frage**, nicht als Dauerfreigabe. Bei der nächsten Lücke wieder fragen.

4. **Pretraining-Wissen wird nicht als Quelle ausgegeben.** Wenn der Skill
   etwas „weiß", was nicht im Mirror steht, darf er es nicht so präsentieren,
   als käme es aus den Quellen. Entweder als unsicher kennzeichnen UND fragen
   (siehe 3), oder weglassen.

5. **Erlaubt ohne Rückfrage** (kein Bruch dieser Regel):
   - Reine Aggregation/Summary/Re-Ranking von Mirror-Items
   - Topic-Score-Erklärung, Dedup-Audit, Quellen-Statistik
   - Skill-eigene Meta-Daten (`_meta.json`, `topics.json`, `source-state.json`)
   - **Live-`web_fetch` auf URLs aus `data/sources.json`** (`url` / `feed_url`)
     zum Mirror-Auffrischen oder Beantworten einer aktuellen Frage — siehe
     Punkt 2 Ausnahme. Read-only auf die kuratierte Liste, kein Internet-Wildwuchs.
   - Cross-Skill-Reads, die explizit erlaubt sind (DOPS `links.json` als
     Topic-Signal — read-only, kein Internet)
   - Antworten der Form „dazu habe ich in meinen Quellen nichts gefunden"

Verstoß = der Skill liefert Inhalte, die der User für aus seinen kuratierten
Quellen kommend hält, obwohl sie es nicht sind. Das ist die schlimmstmögliche
Form von Vertrauensbruch in einem News-Triage-System. Niemals tun.

# News Commander v1.2.1

> Persönliches News-Aggregations-System für Microsoft-Rollen. Pullt ~50 öffentliche MS-Quellen täglich um 03:00 Europe/Berlin, filtert topic-zentrisch und schickt einen kompakten Digest in den Teams-Self-Chat oder per Mail.

## Was er löst

- **Nichts verpassen** — Topic-zentrische Filterung über Title + Abstract + Source-Tags, unabhängig vom Feed
- **Keine Doppellektüre** — Anti-Echo-Dedup (fuzzy Title-Threshold 0.78) entfernt Dubletten zwischen TC-Boards und blog.microsoft.com
- **Kein Spam** — Items unter Score 0.5 fallen raus; Items zwischen 0.5 und 1.0 landen in Sektion "Vorschläge" mit Disclaimer
- **Empty-Day-Suppress** — Wenn HIGH+MEDIUM+VORSCHLÄGE=0 → kein Digest, kein Lärm
- **Window-basierter Pull** — pub_date-gefiltertes 36h-Fenster, gap-aware: bei Schedule-Lücke wird das Fenster automatisch + 6h Overlap erweitert
- **Mirror-Dedup** — sha1(source_id+url)-Hash als `item_id`, verhindert Duplikate im Mirror unabhängig vom Pull-Lauf
- **Topic-Anpassung per Chat** — `News Commander Topic Add <keyword>` / `Drop <keyword>` im Self-Chat, wird beim nächsten Run gelesen
- **Two-Channel-Delivery** — Teams 1:1-Self-Chat (Default) ODER Mail an dich selbst — konfigurierbar in preferences.json
- **Atomic Writes** — Alle JSON/JSONL-Mutationen via tempfile + fsync + `os.replace`; Crash mitten im Schreiben kann State nicht korrupten
- **Monatliches Archiv** — Alle 30 Tage werden Items älter als 90 Tage in `data/mirror/_archive/items-YYYY-MM.jsonl` ausgelagert; Auto-Trigger am Ende des Pull-Laufs
- **Source-Health-Tracking** — Pro Source `consecutive_failures`; ab 3 Fehlern in Folge → Auto-Deaktivierung am nächsten Montag
- **Cross-Skill-Integration** — Optional und read-only: `daily-ops-ms`, `account-radar`, `fasttrack` können auf den letzten Digest zugreifen

## Datei-Struktur

```
data/
├── _meta.json                    # Schema/Skill-Version, last_run, stats, last_archive_ts (gitignored)
├── sources.json                  # Quellenkatalog (~65 Quellen, 50 aktiv)
├── topics.json                   # Topic-Bundles mit Weights + Blocklist + History
├── preferences.example.json      # Template — kopieren nach preferences.json und anpassen
├── preferences.json              # User-Block, Delivery-Channel, Filter-Config (gitignored)
├── mirror/                       # gitignored (Runtime-State)
│   ├── items.jsonl               # Append-only Item-Mirror (1 Zeile = 1 Item)
│   ├── source-state.json         # Pro Source: last_pull_ts, last_status, consecutive_failures
│   └── _archive/
│       └── items-YYYY-MM.jsonl   # Monatstranche Items >90 Tage (Auto-Rotation alle 30d)
├── digests/                      # gitignored
│   └── YYYY-MM-DD.json           # Digest-Snapshot pro Tag (für Audit/Replay)
└── .intake-state.json            # Teams-Self-Chat-Scan-State (gitignored)

scripts/
├── _atomic.py                    # Geteiltes tempfile+fsync+os.replace-Modul (atomic writes)
├── pull_feeds.py                 # RSS/Atom-Parse + HTML-Scrape, gap-aware Window, Auto-Archive-Trigger
├── filter_and_rank.py            # Topic-Scoring + Dedup + Suggestion-Detection
├── intake_topics.py              # Teams-Self-Chat-Scan für Topic Add/Drop
├── archive_items.py              # Monatliche Rotation: Items >90d → _archive/, crash-safe Write-Order
└── send_digest.py                # Adaptive-Card-/Mail-Render + Versand

templates/
├── digest-teams.md               # Teams Self-Chat-Layout
└── digest-mail.md                # Outlook-Mail-Layout (HTML)

scheduled-prompts/
└── daily-news-run.md             # Prompt-Body für 03:00-Run
```

## Day-Cycle

```
03:00 Europe/Berlin
  │
  ├──► SCHRITT 1   intake_topics.py   (Self-Chat seit last_processed_ts scannen,
  │                                    Topics adden/droppen, History loggen)
  │
  ├──► SCHRITT 2   pull_feeds.py      (alle aktiven Sources, gap-aware Window,
  │                                    last_pull_ts abgleichen, Items in
  │                                    items.jsonl appenden; am Ende:
  │                                    archive_items.maybe_archive() auto)
  │
  ├──► SCHRITT 3   filter_and_rank.py (Score gegen topics.json, Dedup,
  │                                    Suggestion-Bucket, Cut-offs anwenden)
  │
  ├──► SCHRITT 4   send_digest.py     (wenn nicht leer: Adaptive Card
  │                                    in Self-Chat ODER Mail rausschicken;
  │                                    sonst suppress_empty_days → no-op)
  │
  └──► SCHRITT 5   _meta.json.last_run aktualisieren, digests/YYYY-MM-DD.json schreiben
```

## Onboarding (einmalig bei erstem Aufruf)

Wenn `preferences.json.onboarding.completed == false`, beim ersten User-Trigger:

1. **Startscreen** (Keen-Banner oben) zeigen
2. **Kurz-Erklärung** — was der Skill tut, drei Sätze
3. **Drei Fragen** via `AskUserQuestion`:
   - Channel? → Teams Self-Chat (Recommended) | Mail | Beide
   - Topic-Init? → Auto aus Rolle (Recommended) | Aus Beispielen lernen | Manuell
   - Industries? → Alle aus (Recommended) | Bestimmte an
4. Antworten in `preferences.json` schreiben
5. `onboarding.completed = true`, `completed_at = now`
6. Bestätigen: "Setup fertig. Erster Digest läuft heute Nacht um 03:00."
7. Optional: Sofort einen Probelauf machen, wenn der User darum bittet ("News Commander jetzt", "Probelauf")

### Banner-Display-Regel (verbindlich)

Siehe **HARD RULE** ganz oben in dieser Datei — der Banner-Block (ASCII-Art im
Codeblock) ist die **erste Ausgabe** bei jedem manuellen Trigger, vor allem
anderen Text und vor allen Tool-Calls.

- **Onboarding** (`onboarding.completed == false`): Banner IMMER zeigen, jedes Mal
- **Manuelle Trigger** (`NC start`, `NC briefing`, `News Commander`, `MS-News heute`,
  `NC status`, `NC digest`, „was gibt's Neues bei Microsoft", etc.):
  Banner einmal pro Session zeigen. Tracking via `_meta.json.banner_shown_session_ids[]`
  (Session-ID = aktueller Cowork-Session-Identifier). Bei wiederholtem Trigger in derselben Session unterdrücken.
- **Scheduled Runs** (03:00 autonom): Banner NICHT zeigen — kein User sichtbar
- **Async Self-Chat-Intake** (`News Commander Topic Add/Drop ...` Nachrichten):
  Banner NICHT zeigen — silent mutation, keine User-Response

## Topic-Scoring-Logik

Pro Item:

1. **Normalisierung** — Title und Abstract zu Lower-Case, Stopwörter raus
2. **Source-Tags hinzuziehen** — `sources.json[item.source_id].tags` als zusätzlicher Matching-Pool
3. **Pro Topic in `topics.json.topics[]`**:
   - Für jedes Keyword: Substring-Match auf Title + Abstract + Tags
   - `hits = count(matches)`
   - `topic_score = topic.weight * hits`
4. **Item-Score** = `sum(topic_score for topic in matched_topics)`
5. **Blocklist-Check**: Wenn ein Blocklist-Keyword matcht → `score = 0`, Item wird verworfen
6. **Klassifikation**:
   - `HIGH` wenn `score >= 2.0`
   - `MEDIUM` wenn `1.0 <= score < 2.0`
   - `WATCH` (= Vorschlag) wenn `0.5 <= score < 1.0`
   - sonst: drop
7. **Source-Priority-Boost**: `top` → +0.5, `high` → +0.3, `medium` → 0, `low` → −0.2
8. **Recency-Decay**: Items älter als `max_age_days` (Default 30) → drop

## Dedup-Logik (Anti-Echo)

- Über alle Items eines Runs (HIGH + MEDIUM + WATCH zusammen)
- Fuzzy Title-Match: `difflib.SequenceMatcher.ratio() >= dedupe_fuzzy_threshold` (Default 0.78)
- Tie-Break-Regeln (wer überlebt):
  1. Höherer Score gewinnt
  2. Bei Gleichstand: Quelle mit höherer `priority` gewinnt
  3. Bei Gleichstand: Ältere `pubDate` gewinnt (Original-Quelle vor Echo)
- Verlierer-Items werden NICHT verworfen, sondern unter `dedup_alias_of: <winner_id>` in `items.jsonl` markiert (für Audit, NICHT im Digest)

## Suggestion-Aggressiveness

Steuert die WATCH-Schwelle:
- `narrow` → WATCH-Threshold = 0.7 (nur knapp-an-Filter, max 2 Vorschläge)
- `normal` → WATCH-Threshold = 0.5 (Default, max 4 Vorschläge)
- `wide` → WATCH-Threshold = 0.3 (Lernmodus, max 6 Vorschläge)

Im Digest erscheint pro Vorschlag der Disclaimer:
```
💡 Würde mit aktuellen Filtern rausfallen.
   Treffer: <topic_keyword>. Topic adden?
   → "News Commander Topic Add <keyword>"
```

## Teams-Self-Chat-Intake

**Im Self-Chat als Nachrichten schreiben:**
```
News Commander Topic Add azure openai
News Commander Topic Add gpt-5
News Commander Topic Drop xbox
News Commander Topic Drop sustainability
```

**Verarbeitung (SCHRITT 1 jedes Morning-Runs):**

1. `ListChatMessages(person='me', since=<_meta.intake_processed_ts>)`
2. Filter auf Nachrichten, deren Text mit `News Commander Topic Add` oder `News Commander Topic Drop` startet
3. Pro Match:
   - **Add**: Wenn Keyword neu, neues Topic mit `id = nc_<slug>`, `weight = 1.0`, `source = "user_intake"` anlegen; sonst Keyword zum bestehenden Topic anhängen
   - **Drop**: Keyword aus allen Topics entfernen; wenn Topic dadurch leer → Topic löschen (mit `source != "auto_role"` als Safeguard, damit Auto-Topics nicht versehentlich gelöscht werden)
4. History-Eintrag in `topics.json.history[]` schreiben (`ts`, `action`, `keyword`, `topic_id`, `by: "user_chat"`)
5. `_meta.intake_processed_ts = now`

**Safeguards:**
- Nur die letzten 100 Self-Chat-Nachrichten pro Run scannen (Performance)
- Pro Run max 20 Topic-Mutations (gegen Tippfehler-Spam)
- Bei Drop eines Auto-Role-Topics → Warnung im Digest, kein Hard-Delete

## Quellen-Katalog (sources.json)

50 aktive Quellen in 13 Kategorien (siehe `data/sources.json` für vollen Katalog):
- **de-lokal** (3) — Techwiese DE-Feeds
- **corporate** (8) — Official MS Blog, News Signal, The Source, Unlocked, On The Issues, Microsoft AI, Accessibility, Sustainability
- **m365-copilot-core** (7) — TC M365 Copilot, TC Copilot Studio, TC Copilot Events, M365 Blog, M365 Dev Blog, Roadmap, TC M365 Blog (TOP-PRIO)
- **workload** (7) — Excel, Outlook, Teams, Teams Community, SharePoint, Planner, EOS
- **security** (5) — TC Security, MS Security Blog, MSRC Blog, Sec Advisories, TC Entra
- **dev-platform** (5) — VS, PowerShell, Mechanics, Sysinternals, Agents Hub
- **power-platform** (3) — PP Blog, Power Apps, Power Automate
- **windows** (4) — 3 inaktiv (Insider/Experience/Devices), Edge aktiv
- **adoption-learn** (3) — Adoption Portal, Release Notes, Skills Hub
- **public-sector-ft** (3) — Public Sector (inaktiv), FastTrack, Community News
- **sustainability-a11y** (2) — siehe corporate
- **internal** (1) — AMC RSS
- **industry** (9) — alle inaktiv, an Bedarf einschaltbar

**Removed (6)** — Microsoft Learn (zu groß), AI Skills Navigator (Interaktiv-Tool), Edu Events (Klick-UI), Edu Blog (rollenfern), Tech Hub (MS-internal), Copilot Studio Wave2 (statische Doku).

## DOPS-Integration (optional)

Bei jedem Lauf:

```
Glob /mnt/user-config/.claude/skills/daily-ops-ms/data/links.json
```

- **Vorhanden** → `dops_available = true`. `links.json` read-only laden. Tags der Links als zusätzlicher Topic-Signal-Pool. Wenn DOPS-Intgration aktiv (`preferences.dops_integration.enabled == true`) und ein News-Item per Title/Abstract auf ein DOPS-Link-Tag-Bundle matcht, kommt ein zusätzlicher Score-Boost von +0.3 (signal_from_dops).
- **Nicht vorhanden** → `dops_available = false`. News Commander läuft autark. Keine Frage, kein Mecker.

**Exposed Command** — Bei `preferences.dops_integration.expose_dops_news_command == true`:
- Tagsüber-Trigger `DOPS news` (oder `DOPS-news`) liest den letzten Digest aus `data/digests/<today>.json` und zeigt ihn im Chat. Wenn `<today>.json` fehlt (z.B. weil 03:00-Run noch nicht lief oder empty_day war) → "Heute kein Digest, weil <Grund>."

⚠️ Niemals nach DOPS fragen, wenn der Skill komplett fehlt. Detection bleibt still.

## Befehls-Cheatsheet

| Befehl | Tut was |
|--------|---------|
| `News Commander` / `NC start` / `NC briefing` | Manueller Probelauf (Pull + Filter + Send) |
| `NC status` | _meta.json + last_run + Stats anzeigen, ohne Run |
| `NC sources` / `NC quellen` | Quellenkatalog kompakt anzeigen (aktiv/inaktiv pro Kategorie) |
| `NC pause` | `preferences.delivery.send_only_if_items = true` UND Scheduled Prompt pausieren |
| `NC resume` | Scheduled Prompt wieder aktivieren |
| `NC topics` | Aktive Topics + Weights anzeigen |
| `NC topic add <keyword>` | Topic-Add manuell (statt über Chat-Keyword) |
| `NC topic drop <keyword>` | Topic-Drop manuell |
| `NC digest` | Letzten Digest aus `data/digests/<today>.json` zeigen |
| `DOPS news` | (wenn DOPS installiert) Letzten Digest abrufen |

## Wie Cowork den Skill nutzt

| Anfrage | Geladen / Aktion |
|---------|------------------|
| Scheduled Run 03:00 | Alle 4 Scripts in Reihenfolge, Banner unterdrückt |
| `News Commander` manuell | Banner + Probelauf, send_digest mit `--force-send` |
| `NC status` | Nur `_meta.json` + `topics.json` (read-only) |
| `NC topic add/drop` | `topics.json` schreiben + History-Eintrag |
| `DOPS news` | `data/digests/<today>.json` lesen, kein Pull |
| Borderline-Vorschläge im Digest | User antwortet im Self-Chat mit Keyword-Add → wird beim nächsten Run aktiv |

## Setup

Siehe `SETUP.md` für detaillierte Installation. Kurz:

1. Skill-Verzeichnis liegt unter `/mnt/user-config/.claude/skills/news-commander/`
2. Bei erstem Trigger: Onboarding läuft automatisch (siehe Sektion oben)
3. Scheduled Prompt täglich 03:00 Europe/Berlin — wird beim Onboarding automatisch via `SetupScheduledPrompt` angelegt
4. Optional: Outlook-Regel auf `News Commander Digest` im Subject → Move to `News/News Commander/` Folder (saubere Mailbox)
5. DOPS-Integration ist auto-detected

## Anpassungen

- **Channel ändern**: `preferences.json.delivery.channel` zwischen `teams_self_chat` | `mail` | `both` umschalten
- **Topic-Init nachträglich ändern**: Geht via `NC topic add/drop` granular; vollständiger Reset über `NC reset topics` (warnt vorher)
- **Mehr/weniger Vorschläge**: `preferences.json.filter.suggestion_aggressiveness` und `max_suggestion_items`
- **Industries einschalten**: In `sources.json` betroffene Einträge `active: true` setzen
- **Lauf-Zeit ändern**: `EditScheduledPrompt` mit neuer `hours[]` (z.B. `["6"]` für 06:00)
- **Stiller Modus** (kein Empty-Day-Send, kein Vorschläge-Hinweis): `suppress_empty_days: true` + `max_suggestion_items: 0`
